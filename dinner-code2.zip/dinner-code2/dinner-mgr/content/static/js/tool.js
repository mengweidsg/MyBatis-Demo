/**
 * treeGrid插件
 */
(function ($) {
	var url;

	function getChildData(nodeId, callBack) {
		var depth=$('#tr-'+nodeId).attr('depth');
		if(url==''){
			return
		}
		$.get(url, { nodeId:nodeId,depth:depth},
			function (data) {
				callBack(data);
			});
	}

	function expandNode(nodeId) {
		var $thisTr = $('#tr-' + nodeId);
		var hasLoad = $thisTr.data('hasLoad');
		if (hasLoad == 'true') {
			$('.child-' + nodeId).show();
			return;
		}
		getChildData(nodeId, function (data) {
			$thisTr.data('hasLoad', 'true');
			$thisTr.after(data);
		});
	}

	function collapseNode(nodeId) {
		var $thisTr = $('#tr-' + nodeId);
		$('.child-' + nodeId).hide();
	}

	$.fn.treeGrid = function (config) {
		config= $.extend({
			url:''
		},config);
		url = config.url;
		var $this = $(this);
		$this.on('click', 'i.icon',function () {
			var $thisIcon = $(this);
			var type = $(this).attr('class');
			var nodeId = $thisIcon.parent().parent().attr('node-id');
			type = type.match(/expand|collapse/g);
			if (type === null) return;
			if (type == 'expand') {
				$thisIcon.removeClass('expand').addClass('collapse');
				expandNode(nodeId);
			} else {
				$thisIcon.removeClass('collapse').addClass('expand');
				collapseNode(nodeId)
			}
		});

	};
})(jQuery);