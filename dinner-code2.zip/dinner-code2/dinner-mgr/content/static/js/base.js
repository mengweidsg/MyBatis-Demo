(function () {
    $.fn.form.settings.rules.mob = function (a) {var b = /^(134|135|136|137|138|139|150|151|152|157|158|159|182|187|188|147|130|131|132|155|156|183|185|186|133|153|180|181|189|186)\d{8}$/;return b.test(a)};
    $.fn.form.settings.rules.tel = function (a) {
        var b = /((\d{11})|^((\d{7,8})|(\d{4}|\d{3})-(\d{7,8})|(\d{4}|\d{3})-(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1})|(\d{7,8})-(\d{4}|\d{3}|\d{2}|\d{1}))$)/;
        return b.test(a)
    };
    $.fn.form.settings.rules.number = function (a) {
        var b = /^\d+$/;
        return b.test(a)
    };
    $.fn.form.settings.rules.price = function (a) {
        var b = /^\d{1,8}\.{0,1}(\d{1,2})?$/;
        return b.test(a)
    };
    $.fn.form.settings.rules.integer = function (a) {
        var b = /^[-\+]?\d+$/;
        return b.test(a)
    };
    $.fn.form.settings.rules.double = function (a) {
        var b = /^[-\+]?\d+(\.\d+)?$/;
        return b.test(a)
    };
    $.fn.form.settings.rules.length_1_18 = function (a) {
        return a.length>0 && a.length<19;
    };
    $.fn.form.settings.rules.lengthBe = function (a) {
        console.log(arguments);
        return a.length>0 && a.length<19;
    };
    $.fn.form.settings.rules.count = function(a, length){
        a = a.split(" ");
        for (var i = a.length - 1; i >= 0; i--) {
            if(a[i].length > length)
                return false;
        }
        return true;
    };
    /*自定义菜单验证*/
    $.fn.form.settings.rules.notHideEmptyMaxLength500 = function (a) {


        var v=$(this).is(":visible");
        console.log(a.length)
        if(v){
            return (a.length<=500 && a.length>0);
        }else{
            return true;
        }
    };
    $.fn.form.settings.rules.notHideEmptyUrl = function (a) {


        var v=$(this).is(":visible");

        if(v){
            var b=/(ftp|http|https):\/\/(\w+:{0,1}\w*@)?(\S+)(:[0-9]+)?(\/|\/([\w#!:.?+=&%@!\-\/]))?/;return b.test(a)

        }else{
            return true;
        }
    };
    /*/自定义菜单验证*/
    $.fn.form.settings.rules.limit = function(a){ //只含有汉字、数字、字母、下划线，下划线位置不限
        var b = /^[a-zA-Z0-9_\u4e00-\u9fa5]+$/;
        return b.test(a)
    };
    /*字段唯一验证*/
    $.fn.form.settings.rules.fieldUnique = function(val,url){
        var result=$.ajax({
            url: url,
            async: false,
            data:{value :val}
        });
        if(result.status=="200"){
            var json= $.parseJSON(result.responseText);
            if(json.result=="success"){
                return true;
            }else{
                return false;
            }

        }else{
            console.log('验证失败：',result);
            return false;
        }
    };
    /**
     * 比较当前这个input，与另一个input的值
     * @param val -- 当前这个input的值
     * @param param   "rule,fieldName" -- rule: [moreThan|lessThan] [大于另一个input的值|小于另一个input值] ,fieldName:另一个input的name
     */
    $.fn.form.settings.rules.compare = function(val,param){
        param=param.split(',');
        var rule=param[0];
        var fieldName=param[1];
        var otherVal=$('[name="'+fieldName+'"]').val();
        val=parseInt(val,10);
        otherVal=parseInt(otherVal,10);
        if(rule=="moreThan"){
            return val>otherVal;
        }else if(rule=="lessThan"){
            return val<otherVal;
        }
        return true;
    };
})();
/**
 * 表单提交失败时，自动将 焦点聚焦到失败的那个input上
 */
function focusErrorField() {
    var hasWaitTime=0;
    //错误的提示信息 的 那个label 现在可能还未生成
    var focusInterval = window.setInterval(function () {
        if(hasWaitTime>100){
            clearInterval(focusInterval);
        }
        hasWaitTime++;
        var label = $('.ui.prompt.label.visible').eq(0);
        if (label.length == 0) {
            return;
        }
        var offsetTop = label.offset().top;
        var input = label.parent().find('input,textarea').eq(0);
        $('body').animate({'scrollTop':offsetTop - 80}, 200, function () {
            if (input.length > 0) {
                input.focus();
            }
        });
        clearInterval(focusInterval);
    }, 50);
}

var ywTool={};
ywTool.parseJSON=function(str){
    console.log(str);
    console.log('||');
    str=str.replace(/\(/g,'\\u0028');
    str=str.replace(/;/g,'\\u003b');
    str=str.replace(/=/g,'\\u003d');
    str=str.replace(/\\]/g,'\\\\\\\u005d');
    console.log(str);
    return $.parseJSON(str);
}

/**
 * 生成菜单
 * @param data
 * @return {String}
 */
function generateMenu(data) {
    var html = '';
    var temp={};        //要闭合的标签
    var tempArray=[];
    for (var i = 0, len = data.length; i < len; i++) {
        var o = data[i];
        if(i>0){
            var prevItem=data[i-1];
            if(prevItem.level> o.level){
                //如果层级变小了，把前面的未标签 闭合
                for (var j = tempArray.length; j >= 0; j--) {
                    var lev = tempArray[j];
                    if(lev>= o.level){
                        html+=temp[lev];
                        delete temp[lev];
                        tempArray.splice(j,1);
                    }
                }
            }
        }
        if(!o.link) o.link='javascript:void(0)';
        var partHtml=aHtml(o);
        html+=partHtml.head;
        if (o.isItem == '0') {
            //如果 有下级了 把需要闭合的标签存起来
            tempArray.push(o.level);
            temp[o.level]=partHtml.foot;
        }
    }
    for (var i = 0, len = tempArray.length; i < len; i++) {
        //最后结束的时候 把最后还未闭合的标签闭合了
        var lev = tempArray[i];
        html+=temp[lev];
    }
    return html;

    function aHtml(o) {
        var head='', foot='';
        if (o.level == '1') {//一级菜单
            var icon='<i class="icon"></i>';
            if (o.isItem == '0') {// 有下级
                icon='<i class="dropdown icon"></i>';
            }
            if (o.isActive == '0') {//没有高亮
                head += '<div class="title"><a href="'+o.link+'">'+icon + o.title + '</a></div>';
                if (o.isItem == '0') {//有下级
                    head += '<div class="content">';
                    foot += '</div>';
                }
            } else {//高亮
                head += '<div class="title active"><a href="'+o.link+'">'+icon + o.title + '</a></div>';
                if (o.isItem == '0') {//有下级
                    head += '<div class="content active">';
                    foot += '</div>';
                }
            }
        } else {//非一级菜单
            if (o.isItem == '0') {//有下级菜单
                if (o.isActive == '0') {//非高亮
                    head += '<div class="subnav"><div class="accordion"><div class="subnav title"><a href="'+o.link+'"><i class="icon"></i><i class="dropdown icon"></i>' + o.title + '</a></div><div class="subnav content">';
                    foot += '</div></div></div>';
                } else {//高亮
                    head += '<div class="subnav" style="opacity: 1;"><div class="accordion"><div class="subnav title active"><a href="'+o.link+'"><i class="icon"></i><i class="dropdown icon"></i>' + o.title + '</a></div><div class="subnav content active">';
                    foot += '</div></div></div>';
                }
            }else{//没下级菜单
                if(o.isActive  == '0'){//非高亮
                    head+='<div class="subnav"><a href="'+o.link+'"><i class="icon"></i><i class="icon"></i>' + o.title + '</a></div>';
                }else{//高亮
                    head+='<div class="subnav active" style="opacity: 1;"><a href="'+o.link+'"><i class="icon"></i><i class="icon"></i>' + o.title + '<i class="icon triangle right active"></i></a></div>';
                }
            }
        }
        return {'head':head,'foot':foot};
    }
}