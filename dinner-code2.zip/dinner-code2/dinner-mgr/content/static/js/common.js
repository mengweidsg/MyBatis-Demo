function initMap() {
	var isSearch = false;
	var localSearch;
	var map = new BMap.Map("map_wrap", {
		enableMapClick:false
	});
	var point = new BMap.Point(120.167633, 30.2822);
	map.centerAndZoom(point, 12);
	map.addControl(new BMap.NavigationControl());
	map.enableScrollWheelZoom();//启动鼠标滚轮缩放地图
	map.enableKeyboard();//启动键盘操作地图


	window.openInfoWinFuns = null;
	var options = {
		pageCapacity:10,
		onSearchComplete:function (results) {
			if(results.getCurrentNumPois()==0){
				$('#mapLoading').hide();
				$('.result-wrapper').show();
				$('.module-header').html('未找到该地址！');
			}
			// 判断状态是否正确
			if (localSearch.getStatus() == BMAP_STATUS_SUCCESS) {
				$('#mapLoading').hide();
				$('.module-header').html('共<span class="highlight addr_amount">'+results.Um.length+'</span>地址');
				var s = [];
				openInfoWinFuns = [];
				for (var i = 0; i < results.getCurrentNumPois(); i++) {
					var marker = addMarker(results.getPoi(i).point, i);
					var openInfoWinFun = addInfoWindow(marker, results.getPoi(i), i);
					openInfoWinFuns.push(openInfoWinFun);
					// 默认打开第一标注的信息窗口
					var selected = "";
					if (i == 0) {
						selected = "ui_current";
						openInfoWinFun();
						map.setZoom(16);
						map.setCenter(results.getPoi(i).point);
					}
					s.push('<div onclick="openInfoWinFuns[' + i + ']()" class = "result-block '+selected+'"><div class = "marker ui_'+(i+1)+'"></div> <p class = "result-name">'+ results.getPoi(i).title.replace(new RegExp(results.keyword, "g"), '<b>' + results.keyword + '</b>') +'</p> <p class = "result-address">' + results.getPoi(i).address + '</p> </div>');
				}
				$('.search_results').html(s.join(''));
				$('.result-wrapper').show();
			}
		}
	};

	// 添加标注
	function addMarker(point, index) {
		var myIcon = new BMap.Icon("http://api.map.baidu.com/img/markers.png", new BMap.Size(23, 25), {
			offset     :new BMap.Size(10, 25),
			imageOffset:new BMap.Size(0, 0 - index * 25)
		});
		var marker = new BMap.Marker(point, {icon:myIcon});
		map.addOverlay(marker);
		return marker;
	}	// 添加信息窗口
	function addInfoWindow(marker, poi, index) {
		var maxLen = 10;
		var name = null;
		if (poi.type == BMAP_POI_TYPE_NORMAL) {
			name = "地址：  "
		} else if (poi.type == BMAP_POI_TYPE_BUSSTOP) {
			name = "公交：  "
		} else if (poi.type == BMAP_POI_TYPE_SUBSTOP) {
			name = "地铁：  "
		}
		// infowindow的标题
		var infoWindowTitle = '<div style="font-weight:bold;color:#CE5521;font-size:14px">' + poi.title + '</div>';
		// infowindow的显示信息
		var infoWindowHtml = [];
		infoWindowHtml.push('<table cellspacing="0" style="table-layout:fixed;width:100%;"><tbody>');
		infoWindowHtml.push('<tr>');
		infoWindowHtml.push('<td style="vertical-align:top;line-height:16px;width:38px;white-space:nowrap;word-break:keep-all">' + name + '</td>');
		infoWindowHtml.push('<td style="vertical-align:top;line-height:16px">' + poi.address + ' </td>');
		infoWindowHtml.push('</tr>');
		infoWindowHtml.push('</tbody></table>');
		infoWindowHtml.push('<div class="info-window-btns"><a href="place.html?addres='+poi.title+'&lng='+poi.point.lng+'&lat='+poi.point.lat+'">确定</a></div>');
		var infoWindow = new BMap.InfoWindow(infoWindowHtml.join(""), {title:infoWindowTitle, width:200});
		var openInfoWinFun = function () {
			marker.openInfoWindow(infoWindow);
			$('#searchResults').find('.result-block').eq(index).addClass('ui_current').siblings('.ui_current').removeClass('ui_current');
			$('#searchResults').scrollTop(80*index);
			for (var cnt = 0; cnt < maxLen; cnt++) {
				if (!document.getElementById("list" + cnt)) {
					continue;
				}
				if (cnt == index) {
					document.getElementById("list" + cnt).style.backgroundColor = "#f0f0f0";
				} else {
					document.getElementById("list" + cnt).style.backgroundColor = "#fff";
				}
			}
		}
		marker.addEventListener("click", openInfoWinFun);
		return openInfoWinFun;
	}

	function infoWindowCLick(info){
		console.log(info);

	}

	var localSearch = new BMap.LocalSearch(map, options);

	$('#address').keypress(function (e) {
		if (e.keyCode == 13) {
			$('#searchAddress').click();
		}
	});
	$('#searchAddress').click(function () {
		var address = $('#address').val();
		if (address == "") {
			return;
		}
		if (!map) return;
		localSearch.clearResults();
		map.clearOverlays();
		$('#mapLoading,#searchResult').show();
		localSearch.search(address);
	});
	$('#toggleResult').click(function(){
		$(this).toggleClass('off');
		$('#searchResults').slideToggle(500);
		if($(this).hasClass('off')){
			$("#searchResult").animate({
				height: "43px"
			}, 500 );
		}else{
			$("#searchResult").animate({
				height: "100%"
			}, 500 );
		}


	});
}
