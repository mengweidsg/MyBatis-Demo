package com.dinner.mgr.controller.dinner;

import java.io.IOException;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.UserExample;
import com.dinner.common.service.biz.DcOrderService;
import com.dinner.common.service.biz.UserService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 人员管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/cook")
public class CookController extends BaseController {

	@Resource
	private DcOrderService dcOrderService;
	
	@Resource
	private UserService userService;

	// 首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "cook")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String q_type) {
		ModelAndView view = new ModelAndView("dinner/cook/index");
		view.addObject("breadcrumb", "烧菜管理");
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
		
		UserExample query = new UserExample();
		UserExample.Criteria criteria = (UserExample.Criteria) query.createCriteria();
		criteria.andRestIdEqualTo(UserUtils.getLoginUser(request).getRestId());
		criteria.andUserTypeEqualTo("1");
		view.addObject("cookie", userService.queryCookList(query));
		
		view.addObject("list", dcOrderService.queryCook(UserUtils.getLoginUser(request).getRestId()));
		return view;
	}
	
	 //设置厨师
	 @RequestMapping(value = "/update.htm", method = RequestMethod.POST)
	 @Permission(module = "dinner", privilege = "cook")
	 public void manager(HttpServletRequest request, HttpServletResponse response) throws IOException {
		 String cooker = request.getParameter("cooker");
		 String ids = request.getParameter("ids");
		 dcOrderService.update(cooker,ids,UserUtils.getLoginUser(request).getRestId());
		 this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	 }
	 
	 //上菜
	 @RequestMapping(value = "/finish.htm", method = RequestMethod.POST)
	 @Permission(module = "dinner", privilege = "cook")
	 public void finish(HttpServletRequest request, HttpServletResponse response) throws IOException {
		 String ids = request.getParameter("ids");
		 dcOrderService.update(ids);
		 this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	 }
	 
	// 全屏查看
	@RequestMapping(value = "/full.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "cook")
	public ModelAndView full(HttpServletRequest request, HttpServletResponse response, String q_type) {
		ModelAndView view = new ModelAndView("dinner/cook/full");
		view.addObject("breadcrumb", "烧菜管理");
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
		
		UserExample query = new UserExample();
		UserExample.Criteria criteria = (UserExample.Criteria) query.createCriteria();
		criteria.andRestIdEqualTo(UserUtils.getLoginUser(request).getRestId());
		criteria.andUserTypeEqualTo("1");
		view.addObject("cookie", userService.queryCookList(query));
		view.addObject("type_", Paramenter.getInstance().getTypeForMap()); // 菜类型
		view.addObject("map", dcOrderService.queryCookForMap(UserUtils.getLoginUser(request).getRestId()));
		return view;
	}

}
