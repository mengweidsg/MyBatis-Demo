package com.dinner.mgr.controller.report;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.service.biz.ReportService;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 人员管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/report")
public class ReportController extends BaseController {

	@Resource
	private ReportService reportService;
	
	@RequestMapping(value = "/money.htm", method = RequestMethod.GET)
	@Permission(module = "report", privilege = "sytj")
	public ModelAndView money(HttpServletRequest request, HttpServletResponse response, String start,String end) {
		ModelAndView view = new ModelAndView("report/money");
		view.addObject("breadcrumb", "餐厅收银统计");
		view.addObject("start", start);
		view.addObject("end", end);
		if(start !=null && start.length() > 0){
			start += "00:00:00";
		}
		if(end !=null && end.length() > 0){
			end += "23:59:59";
		}
		view.addObject("list", reportService.money(start,end,UserUtils.getLoginUser(request).getRestId()));
		return view;
	}
	
	@RequestMapping(value = "/earn.htm", method = RequestMethod.GET)
	@Permission(module = "report", privilege = "srxx")
	public ModelAndView srxx(HttpServletRequest request, HttpServletResponse response, String start,String end) {
		ModelAndView view = new ModelAndView("report/earn");
		view.addObject("breadcrumb", "餐厅收入信息");
		view.addObject("joinType", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		view.addObject("start", start);
		view.addObject("end", end);
		if(start !=null && start.length() > 0){
			start += "00:00:00";
		}
		if(end !=null && end.length() > 0){
			end += "23:59:59";
		}
		view.addObject("list", reportService.srxx(start,end));
		return view;
	}
	

}
