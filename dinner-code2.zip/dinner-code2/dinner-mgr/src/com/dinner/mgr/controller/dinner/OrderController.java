package com.dinner.mgr.controller.dinner;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcMenuExample;
import com.dinner.common.entity.DcOrder;
import com.dinner.common.entity.DcOrderExample;
import com.dinner.common.entity.DcOrderExample.Criteria;
import com.dinner.common.entity.DcOrderMenu;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcMenuService;
import com.dinner.common.service.biz.DcOrderService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 订单管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/order")
public class OrderController extends BaseController {

	@Resource
	private DcOrderService dcOrderService;
	@Resource
	private DcMenuService dcMenuService;

	// 首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "order")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String type, String ispay, String cashor, String start, String end) {
		ModelAndView view = new ModelAndView("dinner/order/index");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (type != null && type.trim().length() > 0) {
			criteria.andTypeEqualTo(type);
		}
		if (ispay != null && ispay.trim().length() > 0) {
			criteria.andIspayEqualTo(ispay);
		}
		
		if (cashor != null && cashor.trim().length() > 0) {
			criteria.andCashorEqualTo(cashor);
		}
		
		if (start != null && start.trim().length() > 0) {
			criteria.andStartGtTo(start);
		}
		if (end != null && end.trim().length() > 0) {
			criteria.andEndLtTo(end);
		}
		
		criteria.andSendMeEqualTo(UserUtils.getLoginUser(request).getRestId());
		view.addObject("breadcrumb", "订单管理");
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("type", type);
		view.addObject("ispay", ispay);
		
		view.addObject("cashor", cashor);
		view.addObject("start", start);
		view.addObject("end", end);
		
		view.addObject("list", dcOrderService.queryList(query));

		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("query", query);
		return view;
	}

	// 管理界面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "order")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/order/manager");
		view.addObject("breadcrumb", "订单管理");

		view.addObject("order_no", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
		view.addObject("operate_id", UserUtils.getLoginUser(request).getName());
		if (id != null) {
			DcOrder order = dcOrderService.selectByPrimaryKey(Integer.parseInt(id));
			view.addObject("data", order);
			view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));
			view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
			view.addObject("order_no", order.getOrder_no());
			view.addObject("operate_id", order.getOperate_id());
		}
		return view;
	}

	// 选菜界面
	@RequestMapping(value = "/menu.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "order")
	public ModelAndView menu(HttpServletRequest request, HttpServletResponse response, String index, String code, String name, String type) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/order/menu");
		index = index == null ? "0" : index;
		// 查询数据 显示枫叶
		int pageNo = Integer.parseInt(index);

		DcMenuExample query = new DcMenuExample();
		DcMenuExample.Criteria createCriteria = (DcMenuExample.Criteria) query.createCriteria();
		if (name != null && name.trim().length() > 0) {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andNameLike("%"+name+"%");
		}
		if (type != null && type.trim().length() > 0) {
			createCriteria.andTypeEqualTo(type);
		}
		if (code != null && code.trim().length() > 0) {
			code = new String(code.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andCodeEqualTo(code);
		}
		
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			createCriteria.andRestIdEqualTo(loginUser.getRestId());
		}
		query.setPageNo(pageNo);
		List<Map<String,Object>> list = dcMenuService.queryList(query);
		view.addObject("list", list);
		view.addObject("query", query);
		view.addObject("typeQ", type);
		view.addObject("name", name);
		view.addObject("code", code);
		view.addObject("type", Paramenter.getInstance().getType()); // 菜类型
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度

		return view;
	}

	// 保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "order")
	public void save(DcOrder dcOrder, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User loginUser = UserUtils.getLoginUser(request);
		dcOrder.setOperate_id(loginUser.getLoginName());
		dcOrder.setType(Integer.parseInt(request.getParameter("buyType")));
		if(dcOrder.getId() == null){	//新增
			dcOrder.setRest_id(loginUser.getRestId());
			dcOrder.setSendRestId(loginUser.getRestId());
			dcOrder.setSendRestStatus(1);
			if(dcOrder.getType() == 0){
				dcOrder.setState(2);
				dcOrder.setIspay(1);
				dcOrder.setPay_time(new Date());
				dcOrder.setCashor(loginUser.getLoginName());
			}
			dcOrderService.save(dcOrder);
		}else{
			dcOrderService.update(dcOrder);
		}
		List<DcOrderMenu> l = new ArrayList<DcOrderMenu>();
		String parameter = request.getParameter("result");
		String[] split = parameter.split(",");
		for (String r : split) {
			String[] split2 = r.split("\\|");
			DcOrderMenu dcOrderMenu = new DcOrderMenu();
			dcOrderMenu.setMenuId(Integer.parseInt(split2[0]));
			dcOrderMenu.setOrder_time(split2[1]);
			dcOrderMenu.setInsert_order_time(split2[2]);
			dcOrderMenu.setStatus(Integer.parseInt(split2[3]));
			dcOrderMenu.setNum(Integer.parseInt(split2[4]));
			if(split2.length>5){
				dcOrderMenu.setRemark(split2[5]);
			}else{
				dcOrderMenu.setRemark("");
			}
			dcOrderMenu.setOrder_id(dcOrder.getId());
			l.add(dcOrderMenu);
		}
		dcOrderService.updateMenu(dcOrder.getId(), l);
		dcOrderService.saveprice(dcOrder.getId());
		this.outJson(response, JsonUtil.toJson(new Result<String>(dcOrder.getId() + "")));
	}

	// 买单界面
	@RequestMapping(value = "/sell.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "order")
	public ModelAndView sell(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/order/sell");
		view.addObject("breadcrumb", "买单管理");

		view.addObject("operate_id", UserUtils.getLoginUser(request).getName());
		view.addObject("data", dcOrderService.selectByPrimaryKey(Integer.parseInt(id)));
		view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));

		return view;
	}

	// 买单
	@RequestMapping(value = "/savesell.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "order")
	public void savesell(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String order_id = request.getParameter("id");
		User loginUser = UserUtils.getLoginUser(request);
		try {
			dcOrderService.savesell(order_id, loginUser.getName());
			this.outJson(response, JsonUtil.toJson(new Result<String>("")));
		} catch (Exception e) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(1, e.getMessage())));
			e.printStackTrace();
		}
	}

	// 退单界面
	@RequestMapping(value = "/sellAllback.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "order")
	public ModelAndView sellAllback(HttpServletRequest request, HttpServletResponse response, String id, String menuId) {
		ModelAndView view = new ModelAndView("dinner/order/sellback");
		view.addObject("breadcrumb", "退单管理");
		view.addObject("data", dcOrderService.selectByPrimaryKey(Integer.parseInt(id)));
		if (menuId != null && menuId.trim().length() > 0) {
			
			view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),Integer.parseInt(menuId)));
		}else{
			view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));
		}
		
		

		view.addObject("getBackReason", Paramenter.getInstance().getBackReason());

		view.addObject("menuId", menuId);

		return view;
	}

	// 退单
	@RequestMapping(value = "/saveback.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "order")
	public void saveBack(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String order_id = request.getParameter("id");
		String menuIds = request.getParameter("menuIds");
		String reason = request.getParameter("reason");
		String backor = request.getParameter("backor");
		String backor_pwd = request.getParameter("backor_pwd");
		String back_men = request.getParameter("back_men");
		String back_men_pwd = request.getParameter("back_men_pwd");
		User loginUser = UserUtils.getLoginUser(request);
		try {
			menuIds = menuIds.substring(0, menuIds.length() - 1);
			if(loginUser.getLoginName().equals(backor) && loginUser.getPwd().equals(DigestUtils.md5Hex(backor_pwd))){
				dcOrderService.saveBack(order_id, menuIds, reason, backor, backor_pwd, back_men, back_men_pwd, loginUser.getRestId());
				this.outJson(response, JsonUtil.toJson(new Result<String>("")));
			}else{
				this.outJson(response, JsonUtil.toJson(new Result<String>(1,"执行人信息错误")));
			}
			
		} catch (Exception e) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(1, e.getMessage())));
			e.printStackTrace();
		}
	}

}
