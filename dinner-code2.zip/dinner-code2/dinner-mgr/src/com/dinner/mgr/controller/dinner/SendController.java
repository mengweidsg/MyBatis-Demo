package com.dinner.mgr.controller.dinner;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcMenuExample;
import com.dinner.common.entity.DcOrder;
import com.dinner.common.entity.DcOrderExample;
import com.dinner.common.entity.DcOrderExample.Criteria;
import com.dinner.common.entity.DcOrderMenu;
import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcMenuService;
import com.dinner.common.service.biz.DcOrderService;
import com.dinner.common.service.biz.DcRestService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 人员管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/send")
public class SendController extends BaseController {

	@Resource
	private DcOrderService dcOrderService;
	
	@Resource
	private DcMenuService dcMenuService;
	@Resource
	private DcRestService dcRestService;
	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "send")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String submit,String accept,String isPay) {
		ModelAndView view = new ModelAndView("dinner/send/index");
		view.addObject("breadcrumb", "外卖申请");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (submit != null &&submit.trim().length() > 0) {
			criteria.andSubmitEqualTo(Integer.parseInt(submit));
		}
		if (accept != null && accept.trim().length() > 0) {
			criteria.andAcceptEqualTo(Integer.parseInt(accept));
		}
		if (isPay != null && isPay.trim().length() > 0) {
			criteria.andIspayEqualTo(isPay);
		}
		
		criteria.andTypeNotEqualTo(1);	//不是堂食
		criteria.andRestIdEqualTo(UserUtils.getLoginUser(request).getRestId());
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("submit", submit);
		view.addObject("isPay", isPay);
		view.addObject("accept", accept);
		view.addObject("list", dcOrderService.queryList(query));

		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("acceptStatus", Paramenter.getInstance().getAcceptStatusForMap()); // 接受状态
		view.addObject("acceptStatus_", Paramenter.getInstance().getAcceptStatus()); // 接受状态
		view.addObject("query", query);
		
		return view;
	}
	
	//提交外派请求
	@RequestMapping(value = "/changeSubmit.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "send")
	public void changeSubmit(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcOrderService.changeSubmit(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>("请求成功！")));
	}
	
	//查看详情
	@RequestMapping(value = "/detail.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "send")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/send/detail");
		view.addObject("breadcrumb", "外卖详情");
		
		 view.addObject("operate_id", UserUtils.getLoginUser(request).getName());
		 view.addObject("data", dcOrderService.selectByPrimaryKey(Integer.parseInt(id)));
		 view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));
		 
		 return view;
	}

	//接收
	@RequestMapping(value = "/send.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "send")
	public ModelAndView send(HttpServletRequest request, HttpServletResponse response, String index, String status,String isPay) {
		ModelAndView view = new ModelAndView("dinner/send/send");
		view.addObject("breadcrumb", "外卖管理");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (status != null && status.trim().length() > 0) {
			criteria.andSendStatusEqualTo(status);
		}
		if (isPay != null && isPay.trim().length() > 0) {
			criteria.andIspayEqualTo(isPay);
		}
		
		criteria.andTypeNotEqualTo(1);	//不是堂食
		criteria.andAcceptEqualTo(1);
		criteria.andSendMeEqualTo(UserUtils.getLoginUser(request).getRestId());
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("status", status);
		view.addObject("isPay", isPay);
		view.addObject("list", dcOrderService.queryList(query));

		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("send", Paramenter.getInstance().getSendStatusForMap()); // 接受状态
		view.addObject("send_", Paramenter.getInstance().getSendStatus()); // 接受状态
		view.addObject("query", query);
		
		return view;
	}
	
	//提交派送
	@RequestMapping(value = "/submitSend.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "send")
	public void submitSend(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcOrderService.submitSend(Integer.parseInt(id),2);
		this.outJson(response, JsonUtil.toJson(new Result<String>("请求成功！")));
	}
	
	//外卖分配(管理)
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String index, String submit,String sourceType,String isPay) {
		ModelAndView view = new ModelAndView("dinner/send/manager");
		view.addObject("breadcrumb", "外卖管理");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (submit != null &&submit.trim().length() > 0) {
			criteria.andSubmitEqualTo(Integer.parseInt(submit));
		}
		if (sourceType != null && sourceType.trim().length() > 0) {
			criteria.andSourceTypeEqualTo(Integer.parseInt(sourceType));
		}
		if (isPay != null && isPay.trim().length() > 0) {
			criteria.andIspayEqualTo(isPay);
		}
		
		criteria.andTypeNotEqualTo(1);	//不是堂食
		criteria.andRestIdEqualTo(UserUtils.getLoginUser(request).getRestId());
		
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("submit", submit);
		view.addObject("isPay", isPay);
		view.addObject("sourceType", sourceType);
		view.addObject("list", dcOrderService.queryList(query));

		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("accept", Paramenter.getInstance().getAcceptStatusForMap()); // 接受状态
		view.addObject("accept_", Paramenter.getInstance().getAcceptStatus()); // 接受状态
		view.addObject("query", query);
		
		return view;
	}

	//提交派送
	@RequestMapping(value = "/sendSend.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void sendSend(String id,String yesno, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcOrderService.sendSend(Integer.parseInt(id),yesno);
		this.outJson(response, JsonUtil.toJson(new Result<String>("请求成功！")));
	}
	
	//派送请求受理(管理)
	@RequestMapping(value = "/manageri.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView manageri(HttpServletRequest request, HttpServletResponse response, String index, String sendRestStatus,String isPay) {
		ModelAndView view = new ModelAndView("dinner/send/manageri");
		view.addObject("breadcrumb", "派送请求受理");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (sendRestStatus != null &&sendRestStatus.trim().length() > 0) {
			criteria.andSendRestStatusEqualTo(Integer.parseInt(sendRestStatus));
		}
		if (isPay != null && isPay.trim().length() > 0) {
			criteria.andIspayEqualTo(isPay);
		}
		
		criteria.andSubmitEqualTo(1);	//必须提交申请
		
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("sendRestStatus", sendRestStatus);
		view.addObject("isPay", isPay);
		view.addObject("list", dcOrderService.querySubmitList(query));
		view.addObject("joinType", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("accept", Paramenter.getInstance().getAcceptStatusForMap()); // 接受状态
		view.addObject("accept_", Paramenter.getInstance().getAcceptStatus()); // 接受状态
		view.addObject("query", query);
		
		return view;
	}
	
	//派送受理
	@RequestMapping(value = "/dealOrder.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void dealOrder(String id, String status,HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcOrderService.dealOrder(Integer.parseInt(id),status);
		this.outJson(response, JsonUtil.toJson(new Result<String>("请求成功！")));
	}
	
	//派送管理(管理)
	@RequestMapping(value = "/managers.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView managers(HttpServletRequest request, HttpServletResponse response, String index, String sendRestStatus,String sendStatus,String isPay) {
		ModelAndView view = new ModelAndView("dinner/send/managers");
		view.addObject("breadcrumb", "派送请求受理");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (sendRestStatus != null &&sendRestStatus.trim().length() > 0) {
			criteria.andSendRestStatusEqualTo(Integer.parseInt(sendRestStatus));
		}
		
		if (sendStatus != null &&sendStatus.trim().length() > 0) {
			criteria.andSendStatusEqualTo(Integer.parseInt(sendStatus));
		}
		if (isPay != null && isPay.trim().length() > 0) {
			criteria.andIspayEqualTo(isPay);
		}
		
		criteria.andAcceptEqualTo(1);
		
		query.setPageNo(pageNo);
		query.setOrderByClause(" order_no desc ");
		view.addObject("sendRestStatus", sendRestStatus);
		view.addObject("sendStatus", sendStatus);
		view.addObject("isPay", isPay);
		view.addObject("list", dcOrderService.querySubmitList(query));
		view.addObject("joinType", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("yesNo_", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("send", Paramenter.getInstance().getSendStatusForMap()); // 接受状态
		view.addObject("send_", Paramenter.getInstance().getSendStatus()); // 接受状态
		view.addObject("accept", Paramenter.getInstance().getAcceptStatusForMap()); // 接受状态
		view.addObject("accept_", Paramenter.getInstance().getAcceptStatus()); // 接受状态
		view.addObject("query", query);
		
		return view;
	}

	//查看详情
	@RequestMapping(value = "/managerd.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView managerd(HttpServletRequest request, HttpServletResponse response, String id) {
		 return manager(request,response,id);
	}
	//派送人员
	
	//跳转外派人员
	@RequestMapping(value = "/setEmployee.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView getEmployee(HttpServletRequest request, HttpServletResponse response, String orderId,String name,String zone) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/send/setEmployee");
		view.addObject("breadcrumb", "指派人员");
		
		
		// 查询数据 显示分页
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (name != null &&name.trim().length() > 0) {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike(name);
		}
		if (zone != null && zone.trim().length() > 0) {
			zone = new String(zone.getBytes("ISO8859-1"),"UTF-8");
			criteria.andZoneLike(zone);
		}
		
		view.addObject("name", name);
		view.addObject("zone", zone);
		view.addObject("orderId", orderId);
		criteria.andUserIdEqualTo(UserUtils.getLoginUser(request).getUserId());
		criteria.andEmployeeTypeEqualTo(2);
		
		view.addObject("datas", dcOrderService.selectEmployee(query));
		view.addObject("rest", dcOrderService.selectRest(Integer.parseInt(orderId)));
		return view;
	}
	
	//指派员工
	@RequestMapping(value = "/setEmployee.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void setEmployee(HttpServletRequest request, HttpServletResponse response, String id,String orderId,String name) {
		dcOrderService.setEmployee(Integer.parseInt(id),Integer.parseInt(orderId),name);
		this.outJson(response, JsonUtil.toJson(new Result<String>("指派成功!")));
	}
	
	
	// 管理界面
	@RequestMapping(value = "/addOrder.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView addOrder(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/send/addOrder");
		view.addObject("breadcrumb", "新增外卖");

		view.addObject("order_no", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()));
		view.addObject("operate_id", UserUtils.getLoginUser(request).getName());
		
		view.addObject("rests", dcRestService.getAllRest());
		if (id != null) {
			DcOrder order = dcOrderService.selectByPrimaryKey(Integer.parseInt(id));
			view.addObject("data", order);
			view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));

			view.addObject("order_no", order.getOrder_no());
			view.addObject("operate_id", order.getOperate_id());
		}
		return view;
	}
	
	// 获取餐馆地址
	@RequestMapping(value = "/getRestAddress.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void getRestAddress(HttpServletRequest request, HttpServletResponse response, int restId) {
		DcRest selectById = dcRestService.selectById(restId);
		this.outJson(response, JsonUtil.toJson(new Result<String>(selectById!=null?selectById.getAddress():"")));
	}
	
	// 选菜界面
	@RequestMapping(value = "/menu.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView menu(HttpServletRequest request, HttpServletResponse response,int restId, String index, String code, String name, String type) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/send/menu");
		index = index == null ? "0" : index;
		// 查询数据 显示枫叶
		int pageNo = Integer.parseInt(index);

		DcMenuExample query = new DcMenuExample();
		DcMenuExample.Criteria createCriteria = (DcMenuExample.Criteria) query.createCriteria();
		if (name != null && name.trim().length() > 0) {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andNameLike("%"+name+"%");
		}
		if (type != null && type.trim().length() > 0) {
			createCriteria.andTypeEqualTo(type);
		}
		if (code != null && code.trim().length() > 0) {
			code = new String(code.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andCodeEqualTo(code);
		}
		createCriteria.andRestIdEqualTo(restId);
		query.setPageNo(pageNo);
		List<Map<String,Object>> list = dcMenuService.queryList(query);
		view.addObject("list", list);
		view.addObject("query", query);
		
		view.addObject("restId", restId);
		view.addObject("typeQ", type);
		view.addObject("name", name);
		view.addObject("code", code);

		view.addObject("type", Paramenter.getInstance().getType()); // 菜类型
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度

		return view;
	}
	
	// 保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void save(DcOrder dcOrder, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User loginUser = UserUtils.getLoginUser(request);
		dcOrder.setOperate_id(loginUser.getLoginName());
		dcOrder.setType(2);
		if(dcOrder.getId() == null){	//新增
			dcOrder.setRest_id(loginUser.getRestId());
			dcOrder.setSendRestStatus(0);
			dcOrderService.save(dcOrder);
		}else{
			dcOrderService.update(dcOrder);
		}
		List<DcOrderMenu> l = new ArrayList<DcOrderMenu>();
		String parameter = request.getParameter("result");
		String[] split = parameter.split(",");
		for (String r : split) {
			String[] split2 = r.split("\\|");
			DcOrderMenu dcOrderMenu = new DcOrderMenu();
			dcOrderMenu.setMenuId(Integer.parseInt(split2[0]));
			dcOrderMenu.setOrder_time(split2[1]);
			dcOrderMenu.setInsert_order_time(split2[2]);
			dcOrderMenu.setStatus(Integer.parseInt(split2[3]));
			dcOrderMenu.setNum(Integer.parseInt(split2[4]));
			dcOrderMenu.setOrder_id(dcOrder.getId());
			l.add(dcOrderMenu);
		}
		dcOrderService.updateMenu(dcOrder.getId(), l);
		dcOrderService.saveprice(dcOrder.getId());
		this.outJson(response, JsonUtil.toJson(new Result<String>(dcOrder.getId() + "")));
	}
	
	// 买单界面
	@RequestMapping(value = "/sell.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "sendManager")
	public ModelAndView sell(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/order/sell");
		view.addObject("breadcrumb", "买单管理");

		view.addObject("operate_id", UserUtils.getLoginUser(request).getName());
		view.addObject("data", dcOrderService.selectByPrimaryKey(Integer.parseInt(id)));
		view.addObject("datas", dcOrderService.selectMenuById(Integer.parseInt(id),null));

		return view;
	}
	
	// 买单
	@RequestMapping(value = "/savesell.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void savesell(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String order_id = request.getParameter("id");
		User loginUser = UserUtils.getLoginUser(request);
		try {
			dcOrderService.savesell(order_id, loginUser.getName());
			this.outJson(response, JsonUtil.toJson(new Result<String>("")));
		} catch (Exception e) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(1, e.getMessage())));
			e.printStackTrace();
		}
	}
	
	// 删除订单
	@RequestMapping(value = "/deleteOrder.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "sendManager")
	public void deleteOrder(HttpServletRequest request, HttpServletResponse response,int id) throws IOException {
		try {
			dcOrderService.deleteOrder(id);
			this.outJson(response, JsonUtil.toJson(new Result<String>("")));
		} catch (Exception e) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(1, e.getMessage())));
			e.printStackTrace();
		}
	}
}
