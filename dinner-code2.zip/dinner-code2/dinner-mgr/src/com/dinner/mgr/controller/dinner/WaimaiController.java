package com.dinner.mgr.controller.dinner;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.dinner.common.entity.DcOrderExample;
import com.dinner.common.entity.DcOrderExample.Criteria;
import com.dinner.common.service.biz.DcEmployeeService;
import com.dinner.common.service.biz.DcOrderService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 订单管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/waimai")
public class WaimaiController extends BaseController {

	@Resource
	private DcOrderService dcOrderService;
	
	@Resource
	private DcEmployeeService dcEmployeeService;

	// 查询订单
	@RequestMapping(value = "/order.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "waimai")
	public void getOrder(HttpServletRequest request, HttpServletResponse response,String status) {
		DcOrderExample query = new DcOrderExample();
		Criteria criteria = (Criteria) query.createCriteria();
		
		criteria.andSendManId(UserUtils.getLoginUser(request).getUserId());
		criteria.andSendStatusEqualTo(status);
		
		this.outJson(response, JsonUtil.toJson(dcOrderService.querySubmitList(query)));
	}

	// 查询订单菜列表
	@RequestMapping(value = "/getOrderDetail.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "waimai")
	public void getOrderDetail(HttpServletRequest request, HttpServletResponse response, int orderId) {
		this.outJson(response, JsonUtil.toJson(dcOrderService.selectMenuById(orderId,null)));
	}
	
	// 改变订单状态
	@RequestMapping(value = "/changeStatus.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "waimai")
	public void changeStatus(HttpServletRequest request, HttpServletResponse response, int status,int orderId) {
		dcOrderService.submitSend(orderId,status);
		 this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}
	
	@RequestMapping(value = "/updatePos.htm", method = RequestMethod.POST)
	@Permission(module = "home", privilege = "loginEmployee")
	public void updatePos(HttpServletRequest request, HttpServletResponse response, String longitude,String latitude,String id) throws Exception {
		dcEmployeeService.update(id,longitude,latitude);
		System.out.println("+++++longitude="+longitude+":::latitude"+latitude);
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	} 
}
