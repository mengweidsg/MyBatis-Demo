package com.dinner.mgr.controller.sys;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcUser;
import com.dinner.common.entity.DcUserExample;
import com.dinner.common.entity.DcUserExample.Criteria;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcUserService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 注册用户管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/reg")
public class RegController extends BaseController {

	@Resource
	private DcUserService dcUserService;
	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "sys", privilege = "regUser")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("sys/reg/index");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcUserExample query = new DcUserExample();
		Criteria criteria = query.createCriteria();
		if (q != null) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike(q);
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);	//合作性质
		List<DcUser> restaurant_list = dcUserService.queryUserList(query);
		view.addObject("user_list", restaurant_list);
		view.addObject("query", query);
		return view;
	}
	
	//客户管理
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "client")
	public ModelAndView manger(HttpServletRequest request, HttpServletResponse response, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("sys/reg/manager");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcUserExample query = new DcUserExample();
		Criteria criteria = query.createCriteria();
		
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			criteria.andRestIdEqualTo(loginUser.getRestId());
		}
		if (q != null) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike(q);
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);	//合作性质
		List<DcUser> restaurant_list = dcUserService.queryRestUserList(query);
		view.addObject("user_list", restaurant_list);
		view.addObject("query", query);
		return view;
	}
	
	//保存折扣
	@RequestMapping(value = "/saveSale.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "client")
	public void checkWorkId(String name, HttpServletRequest request, HttpServletResponse response,String sale,String userId) throws IOException {
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			boolean result = dcUserService.saveSale(loginUser.getRestId(),sale,userId);
			this.outJson(response, JsonUtil.toJson(new Result<String>(result?0:Result.ERROR,"")));
		}else{
			this.outJson(response, JsonUtil.toJson(new Result<String>(Result.ERROR,"当前用户不能设置折扣")));
		}
		
	}
}
