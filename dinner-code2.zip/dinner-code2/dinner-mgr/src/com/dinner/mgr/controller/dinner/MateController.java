package com.dinner.mgr.controller.dinner;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcMate;
import com.dinner.common.entity.DcMateExample;
import com.dinner.common.entity.DcMateExample.Criteria;
import com.dinner.common.entity.DcMatePrice;
import com.dinner.common.entity.DcMatePriceExample;
import com.dinner.common.entity.DcNetBuyMate;
import com.dinner.common.entity.DcNetBuyMateExample;
import com.dinner.common.entity.LogMate;
import com.dinner.common.entity.LogMateExample;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcMatePriceService;
import com.dinner.common.service.biz.DcMateService;
import com.dinner.common.service.biz.DcNetBuyMateService;
import com.dinner.common.service.biz.LogMateService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 食材管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/mate")
public class MateController extends BaseController {

	@Resource
	private DcMateService dcMateService;
	
	@Resource
	private LogMateService logMateService;
	
	@Resource
	private DcNetBuyMateService dcNetBuyMateService;
	
	@Resource
	private DcMatePriceService dcMatePriceService;

	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mateManager")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/mate/index");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcMateExample query = new DcMateExample();
		DcMateExample.Criteria criteria = (Criteria) query.createCriteria();
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			criteria.andRestIdEqualTo(loginUser.getRestId());
		}
		if (q != null&& q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andMateIdLike("%"+q+"%");
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);
		view.addObject("list", dcMateService.queryList(query));
		view.addObject("query", query);
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		return view;
	}
	
	//线下补货
	@RequestMapping(value = "/buyself.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mateManager")
	public ModelAndView buyself(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView view = new ModelAndView("dinner/mate/buyself");
		view.addObject("mate", Paramenter.getInstance().getMate()); // 食材
		return view;
	}
	
	//保存线下补货
	@RequestMapping(value = "/buyself.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mateManager")
	public void savebuyself(HttpServletRequest request, HttpServletResponse response, String mateId, int addNum,double money,String remark) {
		User loginUser = UserUtils.getLoginUser(request);
		
		DcMate dcMate = new DcMate();
		dcMate.setRestId(loginUser.getRestId());
		dcMate.setMateId(mateId);
		dcMate.setLastBuy(addNum);
		dcMate.setLastBuyDate(new Date());
		dcMate.setLastBuyMoney(new BigDecimal(money));
		dcMate.setKucun(addNum);
		
		LogMate lm = new LogMate();
		lm.setAddNum(addNum);
		lm.setAddMoney(new BigDecimal(money));
		lm.setRestId(loginUser.getRestId());
		lm.setRemark(remark);
		lm.setAddType(0);
		lm.setMateId(mateId);
		
		dcMateService.save(dcMate,lm);
		
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}
	
	//更正库存
	@RequestMapping(value = "/update.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mateManager")
	public void update(HttpServletRequest request, HttpServletResponse response,String dataId,String kucun) {
		dcMateService.updateKucun(dataId,kucun);
		this.outJson(response, JsonUtil.toJson(new Result<String>("")));
	}
	
	//查看购买历史
	@RequestMapping(value = "/history.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mateManager")
	public ModelAndView history(HttpServletRequest request, HttpServletResponse response,String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/mate/history");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		LogMateExample query = new LogMateExample();
		LogMateExample.Criteria criteria = (LogMateExample.Criteria) query.createCriteria();
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			criteria.andRestIdEqualTo(loginUser.getRestId());
		}
		if (q != null&& q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andMateIdLike( "%"+q+"%");
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);
		view.addObject("list", logMateService.queryList(query));
		view.addObject("query", query);
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		return view;
	}
	
	//网上购买
	@RequestMapping(value = "/buynet.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mateManager")
	public ModelAndView buynet(HttpServletRequest request, HttpServletResponse response, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/mate/buynet");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcNetBuyMateExample query = new DcNetBuyMateExample();
		DcNetBuyMateExample.Criteria criteria = (DcNetBuyMateExample.Criteria) query.createCriteria();
		
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			criteria.andRestIdEqualTo(loginUser.getRestId());
		}
		if (q != null&& q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andMateLike("%"+q+"%");
		}
		query.setOrderByClause(" dnbm.id desc ");
		query.setPageNo(pageNo);
		view.addObject("q", q);
		view.addObject("list", dcNetBuyMateService.queryList(query));
		view.addObject("query", query);
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		view.addObject("mateStatus_", Paramenter.getInstance().getAcceptStatusForMap()); // 食材受理
		view.addObject("mateStatus", Paramenter.getInstance().getAcceptStatus()); // 食材受理
		return view;
	}
	
	//受理管理界面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mate")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String index, String mateName) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/mate/manager");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcNetBuyMateExample query = new DcNetBuyMateExample();
		DcNetBuyMateExample.Criteria criteria = (DcNetBuyMateExample.Criteria) query.createCriteria();
		if (mateName != null&& mateName.trim().length() != 0) {
			mateName = new String(mateName.getBytes("ISO8859-1"),"UTF-8");
			criteria.andMateLike(mateName);
		}
		query.setOrderByClause(" field(dnbm.status,0,-1,1,2),dnbm.id desc ");
		query.setPageNo(pageNo);
		view.addObject("mateName", mateName);
		view.addObject("list", dcNetBuyMateService.queryList(query));
		view.addObject("query", query);
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		view.addObject("mateStatus_", Paramenter.getInstance().getAcceptStatusForMap()); // 食材受理
		view.addObject("mateStatus", Paramenter.getInstance().getAcceptStatus()); // 食材受理
		return view;
	}
	
	//食材单价界面
	@RequestMapping(value = "/price.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mate")
	public ModelAndView price(HttpServletRequest request, HttpServletResponse response, String index, String mateName) {
		ModelAndView view = new ModelAndView("dinner/mate/price");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcMatePriceExample query = new DcMatePriceExample();
		DcMatePriceExample.Criteria criteria = (DcMatePriceExample.Criteria) query.createCriteria();
		if (mateName != null&& mateName.trim().length() != 0) {
			criteria.andMateLike(mateName);
		}
		query.setPageNo(pageNo);
		view.addObject("list", dcMatePriceService.queryList(query));
		view.addObject("query", query);
		view.addObject("mateName", mateName);
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		return view;
	}
	
	//编辑单价页面
	@RequestMapping(value = "/editPrice.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mate")
	public ModelAndView editPrice( HttpServletRequest request, HttpServletResponse response,String id){
		ModelAndView view = new ModelAndView("dinner/mate/editPrice");
		view.addObject("title", "新增");
		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材
		if (id != null) {
			view.addObject("title", "修改");
			view.addObject("data", dcMatePriceService.selectById(Integer.parseInt(id)));
		}
		return view;
	}

	//保存单价
	@RequestMapping(value = "/editPrice.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mate")
	public void saveEditPrice(DcMatePrice price, HttpServletRequest request, HttpServletResponse response) throws IOException {
		if (price != null) {
			if (price.getId() != null) {
				dcMatePriceService.update(price);
			} else {
				dcMatePriceService.save(price);
			}
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}
	
	//删除
	@RequestMapping(value = "/deletePrice.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mate")
	public void deletePrice(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcMatePriceService.delete(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
	}
	
	//校验食材单价唯一
	@RequestMapping(value = "/checkMateId.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mate")
	public void checkMateId(String id,String mateId, HttpServletRequest request, HttpServletResponse response) throws IOException {
		DcMatePriceExample query = new DcMatePriceExample();
		DcMatePriceExample.Criteria criteria = (DcMatePriceExample.Criteria) query.createCriteria();
		if (mateId != null&& mateId.trim().length() != 0) {
			criteria.andMateIdEqualTo(mateId);
		}
		if (id != null&& id.trim().length() != 0) {
			criteria.andIdEqualTo(Integer.parseInt(id));
		}
		boolean result = dcMatePriceService.checkMateId(query);
		this.outJson(response, JsonUtil.toJson(new Result<String>(result?0:Result.ERROR,"")));
	}

	//网上购买
	@RequestMapping(value = "/buy.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "mateManager")
	public ModelAndView buy(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView view = new ModelAndView("dinner/mate/buy");
		DcMatePriceExample example = new DcMatePriceExample();
		example.setOrderByClause("sp.topValue ");
		view.addObject("mate", dcMatePriceService.queryList(example)); // 食材
		view.addObject("mate_", Paramenter.getInstance().getMateForMap()); // 食材
		return view;
	}

	//食材信息
	@RequestMapping(value = "/mateInfo.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mateManager")
	public void mateInfo(HttpServletRequest request, HttpServletResponse response,String mateId) {
		User loginUser = UserUtils.getLoginUser(request);
		this.outJson(response, JsonUtil.toJson(dcMateService.getMateInfo(mateId,loginUser.getRestId())));
	}
	
	//网上购买
	@RequestMapping(value = "/buy.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mateManager")
	public void savebuy(DcNetBuyMate dcNetBuyMate,HttpServletRequest request, HttpServletResponse response) {
		if (dcNetBuyMate != null) {
			User loginUser = UserUtils.getLoginUser(request);
			dcNetBuyMate.setAddTime(new Date());
			dcNetBuyMate.setDealTime(null);
			dcNetBuyMate.setSubmitTime(null);
			dcNetBuyMate.setStatus(0);
			dcNetBuyMate.setRestId(loginUser.getRestId());
			dcNetBuyMateService.save(dcNetBuyMate);
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}

	//删除已定的网上购买
	@RequestMapping(value = "/changeStatus.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mateManager")
	public void changeStatus(String id,String status,HttpServletRequest request, HttpServletResponse response) {
		changeStatusManager(id,status,request,response);
	}
	
	//删除已定的网上购买
	@RequestMapping(value = "/changeStatusManager.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mate")
	public void changeStatusManager(String id,String status,HttpServletRequest request, HttpServletResponse response) {
		if (id != null) {
			User loginUser = UserUtils.getLoginUser(request);
			int result = dcNetBuyMateService.changeStatus(Integer.parseInt(id),Integer.parseInt(status),loginUser.getRestId());
			
			String msg = "";
			if(result == -4){
				msg = "当前数据已经被处理，请刷新后再试.";
			}
			this.outJson(response, JsonUtil.toJson(new Result<String>(result,msg)));
		}
	}
	
	//hasNewData.htm
	@RequestMapping(value = "/hasNewData.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "mate")
	public void hasNewData(String datatime,HttpServletRequest request, HttpServletResponse response) {
		DcNetBuyMateExample query = new DcNetBuyMateExample();
		DcNetBuyMateExample.Criteria criteria = (DcNetBuyMateExample.Criteria) query.createCriteria();
		
		if (datatime != null&& datatime.trim().length() != 0) {
			criteria.andAddTimeGreaterThan(Long.parseLong(datatime));
		}
		boolean result = dcNetBuyMateService.hasNewData(query);
		this.outJson(response, JsonUtil.toJson(new Result<String>(result?Result.ERROR:0,"")));
		
	}
}
