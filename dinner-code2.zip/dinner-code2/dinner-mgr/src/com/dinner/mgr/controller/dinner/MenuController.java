package com.dinner.mgr.controller.dinner;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcMateMenu;
import com.dinner.common.entity.DcMenu;
import com.dinner.common.entity.DcMenuExample;
import com.dinner.common.entity.DcMenuExample.Criteria;
import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.DcRestExample;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcMenuService;
import com.dinner.common.service.biz.DcRestService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 菜单管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年8月3日 下午7:29:57
 */
@Controller
@RequestMapping("/menu")
public class MenuController extends BaseController {

	@Resource
	private DcMenuService dcMenuService;

	@Resource
	private DcRestService dcRestService;

	// 首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "menu")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String restName, String name, String type) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/menu/index");
		index = index == null ? "0" : index;
		// 查询数据 显示枫叶
		int pageNo = Integer.parseInt(index);

		DcMenuExample query = new DcMenuExample();
		Criteria createCriteria = (Criteria) query.createCriteria();
		if (name != null && name.trim().length() > 0) {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andNameLike("%"+name+"%");
		}
		if (type != null && type.trim().length() > 0) {
			createCriteria.andTypeEqualTo(type);
		}
		if (restName != null && restName.trim().length() > 0) {
			restName = new String(restName.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andRestNameLike("%"+restName+"%");
		}
		query.setPageNo(pageNo);
		List<Map<String, Object>> list = dcMenuService.queryList(query);
		view.addObject("list", list);
		view.addObject("query", query);
		
		view.addObject("restName",restName);
		view.addObject("typeQ", type);
		view.addObject("name", name);

		view.addObject("type", Paramenter.getInstance().getType()); // 菜类型
		view.addObject("type_", Paramenter.getInstance().getTypeForMap()); // 菜类型
		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
		view.addObject("series", Paramenter.getInstance().getSeriesForMap()); // 菜系列

		return view;
	}

	// 查询餐厅名称
	@RequestMapping(value = "/queryRest.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "menu")
	public void saveRest(HttpServletRequest request, HttpServletResponse response, String name) {
		DcRestExample query = new DcRestExample();
		query.setPageNo(0);
		com.dinner.common.entity.DcRestExample.Criteria criteria = (com.dinner.common.entity.DcRestExample.Criteria) query.createCriteria();
		if (name != null) {
			criteria.andNameLike("%" + name + "%");
		}
		List<DcRest> queryRestList = dcRestService.queryList(query);

		this.outJson(response, JsonUtil.toJson(queryRestList));
	}

	// 管理首页
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "menuManager")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String index, String code, String name, String type) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/menu/manager");
		index = index == null ? "0" : index;
		// 查询数据 显示枫叶
		int pageNo = Integer.parseInt(index);

		DcMenuExample query = new DcMenuExample();
		Criteria createCriteria = (Criteria) query.createCriteria();
		if (name != null && name.trim().length() > 0) {
			name = new String(name.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andNameLike("%"+name+"%");
		}
		if (type != null && type.trim().length() > 0) {
			createCriteria.andTypeEqualTo(type);
		}
		if (code != null && code.trim().length() > 0) {
			code = new String(code.getBytes("ISO8859-1"),"UTF-8");
			createCriteria.andCodeEqualTo(code);
		}
		
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			createCriteria.andRestIdEqualTo(loginUser.getRestId());
		}
		query.setPageNo(pageNo);
		List<Map<String, Object>> list = dcMenuService.queryList(query);
		view.addObject("list", list);
		view.addObject("query", query);
		
		view.addObject("name", name);
		view.addObject("typeQ", type);
		view.addObject("code", code);

		view.addObject("type", Paramenter.getInstance().getType()); // 菜类型
		view.addObject("type_", Paramenter.getInstance().getTypeForMap()); // 菜类型
		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
		view.addObject("series", Paramenter.getInstance().getSeriesForMap()); // 菜系列

		return view;
	}

	// 编辑
	@RequestMapping(value = "/edit.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "menuManager")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/menu/edit");
		view.addObject("title", "新增");

		view.addObject("type", Paramenter.getInstance().getType()); // 菜类型
		view.addObject("yesNo", Paramenter.getInstance().getYesNo()); // 是否
		view.addObject("hot", Paramenter.getInstance().getHot()); // 辣程度
		view.addObject("series", Paramenter.getInstance().getSeries()); // 菜系列

		view.addObject("mate_", Paramenter.getInstance().getMate()); // 食材
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材

		if (id != null) {
			DcMenu selectById = dcMenuService.selectById(Integer.parseInt(id));
			view.addObject("data", selectById);
			view.addObject("title", "修改");
		}
		return view;
	}

	// 编辑
	@RequestMapping(value = "/view.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "menu")
	public ModelAndView view(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/menu/view");
		view.addObject("title", "查看");

		view.addObject("type", Paramenter.getInstance().getTypeForMap()); // 菜类型
		view.addObject("yesNo", Paramenter.getInstance().getYesNoForMap()); // 是否
		view.addObject("hot", Paramenter.getInstance().getHotForMap()); // 辣程度
		view.addObject("series", Paramenter.getInstance().getSeriesForMap()); // 菜系列
		view.addObject("mate", Paramenter.getInstance().getMateForMap()); // 食材

		view.addObject("data", dcMenuService.selectById(Integer.parseInt(id)));
		return view;
	}

	// 图片上传
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/upload.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "menuManager")
	public void uploadFile(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String realPath = request.getRealPath("");
		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		final Map<String, MultipartFile> files = multiRequest.getFileMap();

		File f = new File(realPath + "/uploadFile/menu");
		if (!f.exists()) {
			f.mkdirs();
		}
		SimpleDateFormat dataformat = new SimpleDateFormat("yyyyMMddHHmmss");
		String format = dataformat.format(new Date()) + ".png";
		if (files.values().size() > 0) {
			MultipartFile file = (MultipartFile) files.values().toArray()[0];
			InputStream inputStream = file.getInputStream();
			FileUtils.copyInputStreamToFile(inputStream, new File(f, format));
			inputStream.close();
		}
		this.outJson(response, "{\"path\":\"../uploadFile/menu/" + format + "\"}");
	}

	// 保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "menuManager")
	public void saveRest(DcMenu menu, String mateIds, String uses, HttpServletRequest request, HttpServletResponse response) throws IOException {

		if (menu != null) {
			User loginUser = UserUtils.getLoginUser(request);
			String[] mateId = mateIds.split(",");
			String[] use = uses.split(",");
			List<DcMateMenu> list = new ArrayList<DcMateMenu>();
			for (int i = 0; i < mateId.length; i++) {
				DcMateMenu dmm = new DcMateMenu();
				dmm.setMateId(mateId[i]);
				dmm.setUses(Integer.parseInt(use[i]));
				dmm.setRestId(loginUser.getRestId());
				list.add(dmm);
			}

			menu.setRestId(loginUser.getRestId());

			menu.setDcMateMenus(list);
			if (menu.getId() != null) {
				dcMenuService.update(menu);
			} else {
				dcMenuService.save(menu);
			}
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}

	// 校验菜单编号不能重复
	@RequestMapping(value = "/checkCode.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "menuManager")
	public void checkCode(String id, String code, HttpServletRequest request, HttpServletResponse response) throws IOException {
		DcMenuExample query = new DcMenuExample();
		Criteria createCriteria = (Criteria) query.createCriteria();
		if (code != null && code.trim().length() > 0) {
			createCriteria.andCodeEqualTo(code);
		}
		if (id != null && id.trim().length() > 0) {
			createCriteria.andIdEqualTo(Integer.parseInt(id));
		}
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			createCriteria.andRestIdEqualTo(loginUser.getRestId());
		}

		boolean result = dcMenuService.checkCode(query);
		this.outJson(response, JsonUtil.toJson(new Result<String>(result ? 0 : Result.ERROR, "")));
	}

	// 删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "menuManager")
	public void saveRest(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcMenuService.delete(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
	}
}
