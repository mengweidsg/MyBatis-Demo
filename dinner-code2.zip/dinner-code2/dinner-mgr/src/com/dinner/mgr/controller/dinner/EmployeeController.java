package com.dinner.mgr.controller.dinner;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcEmployee;
import com.dinner.common.entity.DcEmployeeExample;
import com.dinner.common.entity.DcEmployeeExample.Criteria;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcEmployeeService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 人员管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/employee")
public class EmployeeController extends BaseController {

	@Resource
	private DcEmployeeService dcEmployeeService;

	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "employee")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String q,String q_type) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/employee/index");
		
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcEmployeeExample query = new DcEmployeeExample();
		DcEmployeeExample.Criteria criteria = (Criteria) query.createCriteria();
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			criteria.andRestIdEqualTo(loginUser.getRestId());
		}
		
		if (q != null&& q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike("%"+q+"%");
		}
		if (q_type != null && q_type.trim().length() != 0) {
			criteria.andEmployeeTypeEqual(q_type);
		}
		query.setPageNo(pageNo);
		view.addObject("q_type", q_type);
		view.addObject("q", q);
		
		view.addObject("employeeType_list", Paramenter.getInstance().getEmployeeType());	//员工类型
		view.addObject("employeeType", Paramenter.getInstance().getEmployeeTypeForMap());	//合作性质
		view.addObject("sex", Paramenter.getInstance().getSexForMap());	//合作性质
		
		List<DcEmployee> employee_list = dcEmployeeService.queryEmployeeList(query);
		view.addObject("employee_list", employee_list);
		view.addObject("query", query);
		return view;
	}
	
	//管理界面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "employee")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("dinner/employee/manager");
		view.addObject("title", "新增");
		
		view.addObject("sex", Paramenter.getInstance().getSex());	//合作性质
		view.addObject("employeeType", Paramenter.getInstance().getEmployeeType());	//特色
		
		if (id != null) {
			DcEmployee selectById = dcEmployeeService.selectById(Integer.parseInt(id));
			view.addObject("data", selectById);
			view.addObject("title", "修改");
		}
		return view;
	}

	//保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "employee")
	public void saveRest(DcEmployee rest, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null) {
			rest.setRestId(loginUser.getRestId());
		}
		if (rest != null) {
			if (rest.getId() != null) {
				dcEmployeeService.update(rest);
			} else {
				dcEmployeeService.save(rest);
			}
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}
	
	//删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "employee")
	public void delete(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		dcEmployeeService.delete(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
	}
	
}
