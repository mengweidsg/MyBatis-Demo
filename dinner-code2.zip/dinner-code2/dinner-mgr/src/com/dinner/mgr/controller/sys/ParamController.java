package com.dinner.mgr.controller.sys;

import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.SysParam;
import com.dinner.common.service.biz.SysParamService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 数字字典管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/param")
public class ParamController extends BaseController {

	@Resource
	private SysParamService sysParamService;

	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "sys", privilege = "param")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response,String tab) {
		List<SysParam> rootParam = Paramenter.getInstance().getRootParam();
		if(tab==null || tab.trim().length() == 0){
			tab = rootParam.get(0).getCodeKey();
		}
		ModelAndView view = new ModelAndView("sys/param/index");
		view.addObject("tabs", rootParam);
		view.addObject("tab", tab);
		view.addObject("data", sysParamService.getParam(tab));
		return view;
	}

	//新增页面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "sys", privilege = "param")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response,String tab,String id) {
		ModelAndView view = new ModelAndView("sys/param/manager");
		view.addObject("tab", tab);
		List<SysParam> rootParam = Paramenter.getInstance().getRootParam();
		for(SysParam p :rootParam){
			if(p.getCodeKey().equals(tab)){
				view.addObject("tabName", p.getCodeValue());
			}
		}
		view.addObject("operate", "添加");
		if (id != null) {
			SysParam selectById = sysParamService.selectById(Integer.parseInt(id));
			view.addObject("data", selectById);
			view.addObject("operate", "保存");
		}
		return view;
	}
	
	
	//保存信息
	@RequestMapping(value = "/manager.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "param")
	public ModelAndView save(HttpServletRequest request, HttpServletResponse response,SysParam param) {
		if (param != null) {
			if (param.getId() != null) {
				sysParamService.update(param);
			} else {
				sysParamService.save(param);

			}
		}
		//更新内存
		Paramenter.getInstance().reload();
		return index(request,response,param.getName());
	}
	
	//删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "param")
	public void delete(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		sysParamService.delParam(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
	}
}
