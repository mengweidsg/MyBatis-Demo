package com.dinner.mgr.controller.dinner;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.DcRestExample;
import com.dinner.common.entity.DcRestExample.Criteria;
import com.dinner.common.entity.User;
import com.dinner.common.service.biz.DcRestService;
import com.dinner.common.service.biz.UserService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 餐厅管理Controller
 * 
 * @author 攻心小虫
 * @create 2014年7月22日 下午7:29:57
 */
@Controller
@RequestMapping("/restaurant")
public class RestaurantController extends BaseController {

	@Resource
	private DcRestService dcRestService;
	@Resource
	private UserService userService;
	//首页
	@RequestMapping(value = "/index.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "restaurant")
	public ModelAndView index(HttpServletRequest request, HttpServletResponse response, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("dinner/restaurant/index");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcRestExample query = new DcRestExample();
		Criteria criteria = (Criteria) query.createCriteria();
		if (q != null) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike("%"+q+"%");
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);	//合作性质
		view.addObject("joinType", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		List<DcRest> restaurant_list = dcRestService.queryList(query);
		view.addObject("restaurant_list", restaurant_list);
		view.addObject("query", query);
		return view;
	}
	
	//管理界面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "restaurant")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id,String isinfo) {
		ModelAndView view = new ModelAndView("dinner/restaurant/manager");
		view.addObject("title", "新增");
		view.addObject("isinfo", isinfo);
		
		view.addObject("joinType", Paramenter.getInstance().getJoinType());	//合作性质
		view.addObject("features", Paramenter.getInstance().getFeatures());	//特色
		view.addObject("businessZone", Paramenter.getInstance().getBusinessZone());	//商圈
		
		if (id != null) {
			DcRest selectById = dcRestService.selectById(Integer.parseInt(id));
			view.addObject("data", selectById);
			view.addObject("title", "修改");
		}
		return view;
	}

	//上传图片
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/uploadPic.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "restaurant,restInfo")
	
	public void uploadFile(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String realPath = request.getRealPath("");
		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		final Map<String, MultipartFile> files = multiRequest.getFileMap();

		File f = new File(realPath + "/uploadFile/rest");
		if (!f.exists()) {
			f.mkdirs();
		}
		SimpleDateFormat dataformat = new SimpleDateFormat("yyyyMMddHHmmss");
		String format = dataformat.format(new Date()) + ".png";
		if (files.values().size() > 0) {

			MultipartFile file = (MultipartFile) files.values().toArray()[0];
			InputStream inputStream = file.getInputStream();
			FileUtils.copyInputStreamToFile(inputStream, new File(f, format));
			inputStream.close();
		}
		this.outJson(response, "{\"path\":\"../uploadFile/rest/" + format + "\"}");
	}
	
	//保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "restaurant")
	public void saveRest(DcRest rest, HttpServletRequest request, HttpServletResponse response) throws IOException {
		if (rest != null) {
			if (rest.getId() != null) {
				dcRestService.update(rest);
			} else {
				dcRestService.save(rest);
			}
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}
	
	//删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "restaurant")
	public void delete(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		int count = userService.getUserByRestId(Integer.parseInt(id));
		if(count >0){
			this.outJson(response, JsonUtil.toJson(new Result<String>(1,"该餐厅已有用户存在。不能删除")));
		}else{
			dcRestService.delete(Integer.parseInt(id));
			this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
		}
	}

	//餐厅详细页
	@RequestMapping(value = "/info.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "restInfo")
	public ModelAndView info(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView view = new ModelAndView("dinner/restaurant/info");
		
		view.addObject("joinType", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		view.addObject("features", Paramenter.getInstance().getFeaturesForMap());	//特色
		view.addObject("businessZone", Paramenter.getInstance().getBusinessZoneForMap());	//商圈
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getRestId() != null && loginUser.getRestId() != 0) {
			DcRest selectById = dcRestService.selectById(loginUser.getRestId());
			view.addObject("data", selectById);
		}
		return view;
	}
	
	
	//餐厅详细页
	@RequestMapping(value = "/editInfo.htm", method = RequestMethod.GET)
	@Permission(module = "dinner", privilege = "restInfo")
	public ModelAndView editInfo(HttpServletRequest request, HttpServletResponse response, String id,String isinfo) {
		ModelAndView view = new ModelAndView("dinner/restaurant/manager");
		view.addObject("title", "新增");
		view.addObject("isinfo", isinfo);
		
		view.addObject("joinType", Paramenter.getInstance().getJoinType());	//合作性质
		view.addObject("features", Paramenter.getInstance().getFeatures());	//特色
		view.addObject("businessZone", Paramenter.getInstance().getBusinessZone());	//商圈
		view.addObject("joinType_", Paramenter.getInstance().getJoinTypeForMap());	//合作性质
		if (id != null) {
			DcRest selectById = dcRestService.selectById(Integer.parseInt(id));
			view.addObject("data", selectById);
			view.addObject("title", "修改");
		}
		return view;
	}
	
	//餐厅详细页
	@RequestMapping(value = "/saveInfo.htm", method = RequestMethod.POST)
	@Permission(module = "dinner", privilege = "restInfo")
	public void saveInfo(DcRest rest, HttpServletRequest request, HttpServletResponse response) throws IOException {
		saveRest(rest,request,response);
	}
	
}
