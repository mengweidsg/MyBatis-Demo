package com.dinner.mgr.controller.sys;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.DcRoleExample;
import com.dinner.common.service.biz.RoleService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 角色Controller
 * 
 * @author admin
 * @create 2014年3月10日 下午7:01:12
 */
@Controller
@RequestMapping("/role")
public class RoleController extends BaseController {
	
    @Resource
    private RoleService roleService;
    
    //首页
    @RequestMapping("/index.htm")
    @Permission(module = "sys", privilege = "role")
    public ModelAndView index(HttpServletRequest request, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("sys/role/index");
		view.addObject("breadcrumb", "角色管理");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		DcRoleExample query = new DcRoleExample();
		DcRoleExample.Criteria criteria = (DcRoleExample.Criteria) query.createCriteria();
		criteria.andUserTopEqualTo(UserUtils.getLoginUser(request).getUserId());
		if (q != null&& q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike("%"+q+"%");
		}
		query.setPageNo(pageNo);
		view.addObject("q", q);
		
		view.addObject("list", roleService.queryList(query));
		view.addObject("query", query);
		return view;
    }

  //管理界面
  	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
  	@Permission(module = "sys", privilege = "role")
  	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id,String model) {
  		ModelAndView view = new ModelAndView("sys/role/manager");
  		view.addObject("breadcrumb", "角色管理");
  		view.addObject("model", model);
  		Integer userId = UserUtils.getLoginUser(request).getUserId();
  		if (id != null) {
  			view.addObject("data", roleService.selectByPrimaryKey(Integer.parseInt(id)));
  			if(userId == 1){
  				//管理员获取全部权限
  				view.addObject("priv", roleService.selectAllPrivByPrimaryKey(Integer.parseInt(id)));
  			}else {
  				view.addObject("priv", roleService.selectPrivByPrimaryKey(Integer.parseInt(id),userId));
  			}
  			view.addObject("users", roleService.selectUserByPrimaryKey(Integer.parseInt(id)));
  		}else{
  			if(userId == 1){
  				//管理员获取全部权限
  				view.addObject("priv", roleService.selectAllPrivByPrimaryKey());
  			}else {
  				view.addObject("priv", roleService.selectPrivByPrimaryKey(userId));
  			}
  		}
  		return view;
  	}
    
  	//保存
  	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
  	@Permission(module = "sys", privilege = "role")
  	public void saveRest(DcRole role, HttpServletRequest request, HttpServletResponse response) throws IOException {
  		if (role != null) {
  			role.setUptime(new Date());
  			role.setUserTop(UserUtils.getLoginUser(request).getUserId());
  		
  			List<Integer> l = new ArrayList<Integer>();
  			Enumeration<String> parameterNames = request.getParameterNames();
  			while(parameterNames.hasMoreElements()){
  				String nextElement = parameterNames.nextElement();
  				if(nextElement.startsWith("priv_")){
  					l.add(Integer.parseInt(nextElement.replace("priv_", "")));
  				}
  			}
  			for(int i=4;i<16;i++){
  				if(l.contains(i)){
  					l.add(1);
  					break;
  				}
  			}
  			for(int i=16;i<20;i++){
  				if(l.contains(i)){
  					l.add(2);
  					break;
  				}
  			}
  			for(int i=20;i<22;i++){
  				if(l.contains(i)){
  					l.add(3);
  					break;
  				}
  			}
  			if (role.getPostId() != null) {
  				roleService.update(role,l);
  			} else {
  				role.setCreateTime(new Date());
  				roleService.save(role,l);
  			}
  		}
  		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
  	}
  	
    
    
    
	//删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "role")
	public void delete(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		boolean delete = roleService.delete(Integer.parseInt(id));
		this.outJson(response, JsonUtil.toJson(new Result<String>(delete?0:1,delete?"删除成功！":"角色正在使用中,请先解除用户角色关系")));
	}
	
}
