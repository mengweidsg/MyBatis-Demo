package com.dinner.mgr.controller.sys;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.User;
import com.dinner.common.entity.UserExample;
import com.dinner.common.service.biz.DcEmployeeService;
import com.dinner.common.service.biz.DcRestService;
import com.dinner.common.service.biz.UserService;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.mgr.constants.Paramenter;
import com.dinner.mgr.controller.base.BaseController;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 用户Controller
 * 
 * @author admin
 * @create 2014年3月10日 下午7:01:12
 */
@Controller
@RequestMapping("/user")
public class UserController extends BaseController {

	@Resource
	private UserService userService;
	@Resource
	private DcRestService dcRestService;
	@Resource
	private DcEmployeeService dcEmployeeService;
	// 首页
	@RequestMapping("/index.htm")
	@Permission(module = "sys", privilege = "user")
	public ModelAndView index(HttpServletRequest request, String index, String q) throws UnsupportedEncodingException {
		ModelAndView view = new ModelAndView("sys/user/index");
		view.addObject("breadcrumb", "用户管理");
		index = index == null ? "0" : index;
		// 查询数据 显示分页
		int pageNo = Integer.parseInt(index);
		UserExample query = new UserExample();
		UserExample.Criteria criteria = (UserExample.Criteria) query.createCriteria();

		if (q != null && q.trim().length() != 0) {
			q = new String(q.getBytes("ISO8859-1"),"UTF-8");
			criteria.andNameLike("%" + q + "%");
		}
		criteria.andUserTopEqualTo(UserUtils.getLoginUser(request).getUserId());
		query.setPageNo(pageNo);
		view.addObject("q", q);
		view.addObject("employeeType", Paramenter.getInstance().getEmployeeTypeForMap());	//员工类型
		view.addObject("list", userService.queryList(query));
		view.addObject("query", query);
		return view;
	}

	// 管理界面
	@RequestMapping(value = "/manager.htm", method = RequestMethod.GET)
	@Permission(module = "sys", privilege = "user")
	public ModelAndView manager(HttpServletRequest request, HttpServletResponse response, String id) {
		ModelAndView view = new ModelAndView("sys/user/manager");
		view.addObject("breadcrumb", "用户管理");
		User loginUser = UserUtils.getLoginUser(request);
		view.addObject("employeeType", Paramenter.getInstance().getEmployeeTypeForMap());	//员工类型
		
		view.addObject("employeeType_", dcEmployeeService.queryAllEmployeeList(loginUser.getRestId()));	//员工类型
		
		if(loginUser.getUserId() == 1){
			//管理员 要全部餐厅
			view.addObject("roles", userService.getAllRole());
			view.addObject("rests", dcRestService.getAllRest());
		}else{
			view.addObject("roles", userService.getAllRole(loginUser.getUserId()));
			view.addObject("restId", loginUser.getRestId());
		}
		if (id != null) {
			view.addObject("data", userService.selectByPrimaryKey(Integer.parseInt(id)));
			view.addObject("role", userService.selectRole(Integer.parseInt(id)));
		}
		return view;
	}

	// 保存
	@RequestMapping(value = "/save.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "user")
	public void saveRest(User user,String roleId, HttpServletRequest request, HttpServletResponse response) throws IOException {
		if (user != null) {
			user.setUptime(new Date());
			user.setUserTop(UserUtils.getLoginUser(request).getUserId());
			if (user.getUserId() != null) {
				userService.update(user,roleId);
			} else {
				user.setCreateTime(new Date());
				userService.save(user,roleId);
			}
		}
		this.outJson(response, JsonUtil.toJson(new Result<String>("操作成功！")));
	}

	// 删除
	@RequestMapping(value = "/delete.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "user")
	public void delete(String id, HttpServletRequest request, HttpServletResponse response) throws IOException {
		User loginUser = UserUtils.getLoginUser(request);
		if (loginUser.getUserId() == Integer.parseInt(id)) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(1, "不能删除当前用户！")));
		} else {
			userService.delete(Integer.parseInt(id));
			this.outJson(response, JsonUtil.toJson(new Result<String>("删除成功！")));
		}
	}

	// 校验工号当前餐厅唯一
	@RequestMapping(value = "/checkLoginName.htm", method = RequestMethod.POST)
	@Permission(module = "sys", privilege = "user")
	public void checkLoginName(String id, String name, HttpServletRequest request, HttpServletResponse response) throws IOException {
		if (name == null || name.trim().length() == 0) {
			this.outJson(response, JsonUtil.toJson(new Result<String>(Result.ERROR, "登录名不能为空！")));
			return;
		} else {
			User byLoginName = userService.getByLoginName(name);
			if (byLoginName == null) {
				this.outJson(response, JsonUtil.toJson(new Result<String>("")));
			} else {
				if (id != null && id.trim().length() > 0) {
					if (byLoginName.getUserId() == Integer.parseInt(id)) {
						this.outJson(response, JsonUtil.toJson(new Result<String>("")));
					} else {
						this.outJson(response, JsonUtil.toJson(new Result<String>("")));
					}
				} else {
					this.outJson(response, JsonUtil.toJson(new Result<String>("")));
				}
			}
		}
	}
}
