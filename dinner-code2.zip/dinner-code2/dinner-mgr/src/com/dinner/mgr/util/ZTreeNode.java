
package com.dinner.mgr.util;

/**
 * jquery ZTree Node
 * @author admin
 * @create 2014年4月1日 下午10:32:37
 */
public class ZTreeNode {

    private int id;
    private int pId;
    private String name;
    private boolean open; // 节点是否打开
    private boolean checked; // 是否选中
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public int getpId() {
        return pId;
    }
    public void setpId(int pId) {
        this.pId = pId;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public boolean isOpen() {
        return open;
    }
    public void setOpen(boolean open) {
        this.open = open;
    }
    public boolean isChecked() {
        return checked;
    }
    public void setChecked(boolean checked) {
        this.checked = checked;
    }
    
}
