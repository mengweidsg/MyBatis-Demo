package com.dinner.mgr.util.annoation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * 许可注解:用于权限拦截
 * <p>
 * 在Controller中的方法上标注该注解,然后通过Spring Aop拦截这些方法从而控制用户权限
 * </p>
 * 
 * @author admin
 * @create 2014年2月18日 下午1:13:05
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Permission {

    /**
     * 模块名称
     * 
     * @return
     */
    public String module();

    /**
     * 权限
     * 
     * @return
     */
    public String privilege();
    
    /**
     * 描述
     * @return
     */
    public String desc() default "";

}
