package com.dinner.mgr.util;

import javax.servlet.http.HttpServletRequest;

import com.dinner.common.entity.User;
import com.dinner.common.exception.BizException;
import com.dinner.common.exception.ErrorCode;

public class SingleUserUtils {

	private static final String LOGINUSER_ID = "userId";
	private static final String LOGIN_USER = "user";

	/**
	 * 从Session中获取已登陆用户
	 * 
	 * @param request
	 * @return
	 */
	public static User getLoginUser(HttpServletRequest request) {
		User user = (User) request.getSession().getAttribute(LOGIN_USER);
		if (user != null) {
			if (request.getSession().getId().equals(user.getSessid())) {
				return user;
			} else {
				throw new BizException(ErrorCode.USER_LOGIN_ELSEWHERE);
			}
		}
		return null;
	}

	/**
	 * 把登陆用户保存到Session中
	 * 
	 * @param request
	 * @param user
	 */
	public static void saveLoginUser(HttpServletRequest request, User user) {
		request.getSession().invalidate(); // session 先置为无效
		request.getSession().setAttribute(LOGINUSER_ID, user.getUserId());
		user.setSessid(request.getSession().getId());
		request.getSession().setAttribute(LOGIN_USER, user);
	}

	/**
	 * 删除用户
	 * 
	 * @param request
	 */
	public static void removeUser(HttpServletRequest request) {
		request.getSession().invalidate();
	}
}
