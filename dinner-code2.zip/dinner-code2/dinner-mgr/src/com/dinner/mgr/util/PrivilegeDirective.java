package com.dinner.mgr.util;

import java.io.IOException;
import java.io.Writer;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.velocity.context.InternalContextAdapter;
import org.apache.velocity.exception.MethodInvocationException;
import org.apache.velocity.exception.ParseErrorException;
import org.apache.velocity.exception.ResourceNotFoundException;
import org.apache.velocity.runtime.directive.Directive;
import org.apache.velocity.runtime.parser.node.Node;
import org.apache.velocity.runtime.parser.node.SimpleNode;
import org.apache.velocity.tools.view.ViewToolContext;

import com.dinner.common.entity.Privilege;
import com.dinner.common.entity.User;

/**
 * Velocity 权限控制指令, 根据权限控制页面“按钮”是否显示
 * 
 * @author admin
 * @create 2014年2月24日 下午2:01:08
 */
public class PrivilegeDirective extends Directive {

	@Override
	public String getName() {
		return "permission";
	}

	@Override
	public int getType() {
		return BLOCK;
	}

	@Override
	public boolean render(InternalContextAdapter context, Writer writer, Node node) throws IOException, ResourceNotFoundException, ParseErrorException,
			MethodInvocationException {

		SimpleNode moduleNode = (SimpleNode) node.jjtGetChild(0);
		String module = (String) moduleNode.value(context);
		SimpleNode privilegeNode = (SimpleNode) node.jjtGetChild(1);
		String privilege = (String) privilegeNode.value(context);

		if (StringUtils.isBlank(module) || StringUtils.isBlank(privilege)) {
			return false;
		}

		ViewToolContext toolContext = (ViewToolContext) context.getInternalUserContext();
		User user = UserUtils.getLoginUser(toolContext.getRequest());
		List<Privilege> privileges = user.getPrivileges();
		for (Privilege p : privileges) {
			if (module.equals(p.getModule()) && privilege.equals(p.getPrivilege())) {
				// 渲染内容
				SimpleNode contentNode = (SimpleNode) node.jjtGetChild(2);
				contentNode.render(context, writer);
				return true;
			}
		}
		return false;
	}

}
