package com.dinner.mgr.intercept;

import java.lang.reflect.Method;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.Signature;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.User;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

@Component
@Aspect
public class IndexAspectJ {

	@Autowired(required = true)
	private HttpServletRequest request;

	@Pointcut("execution(org.springframework.web.servlet.ModelAndView com.dinner.mgr.controller..*.* (..))")
	public void cutController() {

	}

	@AfterReturning(pointcut = "cutController()", returning = "model")
	public void doAfterReturning(JoinPoint jp,ModelAndView model) {
		User user = UserUtils.getLoginUser(request);
		if (user != null) {
			
			Signature signature = jp.getSignature();
			MethodSignature methodSignature = (MethodSignature) signature;  
			Method method = methodSignature.getMethod();  
			
			Permission annotation = method.getAnnotation(Permission.class);
			if(annotation != null){
				model.addObject("root_curr", annotation.module());
				model.addObject("curr",annotation.module()+"/"+ annotation.privilege());
			}
			model.addObject("user", user);
			model.addObject("menus", user.getMenuTree());
		}
	}

}
