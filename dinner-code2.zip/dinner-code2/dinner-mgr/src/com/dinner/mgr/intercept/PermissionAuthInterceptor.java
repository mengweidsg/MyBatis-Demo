package com.dinner.mgr.intercept;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import com.dinner.common.entity.Privilege;
import com.dinner.common.entity.User;
import com.dinner.common.exception.AccessDeniedException;
import com.dinner.common.exception.AuthenticationException;
import com.dinner.mgr.util.UserUtils;
import com.dinner.mgr.util.annoation.Permission;

/**
 * 权限拦截切面 利用Spring Aop 进行权限拦截
 * 
 * @author admin
 * @create 2014年2月18日 下午1:23:56
 */
@Component
@Aspect
public class PermissionAuthInterceptor {

	private static Log log = LogFactory.getLog(PermissionAuthInterceptor.class);

	// 不需要进行拦截的一些权限
	private static final List<Privilege> excludePriv = new ArrayList<Privilege>();

	static {
		excludePriv.add(new Privilege("home", "login")); // 登陆
		excludePriv.add(new Privilege("home", "logout")); // 登出
		excludePriv.add(new Privilege("home", "loginEmployee")); // 登出
		excludePriv.add(new Privilege("home", "index")); // 访问主页
		excludePriv.add(new Privilege("home", "password")); // 修改密码
		excludePriv.add(new Privilege("home", "sys_init")); // 系统初始化
	}

	/**
	 * 切入点: 拦截Controller子包下面的所有Public方法
	 */
	@Pointcut("execution (public * com.dinner.mgr.controller..*(..))")
	public void publicMethod() {
	}

	@Around("publicMethod()")
	public Object permissionAuth(ProceedingJoinPoint pjp) throws Throwable {

		Object target = pjp.getTarget(); // 目标对象

		MethodSignature methodSignature = (MethodSignature) pjp.getSignature();
		Method method = methodSignature.getMethod();

		Permission permission = method.getAnnotation(Permission.class);
		if (permission == null) {
			// 权限验证
			if (log.isDebugEnabled()) {
				log.debug("权限拦截: permission is null. " + target.getClass().getSimpleName() + "." + method.getName());
			}
			throw new AccessDeniedException("您尚无权限进行此项操作！");
		}

		// 是否不需要拦截
		boolean is = exclude(permission);
		if (is) {
			return pjp.proceed();
		}

		User user = null;

		Object[] args = pjp.getArgs();
		for (int i = 0; i < args.length; i++) {
			Object arg = args[i];
			if (arg instanceof HttpServletRequest) {
				user = UserUtils.getLoginUser((HttpServletRequest) arg);
				if (log.isDebugEnabled()) {
					log.debug("权限拦截: 获取已登陆员工:" + user);
				}
			}
		}

		if (user == null) {
			if (log.isInfoEnabled()) {
				log.info("权限拦截: 未登陆,强制结束该请求");
				throw new AuthenticationException("您尚无登陆!");
			}
		}

		// 权限验证
		if (log.isDebugEnabled()) {
			log.debug("权限拦截: [module:" + permission.module() + ", privilege:" + permission.privilege() + "], " + target.getClass().getSimpleName() + "."
					+ method.getName());
		}
		boolean succ = checkPrivilege(user, permission);
		if (!succ) {
			throw new AccessDeniedException("您尚无权限进行此项操作！");
		}
		// 保存用户城市到TheadLoal
		return pjp.proceed();
	}

	private boolean exclude(Permission permission) {
		for (Privilege p : excludePriv) {
			if (p.getModule().equals(permission.module()) && p.getPrivilege().equals(permission.privilege())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * 权限验证
	 * 
	 * @param user
	 * @param permission
	 * @return
	 */
	private boolean checkPrivilege(User user, Permission permission) {
		List<Privilege> privileges = user.getPrivileges();
		if (CollectionUtils.isEmpty(privileges)) {
			return false;
		}
		for (Privilege p : privileges) {
			if (p.getModule().equals(permission.module()) && Arrays.asList(permission.privilege().split(",")).contains(p.getPrivilege())) {
				return true;
			}
		}
		return false;
	}
}
