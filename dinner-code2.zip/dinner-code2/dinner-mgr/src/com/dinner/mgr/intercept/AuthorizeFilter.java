package com.dinner.mgr.intercept;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dinner.common.entity.User;
import com.dinner.framework.util.web.WebUtils;
import com.dinner.mgr.util.UserUtils;

/**
 * 登陆验证filter
 * 
 * @author admin
 * @create 2014年2月17日 下午7:15:11
 */
public class AuthorizeFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;

		// 登陆、退出请求、资源文件
		if (WebUtils.skipFilter(req)) {
			chain.doFilter(request, response);
			return;
		}

		User user = UserUtils.getLoginUser(req);
		if (user != null) { // 已登陆
			chain.doFilter(req, resp);
			return;
		}

		boolean isAjax = WebUtils.isAjaxRequest(req);
		if (isAjax) {
			resp.setHeader("sessionstatus", "timeout");
			resp.sendError(518, "session timeout");
			return;
		}

		// 重定向登陆页面
		resp.sendRedirect(req.getContextPath() + "/home/login.htm");
	}

	@Override
	public void destroy() {

	}

}
