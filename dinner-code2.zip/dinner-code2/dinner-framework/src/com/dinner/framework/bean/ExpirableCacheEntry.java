package com.dinner.framework.bean;

/**
 * 支持过期设置的缓存条目
 * 
 * @author admin 2013-7-17
 * 
 */
public class ExpirableCacheEntry<T> {
    // 数据
    private T data;
    // 上次更改时间(unix时间戳,毫秒)
    private long lastModified = System.currentTimeMillis();

    public T getData() {
	return data;
    }

    public void setData(T data) {
	this.data = data;
	lastModified = System.currentTimeMillis();
    }

    public long getLastModified() {
	return lastModified;
    }

    public void setLastModified(long lastModified) {
	this.lastModified = lastModified;
    }
}
