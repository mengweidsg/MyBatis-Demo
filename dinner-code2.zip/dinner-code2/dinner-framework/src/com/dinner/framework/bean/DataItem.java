package com.dinner.framework.bean;

public class DataItem {
    public final String key;
    public final String value;

    public DataItem(String key, String value) {
	this.key = key;
	this.value = value;
    }
}