package com.dinner.framework.bean;

public enum LogLevel {
    DEBUG, INFO, WARN,ERROR
}
