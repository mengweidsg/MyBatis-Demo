package com.dinner.framework.bean;

public class Result<T> {

    public static final int ERROR = 1; // 错误
    public static final int WARN = 2; // 警告

    private int code = 0; // 成功
    private T msg;

    public Result(int code, T msg) {
	this.code = code;
	this.msg = msg;
    }

    public Result(T msg) {
	this.msg = msg;
    }

    public int getCode() {
	return code;
    }

    public void setCode(int code) {
	this.code = code;
    }

    public T getMsg() {
	return msg;
    }

    public void setMsg(T msg) {
	this.msg = msg;
    }

    /**
     * 错误
     * 
     * @param msg
     * @return
     */
    public static <T> Result<T> getError(T msg) {
	return new Result<T>(Result.ERROR, msg);
    }

    /**
     * 成功
     * 
     * @param msg
     * @return
     */
    public static <T> Result<T> getSucc(T msg) {
	return new Result<T>(msg);
    }

    /**
     * 返回警告
     * 
     * @param msg
     * @return
     */
    public static <T> Result<T> getWarn(T msg) {
	return new Result<T>(Result.WARN, msg);
    }

    @Override
    public String toString() {
	return "Result [code=" + code + ", m=" + msg + "]";
    }

}