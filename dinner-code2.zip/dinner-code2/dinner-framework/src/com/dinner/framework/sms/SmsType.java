package com.dinner.framework.sms;

/**
 * 短信类型
 * 
 * @author yu.han 2014年7月5日 下午4:40:40
 * 
 */
public enum SmsType {
    /**
     * 获取注册验证码
     */
    REGISTER_USER("您的注册验证码：%s"),
    /**
     * 重置密码验证码
     */
    FORGET_PASSWORD("重置密码验证码：%s");

    private String template;

    private SmsType(String template) {
	this.template = template;
    }

    public String getTemplate() {
	return template;
    }
}
