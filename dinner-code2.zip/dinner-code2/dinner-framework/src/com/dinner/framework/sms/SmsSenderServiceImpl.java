package com.dinner.framework.sms;

/**
 * 短信发送service实现
 * 
 * @author yu.han 2014年7月5日 下午4:23:54
 * 
 */
public class SmsSenderServiceImpl implements SmsSenderService {
//	private String url;
//	private String userName;
//	private String password;

	@Override
	public void smsSend(String content, String... mobiles) {
		// TODO Auto-generated method stub

	}

	public void setUrl(String url) {
//		this.url = url;
	}

	public void setUserName(String userName) {
//		this.userName = userName;
	}

	public void setPassword(String password) {
//		this.password = password;
	}

}
