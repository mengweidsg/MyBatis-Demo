package com.dinner.framework.sms;

/**
 * 短信发送service
 * 
 * @author yu.han 2014年7月5日 下午4:22:25
 * 
 */
public interface SmsSenderService {
    /**
     * 发送短信
     * 
     * @param content
     * @param mobiles
     */
    public void smsSend(String content, String... mobiles);
}
