package com.dinner.framework.redis;

import java.util.List;
import java.util.Map;
import java.util.Set;

import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.exceptions.JedisConnectionException;

/**
 * redis服务接口
 * 
 * @author admin 2013-7-3
 * 
 */
public interface RedisService {
    /**
     * 在redis中设置一个值,O(1)
     * 
     * @param key
     *            键
     * @param value
     *            值
     * @return 状态码
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    String set(String key, String value);

    /**
     * 设置一个值,同时指定过期时间,O(1)
     * 
     * @param key
     *            键
     * @param value
     *            值
     * @param expireSeconds
     *            过期时间(秒)
     * @return 状态码
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    String set(String key, String value, int expireSeconds);

    /**
     * 设置一个值进set
     * 
     * @param key
     *            键
     * @param value
     *            值
     * @return 状态码
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    Long addToSet(String key, String value);

    /**
     * 从set中删除一个值
     * 
     * @param key
     *            键
     * @param value
     *            值
     * @return 状态码
     * @author zhengsibi
     * 
     */
    public Long removeFormSet(String key, String value);

    /**
     * 设置一组值
     * 
     * @param key
     * @param value
     * @return
     */
    public Long addToSet(String key, String... value);

    /**
     * 获取一个set的元素数
     * 
     * @param key
     * @return int (number of set)
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    int getSetCount(String key);

    /**
     * 根据一个key值获取一个set集合的元素,O(N)
     * 
     * @param key
     * @return
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     * 
     */
    Set<String> getSetMembers(String key);

    /**
     * 若一个键不存在,则将键设置成对应的值,O(1)
     * 
     * @param key
     *            键
     * @param value
     *            值
     * @return true 设置成功 false 键已存在
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    boolean setIfNotExist(String key, String value);

    /**
     * 从redis中取回和key关联的字符串,O(1)
     * 
     * @param key
     * @return 与key相关联的字符串,若key不存在,则返回null
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    String get(String key);

    /**
     * 获取一批值,O(n),n为键的个数
     * 
     * @param keys
     *            一批键
     * @return 对应的一批值,若某个键不存在,则对应的值为null
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    List<String> gets(String... keys);

    /**
     * 判断key是否存在,O(1)
     * 
     * @param key
     * @return true 存在,false 不存在
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    boolean exists(String key);

    /**
     * 获取指定Key的指定成员的分数。O(1)
     * 
     * @param key
     * @param value
     * @return
     */
    Double getSetScore(String key, String value);

    /**
     * sortedset key中存储的字段value 排序分值是当前时间戳
     * 
     * @param listName
     * @param fieldName
     */
    void addSortedSet(String key, String value);

    /**
     * 删除一批key,O(1)
     * 
     * @param keys
     *            要删除的key
     * @return 被删的key数量
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    int del(String... keys);

    /**
     * 设置一个键的相对过期时间,O(1)
     * 
     * @param key
     *            键
     * @param seconds
     *            过期秒数
     * @return true 设置成功,false 设置失败
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    boolean expire(String key, int seconds);

    /**
     * 设置一个键的绝对过期时间,O(1)
     * 
     * @param key
     *            键
     * @param unixTime
     *            unix时间戳(秒)
     * @return 是否成功
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    boolean expireAt(String key, long unixTime);

    /**
     * 原子性地将一个键设置成新值,同时返回旧值,O(1)
     * 
     * @param key
     *            键
     * @param value
     *            要设置的值
     * @return 旧值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    String getSet(String key, String value);

    /**
     * 将一个键的值(原子性地)增1
     * 
     * @param key
     *            键
     * @return 增加后的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    long incr(String key);

    /**
     * 将一个键的值(原子性地)增加n
     * 
     * @param key
     *            键
     * @param increment
     *            增量
     * @return 增加后的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    long incrBy(String key, int increment);
    
    /**
     * 将一个键的值(原子性地)增加n
     * 
     * @param key
     *            键
     * @param increment
     *            增量
     * @return 增加后的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    Double incrByFloat(String key, double increment);

    /**
     * 将一个键的值(原子性地)减1
     * 
     * @param key
     *            键
     * @return 减少后的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    long decr(String key);

    /**
     * 将一个键的值(原子性地)减n
     * 
     * @param key
     *            键
     * @param decrement
     *            减少的量
     * @return 减少后的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    long decrBy(String key, int decrement);

    /**
     * 在hashtable中设置一个值,O(1)
     * 
     * @param key
     *            hashtable的key
     * @param field
     *            hashtable的field
     * @param value
     *            要设置的值
     * @return 0：更新了原来的值,1:新建了一个值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    int hset(String key, String field, String value);

    /**
     * 在hashtable中设置一批键值对,O(N),N为键值对个数
     * 
     * @param key
     *            hashtable的键
     * @param fields
     *            要设置的一批键值对
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    void hsets(String key, Map<String, String> fields);

    /**
     * 若一个hashtalbe的filed不存在,则将其设置为一个值 ,否则不设置
     * 
     * @param key
     *            hashtalbe的key
     * @param field
     *            hashtable的 field
     * @param value
     *            要设置的值
     * @return true 设置成功,false field已存在
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    boolean hsetIfNotExists(String key, String field, String value);

    /**
     * 获取hashtable中一个field对应的值
     * 
     * @param key
     *            hashtable的键
     * @param field
     *            hashtable的field
     * @return field对应的值
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    String hget(String key, String field);

    /**
     * 获取一个hasht
     * 
     * @param key
     * @param fields
     * @return fields对应的值
     */
    List<String> hgets(String key, String... fields);

    /**
     * 获取hashtable中所有的键值对
     * 
     * @param key
     *            hashtable的key
     * @return hashtable的所有键值对,若与一个key关联的hashtable不存在,则返回empty的map
     */
    Map<String, String> hgetAll(String key);

    /**
     * 删除指定key所在的hashtable中某个field
     * 
     * @param key
     *            指向hashtable的key
     * @param field
     *            hashtable的field
     * @author zhengsibi
     */
    void hdel(String key, String field);

    /**
     * cas(compare and set)
     * 若一个键的旧值为期望的值之一,则将该键的值更改成新值,否则不更改,无论是否将键值成功更新成新值,都将返回该键操作后的值
     * 此操作为原子操作,可以保证在并发情况下的正确性
     * 
     * @param key
     *            键
     * @param expectingOriginVals
     *            期望的旧值
     * @param toBe
     *            期望更新的值
     * @return cas结果,该次cas是否成功更新成期望的新值可以查看{@link CASResult#isSuccess()}
     *         ,该键最终的值可以查看{@link CASResult#getFinalResult()}
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    CASResult<String> cas(String key, Set<String> expectingOriginVals, String toBe);

    /**
     * 订阅一个通道
     * 
     * @param jedisPubSub
     * @param channels
     */
    void subscribe(JedisPubSub jedisPubSub, String... channels);

    /**
     * 向一个通道发布一条消息,订阅该通道的客户端将会受到这条消息
     * 
     * @param channel
     *            通道
     * @param message
     *            要发送的消息
     * @throws JedisConnectionException
     *             若和redis服务器的连接不成功
     */
    void publish(String channel, String message);

    /**
     * 返回redis中存储的类型 one of "none","set","list","string" "hash" key is not
     * exsits retrun none
     * 
     * @param key
     * @return
     */
    String type(String key);

    /**
     * Return all the fields in a hash.
     * 
     * @param key
     * @return
     */
    Set<String> hkeys(String key);

    /**
     * Set the respective fields to the respective values. HMSET replaces old
     * values with new values.
     * 
     * @param key
     * @param hash
     * @return
     */
    String hmset(String key, Map<String, String> hash);

    /**
     * <pre>
     * 返回minuend与key的原值的差(若key未关联过任何值,则认为key的原值为0),并将key的原值更新为minuend
     * 此方法可用于在分布式环境下计算连续的增量(例如计时)
     * </pre>
     * 
     * @param minuend
     *            被减数
     * @param key
     *            减数对应的key
     * @return minuend与key的原值的差
     */
    long substractedAndSet(long minuend, String key);

    /**
     * 增加取ttl时间方法
     * 
     * @param key
     *            对应的key
     * @return 缓存失效的秒数
     */
    public long ttl(String key);

    String toString();

    public Long zcount(String key, double min, double max);

    /**
     * Increment the number stored at field in the hash at key by value. If key
     * does not exist, a new key holding a hash is created. If field does not
     * exist or holds a string, the value is set to 0 before applying the
     * operation. Since the value argument is signed you can use this command to
     * perform both increments and decrements.
     * 
     * @param key
     * @param member
     * @return
     */
    public long hincrBy(String key, String member);

    /**
     * Return the sorted set cardinality (number of elements). If the key does
     * not exist 0 is returned, like for empty sorted sets.
     * 
     * Time complexity O(1)
     * 
     * @param key
     * @return
     */
    public long zcard(String key);
    /**
     * Remove the specified member from the sorted set value stored at key. If member was not a member of the set no operation is performed. If key does not not hold a set value an error is returned. 
     * Time complexity O(log(N)) with N being the number of elements in the sorted set
     * @param key
     * @param value
     */
    public long removeSortedSet(String key, String ...members);
}
