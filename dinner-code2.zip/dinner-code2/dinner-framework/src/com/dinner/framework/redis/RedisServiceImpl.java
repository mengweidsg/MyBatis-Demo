package com.dinner.framework.redis;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.log4j.Logger;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.JedisPubSub;
import redis.clients.jedis.exceptions.JedisConnectionException;

public class RedisServiceImpl implements RedisService {
    private static final Logger logger = Logger.getLogger(RedisServiceImpl.class);
    // redis lua scripts(supportted since redis 2.6)
    private static final String CAS_CMD = "local v=redis.call('get',KEYS[1]);local r=v;local n=#ARGV-1;local tb=ARGV[#ARGV];local succ='F';for i=1, n do if(v==ARGV[i]) then redis.call('set',KEYS[1],tb); r=tb; succ='T' break;end end;return {succ,r}";
    private static final String SUBS_CMD = "local v=redis.call('incrby',KEYS[1],0);local r=ARGV[1]-v;redis.call('set',KEYS[1],ARGV[1]);return r;";
    private String CAS_KEY;
    private String SUBS_KEY;
    private String redisAddr;
    private String[] addrInfo;
    private JedisPool jedisPool;
    private final AtomicInteger subscribeCount = new AtomicInteger();
    private long redisSubMaintainInterval = 10000;
    private int maxActive = 10;
    private int maxIdle = 5;

    public void setRedisAddr(String redisAddr) {
	this.redisAddr = redisAddr;
    }

    public void setRedisSubMaintainInterval(long redisSubMaintainInterval) {
	this.redisSubMaintainInterval = redisSubMaintainInterval;
    }

    public void setMaxActive(int maxActive) {
	this.maxActive = maxActive;
    }

    public void setMaxIdle(int maxIdle) {
	this.maxIdle = maxIdle;
    }

    public void init() {
	if (redisAddr == null || "".equals(redisAddr.trim()) || "NULL".equals(redisAddr.trim())) {
	    logger.warn("no redis addr was configured,this redis service will be unavaliable");
	    return;
	}
	JedisPoolConfig cfg = new JedisPoolConfig();
	cfg.setMaxActive(maxActive);
	cfg.setMaxIdle(maxIdle);
	addrInfo = redisAddr.split(":");
	jedisPool = new JedisPool(cfg, addrInfo[0], Integer.valueOf(addrInfo[1]));
	// load cas scripts
	Jedis jedis = jedisPool.getResource();
	try {
	    CAS_KEY = jedis.scriptLoad(CAS_CMD);
	    SUBS_KEY = jedis.scriptLoad(SUBS_CMD);
	} finally {
	    jedisPool.returnResource(jedis);
	}
    }

    public void stop() {
	if (jedisPool != null) {
	    jedisPool.destroy();
	}
    }

    @Override
    public String set(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.set(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    /**
     * 以当前时间的毫秒数位score
     */
    @Override
    public void addSortedSet(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    jedis.zadd(key, System.currentTimeMillis(), value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public String set(String key, String value, int expireSeconds) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.setex(key, expireSeconds, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public Long addToSet(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.sadd(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    public Long removeFormSet(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.srem(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public Long addToSet(String key, String... value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.sadd(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public int getSetCount(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.scard(key).intValue();
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public boolean setIfNotExist(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    long result = jedis.setnx(key, value);
	    return result > 0;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public String get(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.get(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public List<String> gets(String... keys) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.mget(keys);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public boolean exists(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.exists(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public Double getSetScore(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.zscore(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public int del(String... keys) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    long result = jedis.del(keys);
	    return (int) result;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public boolean expire(String key, int seconds) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    long result = jedis.expire(key, seconds);
	    return result > 0;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public boolean expireAt(String key, long unixTime) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    long result = jedis.expireAt(key, unixTime);
	    return result > 0;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public String getSet(String key, String value) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.getSet(key, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    public Set<String> getSetMembers(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.smembers(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long incr(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.incr(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long incrBy(String key, int increment) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.incrBy(key, increment);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public Double incrByFloat(String key, double increment) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.incrByFloat(key, increment);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long decr(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.decr(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long decrBy(String key, int decrement) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.decrBy(key, decrement);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public int hset(String key, String field, String value) {
	Jedis jedis = jedisPool.getResource();
	int result = 0;
	boolean broken = false;
	try {
	    result = jedis.hset(key, field, value).intValue();
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return result;
    }

    @Override
    public CASResult<String> cas(String key, Set<String> expectingOriginVals, String toBe) {
	List<String> args = new ArrayList<String>(expectingOriginVals.size() + 2);
	args.add(key);
	args.addAll(expectingOriginVals);
	args.add(toBe);
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    @SuppressWarnings("unchecked")
	    List<String> response = (List<String>) jedis.evalsha(CAS_KEY, 1,
		    args.toArray(new String[0]));
	    String succStr = response.get(0);
	    String val = response.get(1);
	    CASResult<String> result = new CASResult<String>("T".equals(succStr), val);
	    return result;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long substractedAndSet(long minuend, String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    Long response = (Long) jedis.evalsha(SUBS_KEY, 1, key, String.valueOf(minuend));
	    return response;
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public void subscribe(final JedisPubSub jedisPubSub, final String... channels) {
	// 使用单独的jedis实例
	Jedis jedis = new Jedis(addrInfo[0], Integer.valueOf(addrInfo[1]));
	// subscribe是个阻塞操作,因此在单独的线程中执行
	Thread t = new Thread(new RedisSubscribeTask(jedis, jedisPubSub, channels));
	t.setName("RedisSubscribe-" + subscribeCount.incrementAndGet());
	t.start();
    }

    @Override
    public void publish(String channel, String message) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    jedis.publish(channel, message);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    /**
     * 订阅reids通道的task,负责执行redis通道的订阅,并在必要(断线)时重新订阅
     * 
     * @author admin 2013-7-18
     * 
     */
    private class RedisSubscribeTask implements Runnable {
	private Jedis jedis;
	private JedisPubSub pubSub;
	private String[] channels;
	private int failForConnection = 0;
	private int failForException = 0;
	private long interval = redisSubMaintainInterval;

	public RedisSubscribeTask(Jedis jedis, JedisPubSub pubSub, String[] channels) {
	    this.jedis = jedis;
	    this.pubSub = pubSub;
	    this.channels = channels;
	}

	@Override
	public void run() {
	    if (channels == null || channels.length == 0) {
		return;
	    }
	    // 不再依赖ArrayUtils,以免jar包找不到时重新订阅失败
	    String channelStr = null;
	    StringBuilder builder = new StringBuilder();
	    for (String channel : channels) {
		builder.append(channel).append(' ');
	    }
	    while (true) {
		try {
		    jedis.subscribe(pubSub, channels);
		} catch (JedisConnectionException e) {
		    interval = redisSubMaintainInterval;
		    failForConnection++;
		    /* 有可能redis服务器挂了,一段时间后尝试重新订阅 */
		    logger.warn("redis subscribe " + channelStr + "@" + redisAddr + " has broken "
			    + failForConnection + " times,will try to resubscribe after "
			    + interval + " millis");
		} catch (Throwable e) {
		    /*
		     * 这个,应该是哪个刁民写的JedisPubSub里抛出的异常,这类异常导致的订阅失败本该由那刁民自己负责.
		     * 但天父叫太阳照好人,也照坏人,降雨给行善的,也给作恶的(马太福音第5章),因此你们要仁慈,因为你们
		     * 的天父是仁慈的,所以对这些刁民写的JedisPubSub,也应该在一段时间后予以重新订阅.
		     */
		    failForException++;
		    interval = redisSubMaintainInterval * 2;
		    logger.error(
			    "redis subscribe " + channelStr + "@" + redisAddr + " has failed "
				    + failForException
				    + " times because of Exception thrown from JedisPubSub class "
				    + pubSub.getClass() + ",will try to resubscribe after "
				    + interval
				    + " millis,but JedisPubSub class should be checked carefully!",
			    e);
		}
		try {
		    Thread.sleep(interval);
		} catch (InterruptedException e) {
		    // impossiable
		}
		jedis = new Jedis(addrInfo[0], Integer.valueOf(addrInfo[1]));
	    }
	};
    }

    @Override
    public void hsets(String key, Map<String, String> fields) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    jedis.hmset(key, fields);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public boolean hsetIfNotExists(String key, String field, String value) {
	Jedis jedis = jedisPool.getResource();
	long result = 0;
	boolean broken = false;
	try {
	    result = jedis.hsetnx(key, field, value);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return result > 0;
    }

    @Override
    public String hget(String key, String field) {
	Jedis jedis = jedisPool.getResource();
	String val = null;
	boolean broken = false;
	try {
	    val = jedis.hget(key, field);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public List<String> hgets(String key, String... fields) {
	Jedis jedis = jedisPool.getResource();
	List<String> val = null;
	boolean broken = false;
	try {
	    val = jedis.hmget(key, fields);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public Map<String, String> hgetAll(String key) {
	Jedis jedis = jedisPool.getResource();
	Map<String, String> val = null;
	boolean broken = false;
	try {
	    val = jedis.hgetAll(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public void hdel(String key, String field) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    jedis.hdel(key, field);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public String type(String key) {
	Jedis jedis = jedisPool.getResource();
	String val = null;
	boolean broken = false;
	try {
	    val = jedis.type(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;

    }

    @Override
    public Set<String> hkeys(String key) {
	Jedis jedis = jedisPool.getResource();
	Set<String> val = null;
	boolean broken = false;
	try {
	    val = jedis.hkeys(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public String hmset(String key, Map<String, String> hash) {
	Jedis jedis = jedisPool.getResource();
	String val = null;
	boolean broken = false;
	try {
	    val = jedis.hmset(key, hash);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public long ttl(String key) {
	Jedis jedis = jedisPool.getResource();
	long val = -99;
	boolean broken = false;
	try {
	    val = jedis.ttl(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
	return val;
    }

    @Override
    public Long zcount(String key, double min, double max) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.zcount(key, min, max);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    public String toString() {
	return "redis addr :" + redisAddr;
    }

    @Override
    public long hincrBy(String key, String member) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.hincrBy(key, member, 1);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long zcard(String key) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.zcard(key);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

    @Override
    public long removeSortedSet(String key, String... members) {
	Jedis jedis = jedisPool.getResource();
	boolean broken = false;
	try {
	    return jedis.zrem(key, members);
	} catch (JedisConnectionException e) {
	    jedisPool.returnBrokenResource(jedis);
	    broken = true;
	    throw e;
	} finally {
	    if (jedis != null && !broken) {
		jedisPool.returnResource(jedis);
	    }
	}
    }

}
