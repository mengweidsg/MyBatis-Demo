package com.dinner.framework.redis;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import redis.clients.jedis.JedisPubSub;

/**
 * redis集群实现
 * 
 * @author liuyong
 * @date 
 * 
 */
public class RedisServiceClusterWrapper implements RedisService {
    private static Logger logger = Logger.getLogger(RedisServiceClusterWrapper.class);
    //使用数组便于快速访问
    public RedisService[] redisClusters;
    public String redisAddr;
    private long redisSubMaintainInterval = 10000;
    private int maxActive = 10;
    private int maxIdle = 5;
    
    public String getRedisAddr() {
        return redisAddr;
    }

    public void setRedisAddr(String redisAddr) {
        this.redisAddr = redisAddr;
    }

    public long getRedisSubMaintainInterval() {
        return redisSubMaintainInterval;
    }

    public void setRedisSubMaintainInterval(long redisSubMaintainInterval) {
        this.redisSubMaintainInterval = redisSubMaintainInterval;
    }

    public int getMaxActive() {
        return maxActive;
    }

    public void setMaxActive(int maxActive) {
        this.maxActive = maxActive;
    }

    public int getMaxIdle() {
        return maxIdle;
    }

    public void setMaxIdle(int maxIdle) {
        this.maxIdle = maxIdle;
    }

    public void init() {
	if (redisAddr == null || "".equals(redisAddr.trim()) || "NULL".equals(redisAddr.trim())) {
	    logger.warn("no redis cluster hosts was configured, all redis cluster service will be unavaliable");
	    return;
	}
	String [] addrs = redisAddr.split(",");
	if (addrs.length > 0) {
	    redisClusters = new RedisService[addrs.length];
	    for (int i = 0; i < addrs.length; i++) {
		RedisServiceImpl redisServiceImpl = new RedisServiceImpl();
		redisServiceImpl.setMaxActive(maxActive);
		redisServiceImpl.setMaxIdle(maxIdle);
		redisServiceImpl.setRedisAddr(addrs[i].trim());
		redisServiceImpl.setRedisSubMaintainInterval(redisSubMaintainInterval);
		redisServiceImpl.init();
		redisClusters[i] = redisServiceImpl;
	    }
	}
    }
    
    public void stop() {
	for (int i = 0; i < redisClusters.length; i++) {
	    ((RedisServiceImpl)redisClusters[i]).stop();
	}
    }

    public RedisService getService(String key) {
	int hash = (key.hashCode() & 0x7FFFFFFF) ;
	int index = hash % redisClusters.length;
	return redisClusters[index];
    }

    @Override
    public String set(String key, String value) {
	return getService(key).set(key, value);
    }

    @Override
    public String set(String key, String value, int expireSeconds) {
	return getService(key).set(key, value, expireSeconds);
    }

    @Override
    public Long addToSet(String key, String value) {
	return getService(key).addToSet(key, value);
    }

    @Override
    public Long removeFormSet(String key, String value) {
	return getService(key).removeFormSet(key, value);
    }

    @Override
    public Long addToSet(String key, String... value) {
	return getService(key).addToSet(key, value);
    }

    @Override
    public int getSetCount(String key) {
	return getService(key).getSetCount(key);
    }

    @Override
    public Set<String> getSetMembers(String key) {
	return getService(key).getSetMembers(key);
    }

    @Override
    public boolean setIfNotExist(String key, String value) {
	return getService(key).setIfNotExist(key, value);
    }

    @Override
    public String get(String key) {
	return getService(key).get(key);
    }

    @Override
    public List<String> gets(String... keys) {
	List<String> list = new ArrayList<String>();
	for (int i = 0; i < keys.length; i++) {
	    RedisService redis = getService(keys[i]);
	    String value = redis.get(keys[i]);
	    list.add(value);
	}
	return list;
    }

    @Override
    public boolean exists(String key) {
	return getService(key).exists(key);
    }

    @Override
    public Double getSetScore(String key, String value) {
	return getService(key).getSetScore(key, value);
    }

    @Override
    public void addSortedSet(String key, String value) {
	getService(key).addSortedSet(key, value);
    }

    @Override
    public int del(String... keys) {
	int count = 0;
	for (int i = 0; i < keys.length; i++) {
	    count += getService(keys[i]).del(new String[]{keys[i]});	    
	}
	return count;
    }

    @Override
    public boolean expire(String key, int seconds) {
	return getService(key).expire(key, seconds);
    }

    @Override
    public boolean expireAt(String key, long unixTime) {
	return getService(key).expireAt(key, unixTime);
    }

    @Override
    public String getSet(String key, String value) {
	return getService(key).getSet(key, value);
    }

    @Override
    public long incr(String key) {
	return getService(key).incr(key);
    }

    @Override
    public long incrBy(String key, int increment) {
	return getService(key).incrBy(key, increment);
    }

    @Override
    public Double incrByFloat(String key, double increment) {
	return getService(key).incrByFloat(key, increment);
    }

    @Override
    public long decr(String key) {
	return getService(key).decr(key);
    }

    @Override
    public long decrBy(String key, int decrement) {
	return getService(key).decrBy(key, decrement);
    }

    @Override
    public int hset(String key, String field, String value) {
	return getService(key).hset(key, field, value);
    }

    @Override
    public void hsets(String key, Map<String, String> fields) {
	getService(key).hsets(key, fields);
    }

    @Override
    public boolean hsetIfNotExists(String key, String field, String value) {
	return getService(key).hsetIfNotExists(key, field, value);
    }

    @Override
    public String hget(String key, String field) {
	return getService(key).hget(key, field);
    }

    @Override
    public List<String> hgets(String key, String... fields) {
	return getService(key).hgets(key, fields);
    }

    @Override
    public Map<String, String> hgetAll(String key) {
	return getService(key).hgetAll(key);
    }

    @Override
    public void hdel(String key, String field) {
	getService(key).hdel(key, field);
    }

    @Override
    public CASResult<String> cas(String key, Set<String> expectingOriginVals, String toBe) {
	return getService(key).cas(key, expectingOriginVals, toBe);
    }

    @Override
    public void subscribe(JedisPubSub jedisPubSub, String... channels){
	for (int i = 0; i < channels.length; i++) {
	    getService(channels[i]).subscribe(jedisPubSub, new String[]{channels[i]});
	}
    }

    @Override
    public void publish(String channel, String message) {
	getService(channel).publish(channel, message);
    }

    @Override
    public String type(String key) {
	return getService(key).type(key);
    }

    @Override
    public Set<String> hkeys(String key) {
	return getService(key).hkeys(key);
    }

    @Override
    public String hmset(String key, Map<String, String> hash) {
	return getService(key).hmset(key, hash);
    }

    @Override
    public long substractedAndSet(long minuend, String key) {
	return getService(key).substractedAndSet(minuend, key);
    }
    
    @Override
    public Long zcount(String key, double min, double max) {
	return getService(key).zcount(key, min, max);
    }

    @Override
    public String toString() {
	return  RedisServiceClusterWrapper.class.getName() +" [redisClusters=" + Arrays.toString(redisClusters)
		+ ", redisAddr=" + redisAddr + ", redisSubMaintainInterval="
		+ redisSubMaintainInterval + ", maxActive=" + maxActive + ", maxIdle=" + maxIdle
		+ "]";
    }
    
    public long ttl(String key){
	return getService(key).ttl(key);
    }

    public static void main(String[] args) {
	//cluster.redis.addr=10.10.0.49:6379,10.10.0.49:6479,10.10.0.49:6579,10.10.0.49:6679,10.10.0.53:6379,10.10.0.53:6479,10.10.0.53:6579,10.10.0.53:6679
	//persistence.redis.addr=10.10.0.118:6379,10.10.0.118:6380,10.10.0.118:6381,10.10.0.119:6379,10.10.0.119:6380,10.10.0.119:6381
	String did = "27922";
	String key = String.format("dri:ha:freq:%s",did);
	int hash = (key.hashCode() & 0x7FFFFFFF) ;
	int index = hash % 8;
	System.out.println(index);
    }

    @Override
    public long hincrBy(String key, String member) {
	return getService(key).hincrBy(key, member);
    }

    @Override
    public long zcard(String key) {
	return getService(key).zcard(key);
    }

    @Override
    public long removeSortedSet(String key, String... members) {
	return getService(key).removeSortedSet(key, members);
    }

}
