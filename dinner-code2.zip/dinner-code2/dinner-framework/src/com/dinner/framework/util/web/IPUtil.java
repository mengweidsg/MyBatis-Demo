package com.dinner.framework.util.web;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;

public class IPUtil {

    private static final String REGX_IP = "((25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)\\.){3}(25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]\\d|\\d)";

    private static final String LAN_REGX_IP = "^((192\\.168|172\\.([1][6-9]|[2]\\d|3[01]))(\\.([2][0-4]\\d|[2][5][0-5]|[01]?\\d?\\d)){2}|(10|127)(\\.([2][0-4]\\d|[2][5][0-5]|[01]?\\d?\\d)){3})$";
    private static final String REGX_IPB = REGX_IP + "\\-" + REGX_IP;

    public static String getIpAddress(HttpServletRequest request) {
	String ip = request.getHeader("X-Forwarded-For");
	if (StringUtils.isBlank(ip) || StringUtils.equalsIgnoreCase(ip, "unknown")) {
	    ip = request.getHeader("Proxy-Client-IP");
	}
	if (StringUtils.isBlank(ip) || StringUtils.equalsIgnoreCase(ip, "unknown")) {
	    ip = request.getHeader("WL-Proxy-Client-IP");
	}
	if (StringUtils.isBlank(ip) || StringUtils.equalsIgnoreCase(ip, "unknown")) {
	    ip = request.getHeader("HTTP_CLIENT_IP");
	}
	if (StringUtils.isBlank(ip) || StringUtils.equalsIgnoreCase(ip, "unknown")) {
	    ip = request.getHeader("HTTP_X_FORWARDED_FOR");
	}
	if (StringUtils.isBlank(ip) || StringUtils.equalsIgnoreCase(ip, "unknown")) {
	    ip = request.getRemoteAddr();
	}

	if (StringUtils.isNotBlank(ip) && StringUtils.indexOf(ip, ",") > 0) {
	    String[] ipArray = StringUtils.split(ip, ",");
	    ip = ipArray[0];
	}
	return ip;
    }

    public static boolean isValidIpAddr(String ipaddr) {
	if (StringUtils.isBlank(ipaddr)) {
	    throw new NullPointerException("ipaddr不能为空！");
	}
	return ipaddr.matches(REGX_IP);
    }

    public static boolean ipIsValid(String ipSection, String ip) {
	if (ipSection == null)
	    throw new NullPointerException("IP段不能为空！");
	if (ip == null)
	    throw new NullPointerException("IP不能为空！");
	ipSection = ipSection.trim();
	ip = ip.trim();

	if (!ipSection.matches(REGX_IPB) || !ip.matches(REGX_IP))
	    return false;
	int idx = ipSection.indexOf('-');
	String[] sips = ipSection.substring(0, idx).split("\\.");
	String[] sipe = ipSection.substring(idx + 1).split("\\.");
	String[] sipt = ip.split("\\.");
	long ips = 0L, ipe = 0L, ipt = 0L;
	for (int i = 0; i < 4; ++i) {
	    ips = ips << 8 | Integer.parseInt(sips[i]);
	    ipe = ipe << 8 | Integer.parseInt(sipe[i]);
	    ipt = ipt << 8 | Integer.parseInt(sipt[i]);
	}
	if (ips > ipe) {
	    long t = ips;
	    ips = ipe;
	    ipe = t;
	}
	return ips <= ipt && ipt <= ipe;
    }

    public static boolean isValid(String ipaddr) {
	if (StringUtils.isBlank(ipaddr)) {
	    throw new IllegalArgumentException("ipaddr不为空！");
	}
	return ipaddr.matches(REGX_IPB) || ipaddr.matches(REGX_IP);
    }

    public static boolean isLanIpAddr(String ipaddr) {
	if (StringUtils.isBlank(ipaddr)) {
	    throw new IllegalArgumentException("ipaddr不为空！");
	}
	return ipaddr.matches(LAN_REGX_IP);
    }

    public static boolean isIpv6(String ipaddr) {
	return !(ipaddr.replaceAll("\\d", "").length() == 3);
    }

    public static void main(String[] args) {
	System.out.println(isLanIpAddr("192.168.0.1"));
	System.out.println(ipIsValid("127.0.0.1-127.0.0.100", "127.0.0.1"));
	System.out.println(isIpv6("0:0:0:0:0:0:0:1"));
    }
}
