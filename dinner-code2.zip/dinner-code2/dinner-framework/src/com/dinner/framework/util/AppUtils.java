package com.dinner.framework.util;

import java.util.Date;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;

import org.apache.commons.lang.RandomStringUtils;
import org.apache.commons.lang.StringUtils;

import com.dinner.framework.util.date.DateUtils;

/**
 * 类AppUtils.java的实现描述：应用级的Helper
 * 
 * @author admin 2011-2-22 下午04:10:36
 */
public final class AppUtils {

    private final static int MAX_VALUE = 99999;
    private static AtomicInteger ai = new AtomicInteger(0);

    public final static String getUUID() {
	return UUID.randomUUID().toString().replace("-", "");
    }

    /**
     * 生成20位长度的数字 - 15位时间 + 3位数字（00001~99999）
     * 
     * @return
     */
    public final static String getSN() {
	if (ai.intValue() > MAX_VALUE) {
	    ai.set(0);
	}
	return getMils() + StringUtils.leftPad(String.valueOf(ai.incrementAndGet()), 5, "0");
    }

    public final static synchronized String getMils() {
	return DateUtils.parse(new Date(), "yyMMddHHmmssSSS");
    }

    /**
     * 时间到毫秒15位 + 5位随机数(理论上存在重复可能)
     * 
     * @return
     */
    public final static String generateOrderSn() {
	return getMils() + RandomStringUtils.randomNumeric(5);
    }

    public final static String generateOrderSn2() {
	return getMils() + RandomStringUtils.randomNumeric(3);
    }

    public final static String getFinalStr() {
	Random random = new Random();
	String retStr = random.nextInt(5000) + random.nextInt(5000) + "";
	if (retStr.length() == 1) {
	    retStr = "000" + retStr;
	} else if (retStr.length() == 2) {
	    retStr = "00" + retStr;
	} else if (retStr.length() == 3) {
	    retStr = "0" + retStr;
	}
	return retStr;
    }

    public static String getBankNoWithStart(String mobileNo) {
	String _mobileNo = mobileNo.replaceAll(" ", "");
	String head;
	String tail;
	try {
	    head = _mobileNo.substring(0, 4);
	    tail = _mobileNo.substring(_mobileNo.length() - 4, _mobileNo.length());
	} catch (RuntimeException e) {

	    return _mobileNo;
	}
	return head + "***" + tail;
    }

    public static String getBankNameNoWithStart(String bankName) {
	String head;
	try {
	    head = bankName.substring(0, 1);

	} catch (RuntimeException e) {
	    return bankName;
	}
	return head + "*";
    }

    public static void main(String[] args) {
	System.out.println(generateOrderSn());
    }

}
