package com.dinner.framework.util;

import java.util.Random;

public class RandomUtil {

    private static final String SEED = "0123456789ABCDEFGHJKMNPQRSTUVWXYZ";
    private static final int COMPLEX = 8;

    /**
     * 新生成一个乘客激活码
     * 
     * @return
     * @author yjw
     */
    public static String getPasActiveCode() {
	char[] ch = SEED.toCharArray();
	int len = ch.length;
	int index = 0;
	Random r = new Random();
	StringBuffer sb = new StringBuffer();
	for (int i = 0; i < COMPLEX; i++) {
	    index = r.nextInt(len);
	    sb.append(ch[index]);
	}

	return sb.toString();
    }

    private static char[] characts = " ABCDEFGHJKLMNPQRSTUVWXYZ0123456789".toCharArray();

    // private static List<String> randoms = new ArrayList<String>();
    /**
     * 取得指定长度的随机数字
     * 
     * @param len
     * @return
     * @throws Exception
     */
    public static String getRandNum(int len) {
	if (len <= 0)
	    throw new RuntimeException("len must bigger than 0.");
	String s = String.valueOf(Math.random());
	// System.out.println(s);
	return s.substring(4, 4 + len);
    }

    public static String getNewPassword() {
	return getRandNum(6);
    }

    /**
     * 取得4位随机数字
     * 
     * @return
     * @throws Exception
     */
    public static String getRand4Num() {
	try {
	    return getRandNum(4);
	} catch (Exception exp) {
	    return "7907";
	}
    }

    public static String getRandChar(int len) {
	String sResult = "";
	int i = 0;
	while (true) {
	    String s = String.valueOf(Math.random());
	    i = Integer.parseInt(s.substring(4, 6));
	    if (i <= 0 || i > 34)
		continue;
	    sResult += characts[i];
	    if (sResult.length() >= len)
		break;
	}
	return sResult;
    }
}
