package com.dinner.framework.util.web;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.Principal;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.httpclient.cookie.CookiePolicy;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.PoolingClientConnectionManager;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.CoreConnectionPNames;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

import com.dinner.framework.util.JsonUtil;

public class HttpUtil {
    private static final Logger logger = Logger.getLogger(HttpUtil.class);

    public static final String UTF8 = "UTF-8";
    public static final String GBK = "GBK";
    public static final String GB2312 = "GB2312";

    private static final HttpClient HTTP_CLIENT;
    static {
	ClientConnectionManager connectionManager = new PoolingClientConnectionManager();
	HTTP_CLIENT = new DefaultHttpClient(connectionManager);
	HTTP_CLIENT.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 6000);
	HTTP_CLIENT.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 6000);
	HTTP_CLIENT.getParams().setParameter(HttpMethodParams.USER_AGENT,
		"Mozilla/5.0 (Windows NT 6.1; rv:8.0.1) Gecko/20100101 Firefox/8.0.1");

    }

    /**
     * 以post方式发送请求并返回响应
     * 
     * @author admin 2013-6-8
     * @param url
     *            发送请求的url
     * @param params
     *            post参数,所有的参数值均视为字符串
     * @return 响应
     */
    public static String post(String url, Map<String, Object> params) {
	return post(url, params, null, null, null);
    }

    /**
     * 以post方式发送请求并返回响应
     * 
     * @author yu.han 20131226
     * 
     * @param url
     *            请求url
     * @param params
     *            post参数,所有的参数值均视为字符串
     * @param reqEncode
     *            请求参数编码，默认：UTF-8
     * @param resEncode
     *            响应返回编码，默认：UTF-8
     * @return
     */
    public static String postEncode(String url, Map<String, Object> params, String reqEncode,
	    String resEncode) {
	return post(url, params, null, reqEncode, resEncode);
    }

    /**
     * 以post方式发送请求并返回响应
     * 
     * @author admin 2013-6-8
     * @param url
     *            发送请求的url
     * @param params
     *            post参数,所有的参数值均视为字符串
     * @param hearders
     *            http头
     * @return 响应
     */
    @SuppressWarnings({ "rawtypes", "unchecked" })
    public static String post(String url, Map<String, Object> params, Map<String, String> headers,
	    String reqEncode, String resEncode) {
	HttpPost post = new HttpPost(url);

	if (StringUtils.isBlank(reqEncode)) {
	    reqEncode = UTF8;
	}
	if (StringUtils.isBlank(resEncode)) {
	    resEncode = UTF8;
	}

	List httpParams = null;
	if (params != null && !params.isEmpty()) {
	    httpParams = new ArrayList(params.size());
	    for (Entry<String, Object> entry : params.entrySet()) {
		String k = entry.getKey();
		Object v = entry.getValue();
		if (v == null) {
		    httpParams.add(new BasicNameValuePair(k, null));
		} else if (!v.getClass().isArray()) {
		    httpParams.add(new BasicNameValuePair(k, v.toString()));
		} else {// 数组要作特殊处理
		    int len = Array.getLength(v);
		    for (int i = 0; i < len; i++) {
			Object element = Array.get(v, i);
			if (element != null) {
			    httpParams.add(new BasicNameValuePair(k, element.toString()));
			} else {
			    httpParams.add(new BasicNameValuePair(k, null));
			}
		    }
		}
	    }
	    if (headers != null) {
		for (Entry<String, String> e : headers.entrySet()) {
		    post.addHeader(e.getKey(), e.getValue());
		}
	    }
	    try {
		post.setEntity(new UrlEncodedFormEntity(httpParams, reqEncode));
		post.getParams().setParameter("http.protocol.cookie-policy",
			CookiePolicy.BROWSER_COMPATIBILITY);
	    } catch (UnsupportedEncodingException impossiable) {
		// shouldn't happen
		throw new RuntimeException("UTF-8 is not surportted", impossiable);
	    }
	}
	String response = null;
	try {
	    HttpEntity entity = HTTP_CLIENT.execute(post).getEntity();
	    response = EntityUtils.toString(entity, resEncode);
	} catch (Exception e) {
	    throw new RuntimeException("error post data to " + url, e);
	} finally {
	    post.releaseConnection();
	}

	if (logger.isDebugEnabled()) {
	    logger.debug("response=" + response);
	}
	return response;
    }

    public static String postForJson(HttpClient httpClient, String url, Map<String, Object> params,
	    Map<String, String> headers) {
	if (httpClient == null) {
	    httpClient = HTTP_CLIENT;
	}
	HttpPost post = new HttpPost(url);

	if (params != null && !params.isEmpty()) {
	    if (headers != null) {
		for (Entry<String, String> e : headers.entrySet()) {
		    post.addHeader(e.getKey(), e.getValue());
		}
	    }
	    try {
		String body = JsonUtil.toJson(params);
		BasicHttpEntity requestBody = new BasicHttpEntity();
		requestBody.setContent(new ByteArrayInputStream(body.getBytes("UTF-8")));
		requestBody.setContentLength(body.getBytes("UTF-8").length);
		post.setEntity(requestBody);
		post.getParams().setParameter("http.protocol.cookie-policy",
			CookiePolicy.BROWSER_COMPATIBILITY);
	    } catch (UnsupportedEncodingException impossiable) {
		// shouldn't happen
		throw new RuntimeException("UTF-8 is not surportted", impossiable);
	    }
	}
	String response = null;
	try {
	    HttpEntity entity = httpClient.execute(post).getEntity();
	    response = EntityUtils.toString(entity, "UTF-8");
	    EntityUtils.consume(entity);
	} catch (Exception e) {
	    throw new RuntimeException("error post data to " + url, e);
	} finally {
	    post.releaseConnection();
	}

	if (logger.isDebugEnabled()) {
	    logger.debug("response=" + response);
	}
	return response;
    }

    public static String get(String url, Map<String, String> params) {
	if (params != null) {
	    StringBuilder builder = new StringBuilder(url).append('?');
	    for (Entry<String, String> e : params.entrySet()) {
		builder.append(e.getKey()).append('=').append(e.getValue()).append('&');
	    }
	    url = builder.toString();
	}
	HttpGet get = new HttpGet(url);
	String response = null;
	try {
	    HttpEntity entity = HTTP_CLIENT.execute(get).getEntity();
	    response = EntityUtils.toString(entity, "UTF-8");
	} catch (Exception e) {
	    throw new RuntimeException("error post data to " + url, e);
	} finally {
	    get.releaseConnection();
	}

	if (logger.isDebugEnabled()) {
	    logger.debug("response=" + response);
	}
	return response;
    }

    /**
     * 注册SSL连接
     * 
     * @param hostname
     *            请求的主机名（IP或者域名）
     * @param protocol
     *            请求协议名称（TLS-安全传输层协议）
     * @param port
     *            端口号
     * @param scheme
     *            协议名称
     * @return HttpClient实例
     * @throws NoSuchAlgorithmException
     * @throws KeyManagementException
     */
    public static DefaultHttpClient registerSSL(String hostname, String protocol, int port,
	    String scheme) throws NoSuchAlgorithmException, KeyManagementException {

	// 创建一个默认的HttpClient
	ClientConnectionManager connectionManager = new PoolingClientConnectionManager();
	DefaultHttpClient httpclient = new DefaultHttpClient(connectionManager);
	httpclient.getParams().setParameter(CoreConnectionPNames.CONNECTION_TIMEOUT, 6000);
	httpclient.getParams().setParameter(CoreConnectionPNames.SO_TIMEOUT, 6000);
	httpclient.getParams().setParameter(HttpMethodParams.USER_AGENT,
		"Mozilla/5.0 (Windows NT 6.1; rv:8.0.1) Gecko/20100101 Firefox/8.0.1");
	// 创建SSL上下文实例
	SSLContext ctx = SSLContext.getInstance(protocol);
	// 服务端证书验证
	X509TrustManager tm = new X509TrustManager() {

	    /**
	     * 验证客户端证书
	     */
	    @Override
	    public void checkClientTrusted(X509Certificate[] chain, String authType)
		    throws java.security.cert.CertificateException {
		// 这里跳过客户端证书 验证
	    }

	    /**
	     * 验证服务端证书
	     * 
	     * @param chain
	     *            证书链
	     * @param authType
	     *            使用的密钥交换算法，当使用来自服务器的密钥时authType为RSA
	     */
	    @Override
	    public void checkServerTrusted(X509Certificate[] chain, String authType)
		    throws java.security.cert.CertificateException {
		if (chain == null || chain.length == 0)
		    throw new IllegalArgumentException("null or zero-length certificate chain");
		if (authType == null || authType.length() == 0)
		    throw new IllegalArgumentException("null or zero-length authentication type");

		boolean br = false;
		Principal principal = null;
		for (X509Certificate x509Certificate : chain) {
		    principal = x509Certificate.getSubjectX500Principal();
		    if (principal != null) {
			br = true;
			return;
		    }
		}
		if (!br) {
		    throw new CertificateException("server certificate failed to verify");
		}
	    }

	    /**
	     * 返回CA发行的证书
	     */
	    @Override
	    public X509Certificate[] getAcceptedIssuers() {
		return new X509Certificate[0];
	    }
	};

	// 初始化SSL上下文
	ctx.init(null, new TrustManager[] { tm }, new java.security.SecureRandom());
	// 创建SSL连接
	SSLSocketFactory socketFactory = new SSLSocketFactory(ctx,
		SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	Scheme sch = new Scheme(scheme, port, socketFactory);
	// 注册SSL连接
	httpclient.getConnectionManager().getSchemeRegistry().register(sch);
	return httpclient;
    }
}
