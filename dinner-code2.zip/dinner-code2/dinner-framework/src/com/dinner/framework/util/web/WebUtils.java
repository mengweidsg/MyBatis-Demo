package com.dinner.framework.util.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;

public class WebUtils {

    public static final String JSON_RESPONSE_TYPE = "application/json;charset=UTF-8";

    public static final String HTML_RESPONSE_TYPE = "text/html;charset=UTF-8";

    public static void outJson(HttpServletResponse response, String content) throws IOException {
	response.setContentType(WebUtils.JSON_RESPONSE_TYPE);
	response.setCharacterEncoding("UTF-8");
	PrintWriter pw = response.getWriter();
	pw.write(content);
	pw.flush();
	pw.close();

    }

    /**
     * 是否ajax请求
     * 
     * @param request
     * @return
     */
    public static boolean isAjaxRequest(HttpServletRequest request) {
	String requestType = request.getHeader("X-Requested-With");
	if (StringUtils.isBlank(requestType)) {
	    return false;
	}
	if ("XMLHttpRequest".equals(requestType)) {
	    return true;
	}
	return false;
    }

    public static boolean skipFilter(HttpServletRequest request) {
	String uri = request.getRequestURI();

	if (uri.endsWith("/home/loginEmployee.htm") || uri.endsWith("/home/login.htm") || uri.endsWith("/home/get_verify_code.htm")
		|| uri.endsWith("/home/logout.htm") || uri.contains("/res/css/")
		|| uri.contains("/res/img/") || uri.contains("/res/js/")
		|| uri.contains("/home/sys/init.htm")) {
	    return true;
	}
	return false;
    }
}
