package com.dinner.framework.util;

import org.apache.commons.lang.StringUtils;

public final class CityUtil {

    private CityUtil() {
    }

    /**
     * 转换成城市ID
     * 
     * @param pcaId
     *            省市区ID
     * @return
     */
    public static Integer toCity(Integer pcaId) {
	if (null == pcaId) {
	    return null;
	}

	String pcaIdStr = String.valueOf(pcaId);
	// 省
	if ("0000".equals(StringUtils.substring(pcaIdStr, -4))) {
	    return pcaId;
	}
	// 市
	else if ("00".equals(StringUtils.substring(pcaIdStr, -2))) {
	    return pcaId;
	}
	return Integer.parseInt(StringUtils.substring(pcaIdStr, 0, 4) + "00");
    }

    /**
     * 通过三级城市id获取他的父城市id 乘以100除以100
     * 
     * @param thirdCityId
     * @return
     */
    public static Integer getSecondCityId(Integer thirdCityId) {
	if (thirdCityId != null) {
	    return (thirdCityId / 100) * 100;
	}
	return null;
    }

    public static void main(String[] args) {
	System.out.println(CityUtil.getSecondCityId(500227));
	System.out.println(CityUtil.toCity(999999));
    }
}
