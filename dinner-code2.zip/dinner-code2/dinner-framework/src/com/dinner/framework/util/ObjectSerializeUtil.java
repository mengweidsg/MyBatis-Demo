package com.dinner.framework.util;

import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.dinner.framework.util.date.DateUtils;

/**
 * 对象序列化工具类
 * 
 * @author admin
 * 
 */
public final class ObjectSerializeUtil {

    private static Logger logger = Logger.getLogger(ObjectSerializeUtil.class);

    private ObjectSerializeUtil() {
	throw new UnsupportedOperationException("Can't be instanted!!");
    }

    /**
     * 对象序列化为map(现在只支持基本类型、枚举、日期)
     * 
     * @param obj
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static Map<String, String> objToMap(Object obj) {
	Map<String, String> resMap = new HashMap<String, String>();
	if (obj == null) {
	    return resMap;
	}
	try {
	    Class<?> cls = obj.getClass();
	    Field[] fields = cls.getDeclaredFields();
	    for (Field f : fields) {
		if (f.getName().equals("serialVersionUID") || Modifier.isStatic(f.getModifiers())) {
		    continue;
		}
		Object value = getFieldValue(obj, f);
		if (value != null
			&& (value instanceof Short || value instanceof Integer
				|| value instanceof Long || value instanceof Double
				|| value instanceof Float || value instanceof String
				|| value instanceof Byte || value instanceof Boolean || value instanceof Character)) {
		    resMap.put(f.getName(), String.valueOf(value));
		} else if (value != null && value instanceof Date) {
		    resMap.put(f.getName(), String.valueOf(((Date) value).getTime()));
		} else if (value != null && value instanceof Enum) {
		    resMap.put(f.getName(), ((Enum) value).name());
		} else if (value != null && value.getClass().isArray()) {
		    if (value.getClass().getComponentType().isPrimitive()) {
			int len = Array.getLength(value);
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < len; i++) {
			    sb.append(Array.get(value, i)).append(",");
			}
			resMap.put(f.getName(), sb.toString());
		    }

		}
	    }
	    return resMap;
	} catch (Exception e) {
	    logger.error("ObjectSerializeUtil -> objToMap", e);
	}
	return resMap;
    }

    /**
     * map反序列化为对象(现在只支持基本类型、枚举、日期)
     * 
     * @param map
     * @param cls
     * @return
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static <T> T mapToObj(Map<String, String> map, Class<T> cls) {
	if (map == null || map.size() == 0) {
	    return null;
	}
	try {
	    T obj = cls.newInstance();
	    Field[] fields = cls.getDeclaredFields();
	    for (Field f : fields) {
		String value = map.get(f.getName());
		if (value != null) {
		    if (f.getType() == Short.class || f.getType() == short.class) {
			setFieldValue(obj, Short.parseShort(value), f);
		    }
		    if (f.getType() == Integer.class || f.getType() == int.class) {
			setFieldValue(obj, Integer.parseInt(value), f);
		    }
		    if (f.getType() == Long.class || f.getType() == long.class) {
			setFieldValue(obj, Long.parseLong(value), f);
		    }
		    if (f.getType() == Double.class || f.getType() == double.class) {
			setFieldValue(obj, Double.parseDouble(value), f);
		    }
		    if (f.getType() == Float.class || f.getType() == float.class) {
			setFieldValue(obj, Float.parseFloat(value), f);
		    }
		    if (f.getType() == String.class) {
			setFieldValue(obj, value, f);
		    }
		    if (f.getType() == Byte.class || f.getType() == byte.class) {
			setFieldValue(obj, Byte.parseByte(value), f);
		    }
		    if (f.getType() == Boolean.class || f.getType() == boolean.class) {
			setFieldValue(obj, Boolean.parseBoolean(value), f);
		    }
		    if (f.getType() == Character.class || f.getType() == char.class) {
			setFieldValue(obj, value.charAt(0), f);
		    }
		    if (f.getType().getSuperclass() == Enum.class) {
			Class clazz = f.getType();
			setFieldValue(obj, Enum.valueOf(clazz, value), f);
		    }
		    if (f.getType() == Date.class) {
			setFieldValue(obj, DateUtils.valueOf(Long.parseLong(value)), f);
		    }
		    if (f.getType().isArray()) {
			if (f.getType().getComponentType().isPrimitive()) {
			    if (value != null) {
				String temp[] = value.split(",");
				Object objArry = Array.newInstance(f.getType().getComponentType(),
					temp.length);
				if (f.getType().getComponentType().getName().equals("double")) {
				    for (int i = 0; i < temp.length; i++) {
					Array.set(objArry, i, Double.parseDouble(temp[i]));
				    }
				    setFieldValue(obj, objArry, f);
				}
			    }
			}
		    }
		}
	    }
	    return obj;
	} catch (Exception e) {
	    logger.error("ObjectSerializeUtil -> mapToObj", e);
	}
	return null;
    }

    private static Object getFieldValue(Object obj, Field f) {
	boolean accessible = f.isAccessible();
	f.setAccessible(Boolean.TRUE);
	Object result = null;
	try {
	    result = f.get(obj);
	} catch (IllegalArgumentException e) {
	    logger.error("ObjectSerializeUtil -> getFieldValue", e);
	} catch (IllegalAccessException e) {
	    logger.error("ObjectSerializeUtil -> getFieldValue", e);
	}
	f.setAccessible(accessible);
	return result;
    }

    private static void setFieldValue(Object obj, Object value, Field f) {
	boolean accessible = f.isAccessible();
	f.setAccessible(Boolean.TRUE);
	try {
	    f.set(obj, value);
	} catch (IllegalArgumentException e) {
	    logger.error("ObjectSerializeUtil -> setFieldValue", e);
	} catch (IllegalAccessException e) {
	    logger.error("ObjectSerializeUtil -> setFieldValue", e);
	}
	f.setAccessible(accessible);
    }

    static class t {
	private int a;

	public int getA() {
	    return this.a;
	}
    }
}
