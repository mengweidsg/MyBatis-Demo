package com.dinner.framework.util.web;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;

import com.dinner.framework.util.date.DateRange;
import com.dinner.framework.util.date.DateUtils;
import com.dinner.framework.util.date.MonthRange;

public class ParamHandlerUtil {

    private static final Logger logger = Logger.getLogger(ParamHandlerUtil.class);

    public static DateRange handleDateRange(HttpServletRequest request, boolean isNow) {
	if (isNow) {
	    Date beginDate = null;
	    Date endDate = new Date();

	    String bDateStr = request.getParameter("beginDate");
	    if (StringUtils.isNotBlank(bDateStr)) {
		beginDate = DateUtils.parse(bDateStr, DateUtils.DATE_TIME_FORMAT);
	    } else {
		beginDate = new Date(endDate.getTime() - 60 * 1000); // 一分钟前
	    }

	    String eDateStr = request.getParameter("endDate");
	    if (StringUtils.isNotBlank(eDateStr)) {
		endDate = DateUtils.parse(eDateStr);
	    } else {
		endDate = DateUtils.addDay(endDate, 1);
	    }
	    // endDate = new Date();
	    return new DateRange(beginDate, DateUtils.parse(beginDate, DateUtils.DATE_TIME_FORMAT),
		    endDate, DateUtils.parse(endDate));
	} else {
	    return handleDateRange(request);
	}
    }

    public static DateRange handleDateRange(HttpServletRequest request) {
	String bDateStr = request.getParameter("beginDate");
	String eDateStr = request.getParameter("endDate");

	return innerHandleDateRange(bDateStr, eDateStr, false, true);
    }

    public static DateRange handlesuccDateRange(HttpServletRequest request) {
	String bDateStr = request.getParameter("succBeginDate");
	String eDateStr = request.getParameter("succEndDate");

	return innerSuccHandleDateRange(bDateStr, eDateStr, false);
    }

    public static DateRange handleDateRangeEndWithToday(HttpServletRequest request) {
	String bDateStr = request.getParameter("beginDate");
	String eDateStr = request.getParameter("endDate");

	return innerHandleDateRange(bDateStr, eDateStr, true, true);
    }

    public static DateRange handleMonthRange(HttpServletRequest request) {
	String bDateStr = request.getParameter("beginDate");
	String eDateStr = request.getParameter("endDate");

	return handleMonthRange(bDateStr, eDateStr);
    }

    private static DateRange handleMonthRange(String bDateStr, String eDateStr) {
	Date bDate = null;
	if (StringUtils.isNotBlank(bDateStr)) {
	    bDate = DateUtils.parse(bDateStr, DateUtils.DATE_MONTH_FORMAT);
	}

	Date eDate = null;
	if (StringUtils.isNotBlank(eDateStr)) {
	    eDate = DateUtils.parse(eDateStr, DateUtils.DATE_MONTH_FORMAT);
	}

	if (eDate == null) {
	    eDateStr = DateUtils.parse(DateUtils.addMonth(new Date(), 0),
		    DateUtils.DATE_MONTH_FORMAT);
	    eDate = DateUtils.parse(eDateStr, DateUtils.DATE_MONTH_FORMAT);
	}

	if (bDate == null) { // 最近一3个月
	    bDate = DateUtils.addMonth(eDate, -3);
	    bDateStr = DateUtils.parse(bDate, DateUtils.DATE_MONTH_FORMAT);
	}

	return new MonthRange(bDate, bDateStr, eDate, eDateStr);
    }

    public static DateRange handleDateRange(String bDateStr, String eDateStr,
	    boolean withDefaultValue) {
	return innerHandleDateRange(bDateStr, eDateStr, false, withDefaultValue);
    }

    private static DateRange innerHandleDateRange(String bDateStr, String eDateStr,
	    boolean endWithToday, boolean withDefaultValue) {
	Date bDate = null;
	if (StringUtils.isNotBlank(bDateStr)) {
	    if (DateUtils.isDate(bDateStr)) {
		bDate = DateUtils.parse(bDateStr);
	    } else {
		bDate = DateUtils.parse(bDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	Date eDate = null;
	if (StringUtils.isNotBlank(eDateStr)) {
	    if (DateUtils.isDate(eDateStr)) {
		eDate = DateUtils.parse(eDateStr);
	    } else {
		eDate = DateUtils.parse(eDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	if (withDefaultValue) {
	    if (eDate == null) {
		if (endWithToday)
		    eDate = DateUtils.beginTimeOfDay(new Date()); // 当前时间
		else
		    eDate = DateUtils.beginTimeOfDay(DateUtils.addDay(new Date(), 1)); // 当前时间后一天
		eDateStr = DateUtils.parse(eDate);
	    }

	    if (bDate == null) { // 一天
		bDate = new Date(DateUtils.beginTimeOfDay(eDate).getTime() - 7 * 24 * 60 * 60
			* 1000);
		bDateStr = DateUtils.parse(bDate);
	    }
	}
	return new DateRange(bDate, bDateStr, eDate, eDateStr);
    }

    public static DateRange handleDateRangeWithoutDefaultValue(HttpServletRequest request) {
	String bDateStr = request.getParameter("beginDate");
	String eDateStr = request.getParameter("endDate");

	Date bDate = null;
	if (StringUtils.isNotBlank(bDateStr)) {
	    if (DateUtils.isDate(bDateStr)) {
		bDate = DateUtils.parse(bDateStr);
	    } else {
		bDate = DateUtils.parse(bDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	Date eDate = null;
	if (StringUtils.isNotBlank(eDateStr)) {
	    if (DateUtils.isDate(eDateStr)) {
		eDate = DateUtils.parse(eDateStr);
	    } else {
		eDate = DateUtils.parse(eDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	return new DateRange(bDate, bDateStr, eDate, eDateStr);
    }

    private static DateRange innerSuccHandleDateRange(String bDateStr, String eDateStr,
	    boolean endWithToday) {
	Date bDate = null;
	if (StringUtils.isNotBlank(bDateStr)) {
	    if (DateUtils.isDate(bDateStr)) {
		bDate = DateUtils.parse(bDateStr);
	    } else {
		bDate = DateUtils.parse(bDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	Date eDate = null;
	if (StringUtils.isNotBlank(eDateStr)) {
	    if (DateUtils.isDate(eDateStr)) {
		eDate = DateUtils.parse(eDateStr);
	    } else {
		eDate = DateUtils.parse(eDateStr, DateUtils.DATE_TIME_FORMAT);
	    }
	}

	return new DateRange(bDate, bDateStr, eDate, eDateStr);
    }

    public static Date getDate(HttpServletRequest request, String dateParam) {
	dateParam = request.getParameter(dateParam);
	Date date = null;
	try {
	    if (DateUtils.isDate(dateParam)) {
		date = DateUtils.parse(dateParam);
	    } else {
		date = DateUtils.parse(dateParam, DateUtils.DATE_TIME_FORMAT);
	    }
	} catch (Exception e) {
	    logger.error("请求日期参数解析出错!", e);
	}
	return date;
    }

    public static Date getDate(String date) {
	Date d = null;
	if (StringUtils.isBlank(date)) {
	    return d;
	}
	try {
	    if (DateUtils.isDate(date)) {
		d = DateUtils.parse(date);
	    } else {
		d = DateUtils.parse(date, DateUtils.DATE_TIME_FORMAT);
	    }
	} catch (Exception e) {
	    logger.error("请求日期参数解析出错!", e);
	}
	return d;
    }
}
