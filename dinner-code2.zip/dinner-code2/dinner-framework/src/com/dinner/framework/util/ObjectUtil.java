package com.dinner.framework.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ObjectUtil {

    /**
     * 对对象进行深拷贝
     * 
     * @param t
     * @return
     */
    @SuppressWarnings("unchecked")
    public static <T> T deepCopy(T t) {

	ByteArrayOutputStream bo = null;
	ByteArrayInputStream bi = null;
	try {
	    bo = new ByteArrayOutputStream();
	    ObjectOutputStream oo = new ObjectOutputStream(bo);
	    oo.writeObject(t);

	    bi = new ByteArrayInputStream(bo.toByteArray());
	    ObjectInputStream oi = new ObjectInputStream(bi);
	    return (T) oi.readObject();
	} catch (Exception e) {
	    throw new RuntimeException(e);
	} finally {
	    try {
		if (bo != null) {
		    bo.close();
		}
		if (bi != null) {
		    bi.close();
		}
	    } catch (IOException e) {
	    }
	}
    }
}
