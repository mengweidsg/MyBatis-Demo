package com.dinner.framework.util.date;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dinner.framework.util.date.DateUtils;

public class DateRange {

    protected Date beginDate;
    protected Date endDate;

    protected String beginDateStr;
    protected String endDateStr;

    public DateRange() {

    }

    public DateRange(Date beginDate, Date endDate) {
	this.beginDate = beginDate;
	this.endDate = endDate;
    }

    public DateRange(Date bDate, String bDateStr, Date eDate, String eDateStr) {
	this.beginDate = bDate;
	this.beginDateStr = bDateStr;
	this.endDate = eDate;
	this.endDateStr = eDateStr;
    }

    public Date getBeginDate() {
	return beginDate;
    }

    public void setBeginDate(Date beginDate) {
	this.beginDate = beginDate;
    }

    public Date getEndDate() {
	return endDate;
    }

    public void setEndDate(Date endDate) {
	this.endDate = endDate;
    }

    public String getBeginDateStr() {
	return beginDateStr;
    }

    public void setBeginDateStr(String beginDateStr) {
	this.beginDateStr = beginDateStr;
    }

    public String getEndDateStr() {
	return endDateStr;
    }

    public void setEndDateStr(String endDateStr) {
	this.endDateStr = endDateStr;
    }

    public List<Date> rangeDates() {
	List<Date> dates = new ArrayList<Date>();
	if (beginDate != null && endDate != null) {
	    Date cur = beginDate;
	    do {
		dates.add(cur);
		cur = DateUtils.addDay(cur, 1);
	    } while (cur.compareTo(endDate) < 0);
	}
	return dates;
    }

    public List<String> rangeFormatDates() {
	List<String> dates = new ArrayList<String>();
	if (beginDate != null && endDate != null) {
	    Date cur = beginDate;
	    do {
		dates.add(DateUtils.parse(cur));
		cur = DateUtils.addDay(cur, 1);
	    } while (cur.compareTo(endDate) < 0);
	}
	return dates;
    }
}
