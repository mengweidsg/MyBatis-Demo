package com.dinner.framework.util.date;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.dinner.framework.util.date.DateUtils;

public class MonthRange extends DateRange {

    public MonthRange(Date bDate, String bDateStr, Date eDate, String eDateStr) {
	super.beginDate = bDate;
	super.beginDateStr = bDateStr;
	super.endDate = eDate;
	super.endDateStr = eDateStr;
    }

    @Override
    public List<String> rangeFormatDates() {
	List<String> months = new ArrayList<String>();

	if (beginDate != null && endDate != null) {
	    Date cur = beginDate;
	    do {
		months.add(DateUtils.parse(cur, DateUtils.DATE_MONTH_FORMAT));
		cur = DateUtils.addMonth(cur, 1);
	    } while (cur.compareTo(endDate) <= 0);
	}

	return months;
    }

    public List<Date> rangeDates() {
	List<Date> months = new ArrayList<Date>();
	if (beginDate != null && endDate != null) {
	    Date cur = beginDate;
	    do {
		months.add(cur);
		cur = DateUtils.addMonth(cur, 1);
	    } while (cur.compareTo(endDate) < 0);
	}
	return months;
    }
}
