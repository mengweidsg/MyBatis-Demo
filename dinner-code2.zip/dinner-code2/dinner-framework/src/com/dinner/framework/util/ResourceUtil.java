package com.dinner.framework.util;

import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * 读取应用配置的类
 * 
 * @author admin @createDate 2010-10-30
 */
public final class ResourceUtil {

    private final static Log log = LogFactory.getLog(ResourceUtil.class);

    private static ResourceBundle system;
    static {
	try {
	    system = ResourceBundle.getBundle("settings.conf");
	} catch (Exception e) {
	    log.error("systemConfig.properties Not Found. some keys lost.");
	}
    }

    /**
     * systemConfig
     * 
     * @param key
     * @return
     */
    public static String getSystem(final String key) {
	String msg = null;
	try {
	    msg = system.getString(key);
	} catch (Exception e) {
	    log.error("Key['" + key + "'] Not Found in systemConfig.properties .");
	}
	return msg == null ? system.getString("default") : msg;
    }

    /**
     * ESunny
     */
    private static ResourceBundle esunny;
    static {
	try {
	    esunny = ResourceBundle.getBundle("urlConfig");
	} catch (Exception e) {
	    log.error("urlConfig.properties Not Found. some keys lost.");
	}
    }

    public static WebServer getUrl(final String key) {
	String msg = null;
	try {
	    msg = esunny.getString(key);
	} catch (Exception e) {
	    log.error("Key['" + key + "'] Not Found in urlConfig.properties .");
	}
	return null == msg ? new WebServer(esunny.getString("default")) : new WebServer(msg);
    }

    public static WebServer getUrl(final String key, final String ad) {
	String msg = null;
	try {
	    msg = esunny.getString(key);
	} catch (Exception e) {
	    log.error("Key['" + key + "'] Not Found in urlConfig.properties .");
	}
	String result = null;
	if (null == msg) {
	    result = StringUtils.isBlank(ad) ? esunny.getString("default") : esunny
		    .getString("default") + ad;
	} else {
	    result = StringUtils.isBlank(ad) ? msg : msg + ad;
	}
	return new WebServer(result);
    }

    public static class WebServer {

	public WebServer(String domain) {
	    this.domain = domain;
	}

	private String domain;

	public String getDomain() {
	    return domain;
	}

	public void setDomain(String domain) {
	    this.domain = domain;
	}

	public String queryData(String param, String value) {
	    if (StringUtils.isBlank(this.domain))
		return "";
	    return (this.domain.lastIndexOf("?") > 0) ? (this.domain + "&" + param + "=" + value)
		    : (this.domain + "?" + param + "=" + value);
	}

	@Override
	public String toString() {
	    return (null == this.domain || "".equals(this.domain)) ? "/" : this.domain;
	}
    }
}
