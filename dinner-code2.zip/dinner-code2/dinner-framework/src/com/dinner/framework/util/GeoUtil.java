package com.dinner.framework.util;

/**
 * 地理坐标工具类,提供各种地理坐标间的转换
 * 
 * @author admin
 * 
 *         2013-9-18
 */
@SuppressWarnings("unused")
public class GeoUtil {
    // geometric
    private static final double _GRID_RADIX_ = 3E3;
    private static final double _MAX_dR_ = 2E-5;
    private static final double _MAX_dT_ = 3E-6;
    private static final double _LL2RAD_ = 0.0174532925194;
    private static final double _OFFSET_X_ = 0.0065;
    private static double _OFFSET_Y_ = 0.0060;

    private static final double EARTHRADIUS = 6370996.81;
    private static final double MCBAND[] = { 12890594.86, 8362377.87, 5591021, 3481989.83,
	    1678043.12, 0 };
    private static final double LLBAND[] = { 75, 60, 45, 30, 15, 0 };

    private static final double MC2LL[][] = {
	    { 1.410526172116255e-008, 8.983055096488720e-006, -1.99398338163310,
		    2.009824383106796e+002, -1.872403703815547e+002, 91.60875166698430,
		    -23.38765649603339, 2.57121317296198, -0.03801003308653, 1.733798120000000e+007 },
	    { -7.435856389565537e-009, 8.983055097726239e-006, -0.78625201886289,
		    96.32687599759846, -1.85204757529826, -59.36935905485877, 47.40033549296737,
		    -16.50741931063887, 2.28786674699375, 1.026014486000000e+007 },
	    { -3.030883460898826e-008, 8.983055099835780e-006, 0.30071316287616, 59.74293618442277,
		    7.35798407487100, -25.38371002664745, 13.45380521110908, -3.29883767235584,
		    0.32710905363475, 6.856817370000000e+006 },
	    { -1.981981304930552e-008, 8.983055099779535e-006, 0.03278182852591, 40.31678527705744,
		    0.65659298677277, -4.44255534477492, 0.85341911805263, 0.12923347998204,
		    -0.04625736007561, 4.482777060000000e+006 },
	    { 3.091913710684370e-009, 8.983055096812155e-006, 0.00006995724062, 23.10934304144901,
		    -0.00023663490511, -0.63218178102420, -0.00663494467273, 0.03430082397953,
		    -0.00466043876332, 2.555164400000000e+006 },
	    { 2.890871144776878e-009, 8.983055095805407e-006, -0.00000003068298, 7.47137025468032,
		    -0.00000353937994, -0.02145144861037, -0.00001234426596, 0.00010322952773,
		    -0.00000323890364, 8.260885000000000e+005 } };

    private static final double LL2MC[][] = {
	    { -0.00157021024440, 1.113207020616939e+005, 1.704480524535203e+015,
		    -1.033898737604234e+016, 2.611266785660388e+016, -3.514966917665370e+016,
		    2.659570071840392e+016, -1.072501245418824e+016, 1.800819912950474e+015,
		    82.50000000000000 },
	    { 8.277824516172526e-004, 1.113207020463578e+005, 6.477955746671608e+008,
		    -4.082003173641316e+009, 1.077490566351142e+010, -1.517187553151559e+010,
		    1.205306533862167e+010, -5.124939663577472e+009, 9.133119359512032e+008,
		    67.50000000000000 },
	    { 0.00337398766765, 1.113207020202162e+005, 4.481351045890365e+006,
		    -2.339375119931662e+007, 7.968221547186455e+007, -1.159649932797253e+008,
		    9.723671115602145e+007, -4.366194633752821e+007, 8.477230501135234e+006,
		    52.50000000000000 },
	    { 0.00220636496208, 1.113207020209128e+005, 5.175186112841131e+004,
		    3.796837749470245e+006, 9.920137397791013e+005, -1.221952217112870e+006,
		    1.340652697009075e+006, -6.209436990984312e+005, 1.444169293806241e+005,
		    37.50000000000000 },
	    { -3.441963504368392e-004, 1.113207020576856e+005, 2.782353980772752e+002,
		    2.485758690035394e+006, 6.070750963243378e+003, 5.482118345352118e+004,
		    9.540606633304236e+003, -2.710553267466450e+003, 1.405483844121726e+003,
		    22.50000000000000 },
	    { -3.218135878613132e-004, 1.113207020701615e+005, 0.00369383431289,
		    8.237256402795718e+005, 0.46104986909093, 2.351343141331292e+003,
		    1.58060784298199, 8.77738589078284, 0.37238884252424, 7.45000000000000 } };

    /**
     * 地理位置类
     * 
     * @author admin
     * 
     *         2013-9-18
     */
    public static class GeoPoint {
	public GeoPoint(double lng, double lat) {
	    this.lng = lng;
	    this.lat = lat;
	}

	// 经度
	private final double lng;
	// 纬度
	private final double lat;

	public double getLng() {
	    return lng;
	}

	public double getLat() {
	    return lat;
	}

	public String toString() {
	    return "(" + lng + "," + lat + ")";
	}
    }

    /**
     * 地理坐标系类型
     * 
     * @author admin
     * 
     *         2013-9-18
     */
    public static enum GeoType {
	/**
	 * 墨卡托坐标系
	 */
	// MC,
	/**
	 * GPS使用的坐标系(除天朝外国际通用的坐标系,从原始GPS设备上拿到的坐标通常都使用GPS坐标系)
	 */
	WGS84,
	/**
	 * 天朝坐标系,GPS坐标经过见不得人的加密后得到(中国大陆境内多使用此坐标系,党的荣光普照全地,阿门！)
	 * 什么是天朝?就是集合了商的酒池肉林,周的贵族世袭,秦的言论管制,汉的好大喜功,晋魏的炫富糜烂,南北朝的文化断层,隋的大兴土木,
	 * 唐的雍容体态,宋的软弱外交,元的税赋镇压,明的腐败党争,清的专制封闭——可谓集古今之大成！此乃天朝也！
	 */
	GCJ02,
	/**
	 * 百度坐标系(在天朝坐标系基础上又动了点手脚)
	 */
	BD09
    }

    /**
     * 地理坐标转换
     * 
     * @param from
     *            源坐标系
     * @param to
     *            目的坐标系
     * @param oldlng
     *            源经度
     * @param oldlat
     *            源纬度
     * @return 转换后的经纬度
     */
    public static GeoPoint convertGeo(GeoType from, GeoType to, double oldlng, double oldlat) {
	GeoPoint newxy = new GeoPoint(oldlng, oldlat);
	if (from == to) {
	    return newxy;
	}
	/* 第一步先把传入的坐标转成国测局坐标 */
	if (from == GeoType.WGS84) {
	    /* 国际坐标先经过国测局一次加密 */
	    GcjEncriptor encryptor = new GcjEncriptor();
	    newxy = encryptor.encrypt(newxy.lng, newxy.lat);
	} else if (from == GeoType.BD09) {
	    /* 百度坐标先解密成国测局坐标 */
	    newxy = bd_decrypt(newxy.lng, newxy.lat);
	}

	/* 第二步把国测局坐标转成目标坐标 */
	if (to == GeoType.WGS84) {
	    /* 国测局解密后就是国际坐标 */
	    newxy = gcj_decrypt(newxy.lng, newxy.lat);
	} else if (to == GeoType.BD09) {
	    /* 国测局加密成百度坐标 */
	    newxy = bd_encrypt(newxy.lng, newxy.lat);
	}
	return newxy;
    }

    private static GeoPoint _conv_(double lng, double lat, double factor[]) {
	lng = factor[0] + factor[1] * Math.abs(lng);
	double temp = Math.abs(lat) / factor[9];
	lat = factor[2] + factor[3] * temp + factor[4] * temp * temp + factor[5] * temp * temp
		* temp + factor[6] * temp * temp * temp * temp + factor[7] * temp * temp * temp
		* temp * temp + factor[8] * temp * temp * temp * temp * temp * temp;
	lng *= (lng < 0 ? -1 : 1);
	lat *= (lat < 0 ? -1 : 1);
	return new GeoPoint(lng, lat);
    }

    private static double _get_delta_r_(double y0) {
	return Math.sin(y0 * _GRID_RADIX_ * _LL2RAD_) * _MAX_dR_;
    }

    private static double _get_delta_t_(double x0) {
	return Math.cos(x0 * _GRID_RADIX_ * _LL2RAD_) * _MAX_dT_;
    }

    /**
     * transform from lat-lon to mercator.
     * 
     * @param pt
     *            point.
     * @return result point.
     */
    private static GeoPoint ll2mc(GeoPoint point) {
	double lng = point.lng;
	if (lng > 180.0) {
	    lng = 180.0;
	} else if (lng < -180.0) {
	    lng = -180.0;
	}

	double lat = point.lat;
	if (lat < 1E-7 && lat >= 0.0) {
	    lat = 1E-7;
	} else if (lat < 0 && lat > -1.0E-7) {
	    lat = -1E-7;
	} else if (lat > 74) {
	    lat = 74;
	} else if (lat < -74) {
	    lat = -74;
	}
	double factor[] = new double[10];
	for (int i = 0; i < LLBAND.length; i++) {
	    if (Math.abs(lat) > LLBAND[i]) {
		factor = LL2MC[i];
		break;
	    }
	}
	return _conv_(lng, lat, factor);
    }

    /**
     * transform from mercator to lat-lon.
     * 
     * @param pt
     *            point.
     * @return result point.
     */
    private static GeoPoint mc2ll(double lng, double lat) {
	double tmplng = lng;
	if (tmplng > 20037508.342) {
	    tmplng = 20037508.342;
	} else if (tmplng < -20037508.342) {
	    tmplng = -20037508.342;
	}
	double tmplat = lat;
	if (tmplat < 1E-6 && tmplat >= 0) {
	    tmplat = 1E-6;
	} else if (tmplat < 0 && tmplat > -1.0E-6) {
	    tmplat = -1E-6;
	} else if (tmplat > 20037508.342) {
	    tmplat = 20037508.342;
	} else if (tmplat < -20037508.342) {
	    tmplat = -20037508.342;
	}

	double[] factor = new double[10];
	for (int i = 0; i < MCBAND.length; i++) {
	    if (Math.abs(tmplat) > MCBAND[i]) {
		factor = MC2LL[i];
		break;
	    }
	}
	return _conv_(tmplng, tmplat, factor);
    }

    /**
     * 将天朝坐标再次加密,得到百度坐标
     * 
     * @param lng
     * @param lat
     * @return
     */
    private static GeoPoint bd_encrypt(double lng, double lat) {
	double x0 = lng;
	double y0 = lat;
	double r0 = Math.sqrt(x0 * x0 + y0 * y0);
	double theta0 = Math.atan2(y0, x0);
	double r1 = r0 + _get_delta_r_(y0);
	double theta1 = theta0 + _get_delta_t_(x0);
	double x1 = r1 * Math.cos(theta1), y1 = r1 * Math.sin(theta1);
	GeoPoint res = new GeoPoint(x1 + _OFFSET_X_, y1 + _OFFSET_Y_);
	return res;
    }

    /**
     * 解密百度坐标(得到的是天朝坐标)
     * 
     * @param lng
     * @param lat
     * @return
     */
    private static GeoPoint bd_decrypt(double lng, double lat) {
	double x0 = lng - _OFFSET_X_;
	double y0 = lat - _OFFSET_Y_;
	double r0 = Math.sqrt(x0 * x0 + y0 * y0);
	double theta0 = Math.atan2(y0, x0);
	double r1 = r0 - _get_delta_r_(y0);
	double theta1 = theta0 - _get_delta_t_(x0);
	double x1 = r1 * Math.cos(theta1), y1 = r1 * Math.sin(theta1);
	GeoPoint res = new GeoPoint(x1, y1);
	return res;
    }

    /**
     * 天朝坐标加密器,负责把国际坐标(WGS84)加密成天朝坐标(GCJ02)
     * 
     * @author admin
     * 
     *         2013-9-24
     */
    private static class GcjEncriptor {
	double casm_rr = 0;
	double casm_t1 = 0;
	double casm_t2 = 0;
	double casm_x1 = 0;
	double casm_y1 = 0;
	double casm_x2 = 0;
	double casm_y2 = 0;
	double casm_f = 0;

	public GcjEncriptor() {
	    this.casm_rr = 0;
	    this.casm_t1 = 0;
	    this.casm_t2 = 0;
	    this.casm_x1 = 0;
	    this.casm_y1 = 0;
	    this.casm_x2 = 0;
	    this.casm_y2 = 0;
	    this.casm_f = 0;
	}

	protected double yj_sin2(double x) {
	    double tt;
	    double ss;
	    double ff;
	    double s2;
	    int cc;
	    ff = 0;
	    if (x < 0) {
		x = -x;
		ff = 1;
	    }

	    cc = (int) (x / 6.28318530717959);

	    tt = x - cc * 6.28318530717959;
	    if (tt > 3.1415926535897932) {
		tt = tt - 3.1415926535897932;
		if (ff == 1) {
		    ff = 0;
		} else if (ff == 0) {
		    ff = 1;
		}
	    }
	    x = tt;
	    ss = x;
	    s2 = x;
	    tt = tt * tt;
	    s2 = s2 * tt;
	    ss = ss - s2 * 0.166666666666667;
	    s2 = s2 * tt;
	    ss = ss + s2 * 8.33333333333333E-03;
	    s2 = s2 * tt;
	    ss = ss - s2 * 1.98412698412698E-04;
	    s2 = s2 * tt;
	    ss = ss + s2 * 2.75573192239859E-06;
	    s2 = s2 * tt;
	    ss = ss - s2 * 2.50521083854417E-08;
	    if (ff == 1) {
		ss = -ss;
	    }
	    return ss;
	}

	protected double Transform_yj5(double x, double y) {
	    double tt;
	    tt = 300 + 1 * x + 2 * y + 0.1 * x * x + 0.1 * x * y + 0.1 * Math.sqrt(x);
	    tt = tt + (20 * yj_sin2(18.849555921538764 * x) + 20 * yj_sin2(6.283185307179588 * x))
		    * 0.6667;
	    tt = tt + (20 * yj_sin2(3.141592653589794 * x) + 40 * yj_sin2(1.047197551196598 * x))
		    * 0.6667;
	    tt = tt
		    + (150 * yj_sin2(0.2617993877991495 * x) + 300 * yj_sin2(0.1047197551196598 * x))
		    * 0.6667;
	    return tt;
	}

	protected double Transform_yjy5(double x, double y) {
	    double tt;
	    tt = -100 + 2 * x + 3 * y + 0.2 * y * y + 0.1 * x * y + 0.2
		    * Math.sqrt(Math.sqrt(x * x));
	    tt = tt + (20 * yj_sin2(18.849555921538764 * x) + 20 * yj_sin2(6.283185307179588 * x))
		    * 0.6667;
	    tt = tt + (20 * yj_sin2(3.141592653589794 * y) + 40 * yj_sin2(1.047197551196598 * y))
		    * 0.6667;
	    tt = tt
		    + (160 * yj_sin2(0.2617993877991495 * y) + 320 * yj_sin2(0.1047197551196598 * y))
		    * 0.6667;
	    return tt;
	}

	protected double Transform_jy5(double x, double xx) {
	    double n;
	    double a;
	    double e;
	    a = 6378245;
	    e = 0.00669342;
	    n = Math.sqrt(1 - e * yj_sin2(x * 0.0174532925199433) * yj_sin2(x * 0.0174532925199433));
	    n = (xx * 180) / (a / n * Math.cos(x * 0.0174532925199433) * 3.1415926);
	    return n;
	}

	protected double Transform_jyj5(double x, double yy) {
	    double m;
	    double a;
	    double e;
	    double mm;
	    a = 6378245;
	    e = 0.00669342;
	    mm = 1 - e * yj_sin2(x * 0.0174532925199433) * yj_sin2(x * 0.0174532925199433);
	    m = (a * (1 - e)) / (mm * Math.sqrt(mm));
	    return (yy * 180) / (m * 3.1415926);
	}

	protected int r_yj() {
	    return 0;
	}

	protected double random_yj() {
	    double t;
	    double casm_a = 314159269;
	    double casm_c = 453806245;
	    casm_rr = casm_a * casm_rr + casm_c;
	    t = (int) (casm_rr / 2);
	    casm_rr = casm_rr - t * 2;
	    casm_rr = casm_rr / 2;
	    return (casm_rr);
	}

	protected void IniCasm(double w_time, double w_lng, double w_lat) {
	    double tt;
	    casm_t1 = w_time;
	    casm_t2 = w_time;
	    tt = (int) (w_time / 0.357);
	    casm_rr = w_time - tt * 0.357;
	    if (w_time == 0)
		casm_rr = 0.3;
	    casm_x1 = w_lng;
	    casm_y1 = w_lat;
	    casm_x2 = w_lng;
	    casm_y2 = w_lat;
	    casm_f = 3;
	}

	private GeoPoint wgtochina_lb(int wg_flag, int wg_lng, int wg_lat, int wg_heit,
		int wg_week, int wg_time) {
	    double x_add;
	    double y_add;
	    double h_add;
	    double x_l;
	    double y_l;
	    double casm_v;
	    double t1_t2;
	    double x1_x2;
	    double y1_y2;
	    GeoPoint point = null;
	    if (wg_heit > 5000) {
		return point;
	    }
	    x_l = wg_lng;
	    x_l = x_l / 3686400.0;
	    y_l = wg_lat;
	    y_l = y_l / 3686400.0;
	    if (x_l < 72.004) {
		return point;
	    }
	    if (x_l > 137.8347) {
		return point;
	    }
	    if (y_l < 0.8293) {
		return point;
	    }
	    if (y_l > 55.8271) {
		return point;
	    }
	    // add by admin
	    IniCasm(wg_time, wg_lng, wg_lat);
	    if (wg_flag == 0) {
		IniCasm(wg_time, wg_lng, wg_lat);
		point = new GeoPoint(wg_lng, wg_lat);
		return point;
	    }
	    casm_t2 = wg_time;
	    t1_t2 = (casm_t2 - casm_t1) / 1000.0;
	    if (t1_t2 <= 0) {
		casm_t1 = casm_t2;
		casm_f = casm_f + 1;
		casm_x1 = casm_x2;
		casm_f = casm_f + 1;
		casm_y1 = casm_y2;
		casm_f = casm_f + 1;
	    } else {
		if (t1_t2 > 120) {
		    if (casm_f == 3) {
			casm_f = 0;
			casm_x2 = wg_lng;
			casm_y2 = wg_lat;
			x1_x2 = casm_x2 - casm_x1;
			y1_y2 = casm_y2 - casm_y1;
			casm_v = Math.sqrt(x1_x2 * x1_x2 + y1_y2 * y1_y2) / t1_t2;
			if (casm_v > 3185) {
			    return (point);
			}
		    }
		    casm_t1 = casm_t2;
		    casm_f = casm_f + 1;
		    casm_x1 = casm_x2;
		    casm_f = casm_f + 1;
		    casm_y1 = casm_y2;
		    casm_f = casm_f + 1;
		}
	    }
	    x_add = Transform_yj5(x_l - 105, y_l - 35);
	    y_add = Transform_yjy5(x_l - 105, y_l - 35);
	    h_add = wg_heit;
	    x_add = x_add + h_add * 0.001 + yj_sin2(wg_time * 0.0174532925199433) + random_yj();
	    y_add = y_add + h_add * 0.001 + yj_sin2(wg_time * 0.0174532925199433) + random_yj();
	    double lng = ((x_l + Transform_jy5(y_l, x_add)) * 3686400);
	    double lat = ((y_l + Transform_jyj5(y_l, y_add)) * 3686400);
	    point = new GeoPoint(lng, lat);
	    return point;
	}

	public GeoPoint encrypt(double x, double y) {
	    double x1, tempx;
	    double y1, tempy;
	    x1 = x * 3686400.0;
	    y1 = y * 3686400.0;
	    GeoPoint point = wgtochina_lb(1, (int) x1, (int) y1, 1, 0, 0);
	    if (point == null) {
		// 不合法的
		return point;
	    }
	    tempx = point.getLng();
	    tempy = point.getLat();
	    tempx = tempx / 3686400.0;
	    tempy = tempy / 3686400.0;
	    point = new GeoPoint(tempx, tempy);
	    return point;
	}
    }

    private static double dis(double x1, double y1, double x2, double y2) {
	return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    }

    /**
     * 将天朝坐标系解密成国际坐标系(使用二分查找法)
     * 
     * @param lng
     * @param lat
     * @return
     */
    private static GeoPoint gcj_decrypt(double lng, double lat) {
	double xmid = lng, ymid = lat;
	double cellsize = 1;
	double realgcjx = lng, realgcjy = lat;
	double x1 = xmid - cellsize, x1new = 0;
	double y1 = ymid + cellsize, y1new = 0;
	double x2 = xmid - cellsize, x2new = 0;
	double y2 = ymid - cellsize, y2new = 0;
	double x3 = xmid + cellsize, x3new = 0;
	double y3 = ymid - cellsize, y3new = 0;
	double x4 = xmid + cellsize, x4new = 0;
	double y4 = ymid + cellsize, y4new = 0;
	double xmidnew, ymidnew;
	double gpsx = 0.0, gpsy = 0.0;
	GcjEncriptor encryptor = new GcjEncriptor();
	GeoPoint encLoc = encryptor.encrypt(xmid, ymid);
	xmidnew = encLoc.lng;
	ymidnew = encLoc.lat;
	double err = 1e-7;
	if (dis(xmidnew, ymidnew, realgcjx, realgcjy) <= err) {
	    gpsx = xmid;
	    gpsy = ymid;
	} else {
	    while (true) {// 有迭代的必要
		x1 = xmid - cellsize;
		x1new = 0;
		y1 = ymid + cellsize;
		y1new = 0;
		x2 = xmid - cellsize;
		x2new = 0;
		y2 = ymid - cellsize;
		y2new = 0;
		x3 = xmid + cellsize;
		x3new = 0;
		y3 = ymid - cellsize;
		y3new = 0;
		x4 = xmid + cellsize;
		x4new = 0;
		y4 = ymid + cellsize;
		y4new = 0;
		GeoPoint newLoc = encryptor.encrypt(x1, y2);
		x1new = newLoc.lng;
		y1new = newLoc.lat;
		newLoc = encryptor.encrypt(x2, y2);
		x2new = newLoc.lng;
		y2new = newLoc.lat;
		newLoc = encryptor.encrypt(x3, y3);
		x3new = newLoc.lng;
		y3new = newLoc.lat;
		newLoc = encryptor.encrypt(x4, y4);
		x4new = newLoc.lng;
		y4new = newLoc.lat;
		double dis1 = dis(x1new, y1new, realgcjx, realgcjy);
		double dis2 = dis(x2new, y2new, realgcjx, realgcjy);
		double dis3 = dis(x3new, y3new, realgcjx, realgcjy);
		double dis4 = dis(x4new, y4new, realgcjx, realgcjy);
		if (dis1 < err) {
		    gpsx = x1;
		    gpsy = y1;
		    break;
		}
		if (dis2 < err) {
		    gpsx = x2;
		    gpsy = y2;
		    break;
		}
		if (dis3 < err) {
		    gpsx = x3;
		    gpsy = y3;
		    break;
		}
		if (dis4 < err) {
		    gpsx = x4;
		    gpsy = y4;
		    break;
		}
		// 四个都不为0
		double w1 = 1 / dis1, w2 = 1 / dis2, w3 = 1 / dis3, w4 = 1 / dis4;
		xmid = (x1 * w1 + x2 * w2 + x3 * w3 + x4 * w4) / (w1 + w2 + w3 + w4);
		ymid = (y1 * w1 + y2 * w2 + y3 * w3 + y4 * w4) / (w1 + w2 + w3 + w4);
		newLoc = encryptor.encrypt(xmid, ymid);
		xmidnew = newLoc.lng;
		ymidnew = newLoc.lat;
		double dismid = dis(xmidnew, ymidnew, realgcjx, realgcjy);
		if (dismid <= err) {
		    gpsx = xmid;
		    gpsy = ymid;
		    break;
		}
		cellsize *= 0.6;
		if (cellsize < err) {
		    gpsx = xmid;
		    gpsy = ymid;
		    break;
		}
	    }
	}
	gpsx -= 3e-6;
	gpsy += 2e-6;
	return new GeoPoint(gpsx, gpsy);
    }

    // 框住苏州的矩形(两个点,左上-右下)
    private static final double[] szArea = new double[] { 120.457423, 31.457855, 120.843766,
	    31.266433 };

    /**
     * 判断一个地理坐标是否在苏州
     * 
     * @param lng
     * @param lat
     * @return
     */
    public static boolean isInSuZhou(double lng, double lat) {
	return isInRect(lng, lat, szArea);
    }

    // 判定一个坐标点是否在一个方块内,rect内的数值为左上-右下的坐标
    private static boolean isInRect(double lng, double lat, double[] rect) {
	double x = lng;
	double y = lat;
	double x1 = rect[0];
	double y1 = rect[1];
	double x2 = rect[2];
	double y2 = rect[3];
	return x >= x1 && x <= x2 && y >= y2 && y <= y1;
    }

    // 地理位置分割的方块，每个数组存放四个浮点数，分别表示左上经、纬度-右下经、纬度
    // 5个方块，依次为北京，上海，杭州
    private static double[][] rects = new double[][] {
	    new double[] { 116.036898, 40.203861, 116.860177, 39.711864 },
	    new double[] { 121.086956, 31.508851, 122.050514, 30.737255 },
	    new double[] { 119.723256, 30.540383, 120.640821, 29.965374 } };

}
