package com.dinner.framework.util.date;

import org.apache.commons.lang.StringUtils;

import java.beans.PropertyEditorSupport;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DateUtils extends PropertyEditorSupport {

    public static final String yyyy_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";

    public static final String DATE_FORMAT = "yyyy-MM-dd";

    public static final String DATE_MONTH_FORMAT = "yyyy-MM";

    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static final String DATE_DAY_FORMAT = "yyyyMMdd";

    private String dateFormat = "yyyy-MM-dd";

    public void setDateFormat(String dateFormat) {
	this.dateFormat = dateFormat;
    }

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
	System.out.println("set Text");
	SimpleDateFormat frm = new SimpleDateFormat(dateFormat);
	try {
	    Date date = frm.parse(text);
	    this.setValue(date);
	} catch (Exception exp) {
	    exp.printStackTrace();
	}

    }

    /**
     * 如果解析错误则返回null
     * 
     * @param text
     * @return
     */
    public static Date parse(String text) {
	if (StringUtils.isBlank(text)) {
	    return null;
	}
	text = text.trim();
	SimpleDateFormat frm = new SimpleDateFormat(DATE_FORMAT);
	try {
	    return frm.parse(text);
	} catch (ParseException e) {
	    return null;
	}
    }

    public static Date parse(String text, String format) {
	if (StringUtils.isBlank(text)) {
	    return null;
	}
	SimpleDateFormat frm = new SimpleDateFormat(format);
	try {
	    return frm.parse(text);
	} catch (ParseException e) {
	    return null;
	}
    }

    public static String parse(Date date) {
	if (date == null) {
	    return "";
	}
	SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
	return format.format(date);
    }

    public static String parse(Date date, String format) {
	if (date == null) {
	    return "";
	}
	SimpleDateFormat fmat = new SimpleDateFormat(format);
	return fmat.format(date);
    }

    /**
     * 把时间的时分秒设置为 23:59:59 999
     * 
     * @param date
     * @return
     */
    public static Date endTimeOfDay(Date date) {
	if (date == null) {
	    return null;
	}
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.HOUR_OF_DAY, 23);
	cal.set(Calendar.MINUTE, 59);
	cal.set(Calendar.SECOND, 59);
	cal.set(Calendar.MILLISECOND, 999);
	return cal.getTime();
    }

    /**
     * 把时间的时分秒设置为 0:0:0 0
     * 
     * @param date
     * @return
     */
    public static Date beginTimeOfDay(Date date) {
	if (date == null) {
	    return null;
	}
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.HOUR_OF_DAY, 0);
	cal.set(Calendar.MINUTE, 0);
	cal.set(Calendar.SECOND, 0);
	cal.set(Calendar.MILLISECOND, 0);
	return cal.getTime();
    }

    /**
     * 在当前日期的基础上加减天数
     * 
     * @param date
     * @param day
     * @return
     */
    public static Date addDay(Date date, int day) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.DAY_OF_MONTH, cal.get(Calendar.DAY_OF_MONTH) + day);
	return cal.getTime();
    }

    /**
     * 是否只包含日期部分，不包含时分秒部分
     * 
     * @param input
     * @return
     */
    public static boolean isDate(String input) {
	if (StringUtils.isBlank(input)) {
	    return false;
	}
	Matcher matcher = Pattern.compile(
		"^(\\d{4})-(0\\d{1}|[1-9]|1[0-2])-([1-9]|0\\d{1}|[12]\\d{1}|3[01])$")
		.matcher(input);
	return matcher.matches();
    }

    public static boolean isDateTime(String input, String formt) {
	SimpleDateFormat df = new SimpleDateFormat(formt);
	try {
	    df.parse(input);
	    return true;
	} catch (ParseException e) {
	    return false;
	}
    }

    public static int getHour(Date date) {
	Calendar calendar = Calendar.getInstance();
	calendar.setTime(date);
	return calendar.get(Calendar.HOUR_OF_DAY);
    }

    public static Date getDate(String date) {
	return getDate(date, yyyy_MM_DD_HH_MM_SS);
    }

    public static Date getDate(String date, String format) {
	SimpleDateFormat df = new SimpleDateFormat(format);
	try {
	    return df.parse(date);
	} catch (ParseException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}

	return null;
    }

    public static int getDate(Date date) {
	Calendar calendar = Calendar.getInstance();
	calendar.setTime(date);
	return calendar.get(Calendar.DAY_OF_MONTH);
    }

    public static String getDate(Date date, String format) {
	SimpleDateFormat df = new SimpleDateFormat(format);
	return df.format(date);
    }

    /**
     * 指定时间的凌晨
     * 
     * @param date
     * @return
     */
    public static Date getDateZero(Date date) {
	date = org.apache.commons.lang.time.DateUtils.setHours(date, 0);
	date = org.apache.commons.lang.time.DateUtils.setMinutes(date, 0);
	date = org.apache.commons.lang.time.DateUtils.setSeconds(date, 0);
	date = org.apache.commons.lang.time.DateUtils.setMilliseconds(date, 0);
	return date;
    }

    public static Calendar getDateZeroCalendar(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.SECOND, 0);
	cal.set(Calendar.MINUTE, 0);
	cal.set(Calendar.MILLISECOND, 0);
	cal.set(Calendar.HOUR_OF_DAY, 0);
	return cal;
    }

    public static Date addMonth(Date date, int i) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.MONTH, cal.get(Calendar.MONTH) + i);
	return cal.getTime();
    }

    /**
     * 每周从星期一开始、星期天结束
     * 
     * @param date
     * @return
     */
    public static int getDayOfWeek(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	int day = cal.get(Calendar.DAY_OF_WEEK);
	if (day == 1)
	    day = 7;
	else
	    day--;
	return day;
    }

    public static int getWeekOfYear(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	return cal.get(Calendar.WEEK_OF_YEAR);
    }

    public static int getWeekOfYearBeginOfMonday(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	int weekOfYear = cal.get(Calendar.WEEK_OF_YEAR);
	int day = cal.get(Calendar.DAY_OF_WEEK);
	if (day == 1) { // 星期天
	    weekOfYear--;
	}
	return weekOfYear;
    }

    public static int getYear(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	return cal.get(Calendar.YEAR);
    }

    public static int getMonth(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	return cal.get(Calendar.MONTH);
    }

    public static int getMinute(Date date) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	return cal.get(Calendar.MINUTE);
    }

    /**
     * 月初第一天
     * 
     * @param date
     * @return
     */
    public static Date beginOfMonth(Date date) {
	if (date == null)
	    return date;
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.DAY_OF_MONTH, 1);
	return cal.getTime();
    }

    /**
     * n为推迟的周数，0本周，-1向前推迟一周，1下周，依次类推
     * 
     * @param n
     * @param weekDay
     * @return
     */
    public static String getWeekDay(int n, int weekDay) {
	Calendar cal = Calendar.getInstance();

	cal.add(Calendar.DATE, n * 7);
	// 想周几，这里就传几Calendar.MONDAY（TUESDAY...）
	cal.set(Calendar.DAY_OF_WEEK, weekDay);
	return new SimpleDateFormat("yyyy-MM-dd").format(cal.getTime()) + " 00:00:00";
    }

    public static Date valueOf(long timestamp) {
	Calendar calendar=Calendar.getInstance();
	calendar.setTimeInMillis(timestamp);
	return calendar.getTime();
    }

    public static void main(String[] args) {
	System.out.println(getMonth(new Date()));
    }

    public static void recursionDay(Date begin, Date end, List<String> allDays) {
	if (begin.after(end)) {
	    return;
	}

	Date b = DateUtils.beginTimeOfDay(begin);
	Date e = DateUtils.endTimeOfDay(begin);
	if (e.after(end)) {
	    e = end;
	}

	allDays.add(DateUtils.parse(b));

	recursionDay(DateUtils.beginTimeOfDay(DateUtils.addDay(begin, 1)), end, allDays);

    }

    public static void recursionMonth(Date begin, Date end) {
	if (begin.after(end)) {
	    return;
	}
	Calendar cal = Calendar.getInstance();
	cal.setTime(begin);
	cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));

	Date e = cal.getTime();
	e = DateUtils.endTimeOfDay(e);
	if (e.after(end)) {
	    e = end;
	}

	recursionMonth(DateUtils.beginTimeOfDay(DateUtils.addDay(e, 1)), end);
    }

    public static void recursionWeek(Date begin, Date end, List<Date> lastDayOfWeek) {
	if (begin.after(end)) {
	    return;
	}
	Calendar cal = Calendar.getInstance();
	cal.setTime(begin);
	int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
	dayOfWeek = dayOfWeek == 1 ? 7 : dayOfWeek - 1;
	Date b = DateUtils.beginTimeOfDay(begin);

	Date e;
	if (dayOfWeek == 7) {
	    e = DateUtils.endTimeOfDay(begin);
	} else {
	    e = DateUtils.addDay(b, 7 - dayOfWeek);
	    e = DateUtils.endTimeOfDay(e);
	}

	if (e.after(end)) {
	    e = end;
	}

	lastDayOfWeek.add(e);

	recursionWeek(DateUtils.beginTimeOfDay(DateUtils.addDay(e, 1)), end, lastDayOfWeek);

    }

    public static void recursionWeek(Date begin, Date end, Map<Date, Date> weekDates) {
	if (begin.after(end)) {
	    return;
	}
	Calendar cal = Calendar.getInstance();
	cal.setTime(begin);
	int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
	dayOfWeek = dayOfWeek == 1 ? 7 : dayOfWeek - 1;
	Date b = DateUtils.beginTimeOfDay(begin);

	Date e;
	if (dayOfWeek == 7) {
	    e = begin;
	} else {
	    e = DateUtils.addDay(b, 7 - dayOfWeek);
	}

	if (e.equals(end) || e.after(end)) {
	    e = end;
	} else {
	    e = DateUtils.addDay(e, 1);
	}

	weekDates.put(b, e);

	if (!e.equals(end)) {
	    recursionWeek(e, end, weekDates);
	}

    }

    /**
     * 判断日期是否昨天 或者前天.....
     * 
     * @param paramDate
     *            要判断的时间
     * @param day
     *            昨天传1 前天传2以此类推
     * @return
     * @throws ParseException
     */
    public static boolean judgeDay(Date paramDate, Integer day) throws ParseException {
	Date date = new Date();
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	String todayStr = format.format(date);
	// 得到今天零时零分零秒这一时刻
	Date today = format.parse(todayStr);
	// 与今日零时零分零秒比较
	if ((today.getTime() - paramDate.getTime()) > (day - 1) * 86400000
		&& (today.getTime() - paramDate.getTime()) < day * 86400000) {
	    return true;
	}
	return false;
    }

    /**
     * 判断日期是否今天.....
     * 
     * @param paramDate
     *            要判断的时间
     * @return
     * @throws ParseException
     */
    public static boolean judgeToday(Date paramDate) throws ParseException {
	Date date = new Date();
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	String todayStr = format.format(date);
	// 得到今天零时零分零秒这一时刻
	Date today = format.parse(todayStr);
	// 与今日零时零分零秒比较
	if ((paramDate.getTime() - today.getTime()) > 0
		&& (paramDate.getTime() - today.getTime()) < 86400000) {
	    return true;
	}
	return false;
    }

    public static Date addMinute(Date date, int minutes) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.MINUTE, cal.get(Calendar.MINUTE) + minutes);
	return cal.getTime();
    }

    public static Date addHour(Date date, int hours) {
	Calendar cal = Calendar.getInstance();
	cal.setTime(date);
	cal.set(Calendar.HOUR, cal.get(Calendar.HOUR) + hours);
	return cal.getTime();
    }

    /**
     * 开始时间和结束时间间的间隔.
     * @param start 开始时间
     * @param end 结束时间
     * @return 时间间隔 毫秒粒度
     */
    public static long timeIntervalInDay(Date start, Date end) {
	Date now = beginTimeOfDay(end);
	return Math.abs( now.getTime() - start.getTime() );
    }
}
