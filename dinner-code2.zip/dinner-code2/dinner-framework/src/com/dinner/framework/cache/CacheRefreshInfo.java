package com.dinner.framework.cache;

public class CacheRefreshInfo {
    public CacheRefreshInfo(Integer refresherId, String cacheName, String key) {
	this.refresherID = refresherId;
	this.cacheName = cacheName;
	this.key = key;
    }

    private Integer refresherID;
    private String cacheName;
    private String key;

    public String getCacheName() {
	return cacheName;
    }

    public String getKey() {
	return key;
    }

    public Integer getRefresherID() {
	return refresherID;
    }
}
