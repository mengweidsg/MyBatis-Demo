package com.dinner.framework.cache;

/**
 * 缓存刷新器
 * 
 * @author admin 2013-7-18
 * 
 */
public interface CacheRefresher {
    /**
     * 刷新缓存
     * 
     * @param cacheName
     *            要刷新的缓存名称
     * @param key
     *            要刷新的键
     */
    void refresh(String cacheName, String key);
}
