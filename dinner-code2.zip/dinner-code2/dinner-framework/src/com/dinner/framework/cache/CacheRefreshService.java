package com.dinner.framework.cache;

/**
 * 刷新缓存的服务接口,用于分布式缓存架构下的缓存刷新
 * 
 * @author admin 2013-7-18
 * 
 */
public interface CacheRefreshService {
    /**
     * 注册缓存刷新器
     * 
     * @param refresherID
     *            刷新器ID
     * @param refresher
     *            刷新器
     * @throws IllegalArgumentException
     *             若refresherID已存在
     */
    void registerRefresher(Integer refresherID, CacheRefresher refresher);

    /**
     * 触发刷新动作
     * 
     * @param refresherID
     *            刷新器ID
     * @param cacheName
     *            缓存名
     * @param key
     *            要刷新的键
     */
    void fireRefresh(Integer refresherID, String cacheName, String key);
}
