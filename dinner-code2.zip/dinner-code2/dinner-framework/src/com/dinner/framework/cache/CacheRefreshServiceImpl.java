package com.dinner.framework.cache;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.log4j.Logger;

import redis.clients.jedis.JedisPubSub;

import com.dinner.framework.redis.RedisService;
import com.dinner.framework.threadfactory.NamedThreadFactory;

public class CacheRefreshServiceImpl implements CacheRefreshService {
    private static final Logger logger = Logger.getLogger(CacheRefreshServiceImpl.class);
    private static final String CHANNEL = "CacheRefresh";
    private static final ExecutorService EXECUTOR = Executors.newFixedThreadPool(2,
	    new NamedThreadFactory("CacheRefresher"));
    private static final String SEPERATE_STRING = ";->";
    private final Map<Integer, CacheRefresher> refreshers = new ConcurrentHashMap<Integer, CacheRefresher>();
    private RedisService redisService;
    private volatile boolean subscribed;

    public void setRedisService(RedisService redisService) {
	this.redisService = redisService;
    }

    @Override
    public synchronized void registerRefresher(Integer refresherId, CacheRefresher refresher) {
	if (!subscribed) {
	    subscribed = true;
	    redisService.subscribe(new CacheRefreshListener(), CHANNEL);
	}
	if (refreshers.containsKey(refresherId)) {
	    logger.warn("refresherID " + refresherId + " is already exists");
	}
	refreshers.put(refresherId, refresher);
    }

    @Override
    public void fireRefresh(Integer refresherId, String cacheName, String key) {
	String message = refresherId + SEPERATE_STRING + cacheName + SEPERATE_STRING + key;
	redisService.publish(CHANNEL, message);
    }

    public void init() {

    }

    /**
     * 基于reids pub/sub实现的刷新监听器
     * 
     * @author admin 2013-7-18
     * 
     */
    private class CacheRefreshListener extends JedisPubSub {

	private String cacheName;
	private String key;

	@Override
	public void onMessage(String channel, String message) {
	    // format className:args
	    if (logger.isDebugEnabled()) {
		logger.debug("receive message:" + message + " from " + channel);
	    }
	    if (!CHANNEL.equals(channel)) {
		return;
	    }
	    try {
		String[] info = message.split(SEPERATE_STRING);
		String refresherIdStr = info[0];

		if (info != null && info.length > 1) {
		    cacheName = info[1];
		    key = info.length > 2 ? info[2] : "";
		} else {
		    cacheName = null;
		    key = null;
		}

		final CacheRefresher refresher = refreshers.get(Integer.valueOf(refresherIdStr));
		if (refresher != null) {
		    EXECUTOR.execute(new Runnable() {
			@Override
			public void run() {
			    refresher.refresh(cacheName, key);
			    if (logger.isDebugEnabled()) {
				logger.debug(key + "@" + cacheName + " has been refreshed");
			    }
			}
		    });
		}
	    } catch (Exception e) {
		logger.error("error process cache refresh message " + message, e);
	    }
	}

	@Override
	public void onPMessage(String pattern, String channel, String message) {

	}

	@Override
	public void onSubscribe(String channel, int subscribedChannels) {

	}

	@Override
	public void onUnsubscribe(String channel, int subscribedChannels) {

	}

	@Override
	public void onPUnsubscribe(String pattern, int subscribedChannels) {

	}

	@Override
	public void onPSubscribe(String pattern, int subscribedChannels) {

	}

    }

}
