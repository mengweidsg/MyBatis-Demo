package com.dinner.framework.memcache.copy;

import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.XMemcachedClientBuilder;
import net.rubyeye.xmemcached.impl.KetamaMemcachedSessionLocator;
import net.rubyeye.xmemcached.transcoders.Transcoder;

import org.apache.log4j.Logger;

public class MemcacheServiceImpl implements MemcacheService {
    private static final Logger logger = Logger.getLogger(MemcacheServiceImpl.class);
    // 默认12小时过期
    private static final int default_expire_seconds = 12 * 3600;
    private String memcacheAddrs;
    private MemcachedClient client;
    private String version = "20130609";
    @SuppressWarnings("rawtypes")
    private Transcoder transcoder;

    public void setMemcacheAddrs(String memcacheAddrs) {
	this.memcacheAddrs = memcacheAddrs;
    }

    public void setVersion(String version) {
	this.version = version;
    }

    @SuppressWarnings("rawtypes")
    public void setTranscoder(Transcoder transcoder) {
	this.transcoder = transcoder;
    }

    @Override
    public void set(String key, Object value) {
	set(key, value, default_expire_seconds);
    }

    @Override
    public void set(String key, Object value, int expireSeconds) {
	try {
	    client.set(getCacheKey(key), expireSeconds, value);
	} catch (Exception e) {
	    logger.error("error set key " + getCacheKey(key) + " with val " + value, e);
	}
    }

    @Override
    public <T> T get(String key) {
	try {
	    return client.get(getCacheKey(key));
	} catch (Exception e) {
	    logger.error("error get key:" + getCacheKey(key), e);
	    return null;
	}
    }

    @Override
    public void delete(String key) {
	try {
	    client.delete(getCacheKey(key));
	} catch (Exception e) {
	    logger.error("error delete key " + getCacheKey(key), e);
	}
    }

    private String getCacheKey(String key) {
	return key + version;
    }

    public void init() throws Exception {
	if (memcacheAddrs == null || memcacheAddrs.trim().equals("")
		|| memcacheAddrs.trim().endsWith("NULL")) {
	    logger.warn("no memcache addr was configured,this memcache servcie will be unavaliable");
	    return;
	}
	XMemcachedClientBuilder builder = new XMemcachedClientBuilder(memcacheAddrs);
	builder.setSessionLocator(new KetamaMemcachedSessionLocator());
	if (transcoder != null) {
	    builder.setTranscoder(transcoder);
	}
	client = builder.build();
    }

}
