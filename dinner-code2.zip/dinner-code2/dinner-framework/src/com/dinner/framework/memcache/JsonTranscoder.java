package com.dinner.framework.memcache;

import java.io.UnsupportedEncodingException;

import net.rubyeye.xmemcached.transcoders.BaseSerializingTranscoder;
import net.rubyeye.xmemcached.transcoders.CachedData;
import net.rubyeye.xmemcached.transcoders.SerializingTranscoder;
import net.rubyeye.xmemcached.transcoders.Transcoder;

import org.apache.log4j.Logger;

import com.dinner.framework.util.JsonUtil;

/**
 * xmemcahced的 json序列化器
 * 
 * @author admin
 * 
 *         2013-9-25
 */
public class JsonTranscoder extends BaseSerializingTranscoder implements Transcoder<Object> {
    private static final Logger logger = Logger.getLogger(JsonTranscoder.class);

    /**
     * 将一个short类型编码为2个字节(大端法)
     * 
     * @param s
     * @return
     */
    private byte[] s2b(short s) {
	byte[] bytes = new byte[2];
	bytes[1] = (byte) s;
	bytes[0] = (byte) (s >>> 8);
	return bytes;
    }

    /**
     * 将2个字节(大端法)转化成short
     * 
     * @param bytes
     * @return
     */
    private short b2s(byte[] bytes) {
	short val = 0;
	val = (short) (val + ((bytes[0] & 0xFF) << 8));
	val = (short) (val + (bytes[1] & 0xFF));
	return val;
    }

    @Override
    public CachedData encode(Object o) {
	if (o == null) {
	    return null;
	}
	String clsName = o.getClass().getName();
	byte[] clsBytes = null;
	try {
	    clsBytes = clsName.getBytes("UTF-8");
	} catch (UnsupportedEncodingException impossiable) {
	    throw new RuntimeException("error encode class " + clsName + ",utf-8 is unsupported");
	}
	byte[] jsonBytes = JsonUtil.toBytes(o);
	byte[] lenBytes = s2b((short) clsBytes.length);
	byte[] totalBytes = new byte[lenBytes.length + clsBytes.length + jsonBytes.length];
	System.arraycopy(lenBytes, 0, totalBytes, 0, lenBytes.length);
	System.arraycopy(clsBytes, 0, totalBytes, lenBytes.length, clsBytes.length);
	System.arraycopy(jsonBytes, 0, totalBytes, lenBytes.length + clsBytes.length,
		jsonBytes.length);
	int flags = 0;
	if (totalBytes.length > compressionThreshold) {
	    byte[] compressed = compress(totalBytes);
	    if (compressed.length < totalBytes.length) {
		totalBytes = compressed;
		flags |= SerializingTranscoder.COMPRESSED;
	    } else {
		logger.warn("compress increase bytes of " + clsName + ",from " + totalBytes.length
			+ " to " + compressed.length);
	    }
	}
	return new CachedData(flags, totalBytes);
    }

    @Override
    public Object decode(CachedData d) {
	byte[] data = d.getData();
	int flags = d.getFlag();
	if ((flags & SerializingTranscoder.COMPRESSED) != 0) {
	    data = decompress(data);
	}
	byte[] lenBytes = new byte[2];
	System.arraycopy(data, 0, lenBytes, 0, 2);
	short clsByteslen = b2s(lenBytes);
	byte[] clsBytes = new byte[clsByteslen];
	System.arraycopy(data, 2, clsBytes, 0, clsByteslen);
	byte[] jsonBytes = new byte[data.length - clsByteslen - 2];
	System.arraycopy(data, 2 + clsByteslen, jsonBytes, 0, jsonBytes.length);
	String clsName = null;
	try {
	    clsName = new String(clsBytes, "UTF-8");
	} catch (UnsupportedEncodingException impossiable) {
	    // shoudn't happen
	    throw new RuntimeException("error decode class name,utf-8 is unsupported");
	}
	try {
	    Object obj = JsonUtil.toObject(jsonBytes, Class.forName(clsName));
	    return obj;
	} catch (ClassNotFoundException e) {
	    throw new RuntimeException(clsName + " is not found", e);
	}
    }

    @Override
    public void setPrimitiveAsString(boolean primitiveAsString) {

    }

    @Override
    public void setPackZeros(boolean packZeros) {

    }

    @Override
    public boolean isPrimitiveAsString() {
	return false;
    }

    @Override
    public boolean isPackZeros() {
	return false;
    }
}
