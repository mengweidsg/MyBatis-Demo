package com.dinner.framework.memcache.copy;

public interface MemcacheService {
    /**
     * 设置一个值
     * 
     * @param key
     *            键
     * @param value
     *            值
     */
    void set(String key, Object value);

    /**
     * 设置一个值,并指定超时时间
     * 
     * @param key
     * @param value
     * @param expireSeconds
     *            过期时间(秒),若小于30天,则认为是从当前时间的相对时间,若大于30天,则认为是一个自unix epoch的绝对时间
     */
    void set(String key, Object value, int expireSeconds);

    /**
     * 获取一个值
     * 
     * @param key
     *            键
     * @return 值
     */
    <T> T get(String key);

    /**
     * 删除一个键
     * 
     * @param key
     */
    void delete(String key);
}
