package com.dinner.framework.mongo;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;

import com.mongodb.CommandResult;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.Mongo;
import com.mongodb.MongoOptions;
import com.mongodb.ReadPreference;
import com.mongodb.ServerAddress;

public class MongoServiceImpl implements MongoService {
    private static final Logger LOGGER = Logger.getLogger(MongoServiceImpl.class);
    // comma seperated host:port
    private Mongo mongo;
    private String mongoHosts;
    private int connectionPerHost = 30;
    private int connectionTimeout = 6000;
    private int maxWaitTime = 6000;
    private String masterCollectionsStr;
    private final Set<String> operateOnMasterCollectinos = new HashSet<String>();

    public MongoServiceImpl() {

    }

    public MongoServiceImpl(String mongoHosts) {
	setMongoHosts(mongoHosts);
    }

    public void setMongoHosts(String mongoHosts) {
	this.mongoHosts = mongoHosts;
    }

    public void setMasterCollectionsStr(String masterCollectionsStr) {
	this.masterCollectionsStr = masterCollectionsStr;
    }

    public void setConnectionPerHost(int connectionPerHost) {
	this.connectionPerHost = connectionPerHost;
    }

    public void setConnectionTimeout(int connectionTimeout) {
	this.connectionTimeout = connectionTimeout;
    }

    public void setMaxWaitTime(int maxWaitTime) {
	this.maxWaitTime = maxWaitTime;
    }

    public void init() throws Exception {
	mongo = initMongo(mongoHosts);
    }

    private Mongo initMongo(String hosts) throws Exception {
	if (hosts == null || "".equals(hosts.trim()) || "NULL".equals(hosts.trim())) {
	    LOGGER.warn("no mongo hosts was configed,this mongo service will be unavaliable");
	    return null;
	}
	String[] hostInfos = hosts.split("\\s*,\\s*");
	List<ServerAddress> addrs = new ArrayList<ServerAddress>(hostInfos.length);
	for (String hostInfo : hostInfos) {
	    try {
		String[] hp = hostInfo.split(":");
		ServerAddress addr = new ServerAddress(hp[0], Integer.valueOf(hp[1]));
		addrs.add(addr);
	    } catch (Exception e) {
		LOGGER.error("init-mongo-error,hosts=" + hosts + ",target host is " + hostInfo);
		throw e;
	    }
	}
	MongoOptions opt = new MongoOptions();
	opt.autoConnectRetry = true;
	opt.socketKeepAlive = true;
	if (hostInfos.length == 1) {
	    opt.readPreference = ReadPreference.primaryPreferred();
	} else {
	    opt.readPreference = ReadPreference.secondaryPreferred();
	}
	opt.connectionsPerHost = connectionPerHost;
	opt.connectTimeout = connectionTimeout;
	opt.maxWaitTime = maxWaitTime;
	if (masterCollectionsStr != null) {
	    String[] colls = masterCollectionsStr.split("\\s*,\\s*");
	    for (String coll : colls) {
		operateOnMasterCollectinos.add(coll);
	    }
	}
	Mongo mongo = new Mongo(addrs, opt);
	return mongo;
    }

    @Override
    public DBCollection getCollection(String dbName, String collectionName) {
	DB db = mongo.getDB(dbName);
	DBCollection collection = db.getCollection(collectionName);
	if (operateOnMasterCollectinos.contains(collectionName)) {
	    collection.setReadPreference(ReadPreference.primary());
	}
	return collection;
    }

    @Override
    public CommandResult command(String dbName, DBObject command) {
	return command(dbName, command, false);
    }

    @Override
    public CommandResult command(String dbName, DBObject command, boolean runOnMaster) {
	DB db = mongo.getDB(dbName);
	CommandResult result = null;
	if (runOnMaster) {
	    result = db.command(command, 0, ReadPreference.primary());
	} else {
	    result = db.command(command);
	}
	return result;
    }

    @Override
    public DBObject remove(String dbName, String collectionName) {
	return remove(dbName, collectionName, null, null);
    }

    @Override
    public DBObject remove(String dbName, String collectionName, DBObject query) {
	return remove(dbName, collectionName, query, null);
    }

    @Override
    public DBObject remove(String dbName, String collectionName, DBObject query, DBObject fields) {
	DBCollection dbc = getCollection(dbName, collectionName);
	DBObject dbObj = dbc.findAndModify(query, fields, null, true, null, true, false);
	return dbObj;
    }

}
