package com.dinner.common.contants;

/**
 * localsetting 配置文件key
 * 
 * @author admin
 * @create 2014年5月6日 上午11:18:19
 */
public class LocalSettingKeys {

    /**
     * <pre>
     * 登陆获取验证码时是否把验证码返回给登陆页面, 该开关主要用在测试环境下方便登陆
     * 注意: 线上环境需要关闭
     * </pre>
     */
    public static String SHOW_VERIFY_CODE_FOR_LOGIN = "show_verify_code_for_login";

    public static String REQUEST_IP_INTERCEPTOR_SWITCH = "request.ip.interceptor.switch";

    public static String REQUEST_IP_NOT_INTERCEPT_AREA = "request.ip.not.intercept.area";
}
