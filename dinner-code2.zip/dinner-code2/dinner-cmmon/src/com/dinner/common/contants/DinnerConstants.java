/**
 * 
 */
package com.dinner.common.contants;

/**
 * @author jianting.xu
 * 
 */
public interface DinnerConstants {

    /** 统一收款帐号 */
    int DEFAULT_PAY_REST_ID = 1;

    /**
     * 是否
     * 
     * @author jianting.xu
     * 
     */
    public static interface YesNo {

	/** 0:否 */
	int NO = 0;

	/** 1:是 */
	int YES = 1;

    }

    /**
     * 性别
     * 
     * @author jianting.xu
     * 
     */
    public static interface Sex {

	/** 1:男 */
	int MALE = 0;

	/** 2:女 */
	int FEMALE = 0;

    }

    /**
     * 订单状态
     * 
     * @author jianting.xu
     * 
     */
    public static interface OrderState {

	/** 0:待支付 */
	int TO_PAY = 0;

	/** 1:待审核 */
	int TO_AUDIT = 1;
    }

    /**
     * 订单类型:1.网上下单 2.电话下单 3.大堂下单
     * 
     * @author jianting.xu
     * 
     */
    public static interface OrderType {

	/** 1.网上下单 */
	int WEB = 1;

	/** 2.电话下单 */
	int PHONE = 2;

	/** 3.大堂下单 */
	int REST = 3;
    }

    /**
     * 支付方式
     * 
     * @author jianting.xu
     * 
     */
    public static interface PayType {

	/** 1.在线支付 */
	int ONLINE = 1;

	/** 2.现金 */
	int CASH = 2;

	/** 3.点餐币 */
	int DIANCAN_COIN = 3;
    }

    /**
     * 配送方式:1.统一配送 2.独立配送
     * 
     * @author jianting.xu
     * 
     */
    public static interface DeliveryType {

	/** 1.统一配送 */
	int UNIFY = 1;

	/** 2.独立配送 */
	int SELF = 2;

    }

    /**
     * 经营模式：1.统一经营 2.独立经营
     * 
     * @author jianting.xu
     * 
     */
    public static interface ManageType {

	/** 1.统一经营 */
	int UNIFY = 1;

	/** 2.独立经营 */
	int SELF = 2;
    }

    /**
     * dc_order_detail 状态:1.待处理 2.处理中 3.已完成典类型
     * 
     * @author yeyj
     * 
     */
    public static interface OrderDetailState {

	/** 1.在线支付 */
	int WAITING = 1;

	/** 2.现金 */
	int DOING = 2;

	/** 3.点餐币 */
	int FINISH = 3;

    }

    /**
     * 字典类型
     * 
     * @author jianting.xu
     * 
     */
    public static interface DictType {

	/** 菜馆类型 */
	String REST_TYPE = "rest_type";

	/** 商圈 */
	String BUSINESS_ZONE = "business_zone";

    }
}
