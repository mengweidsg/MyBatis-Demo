package com.dinner.common.entity;


public class DcEmployee {

	private Integer id;
	private Integer restId;
	private String name;
	private String employeeType;
	private int age;
	private String link;
	private String sex;
	private String cardNum;
	private String address;
	private String tel;
	private int workAge;
	private String manager_zone;
	private String x_coordinate;
	private String y_coordinate;
	

	public Integer getRestId() {
		return restId;
	}

	public void setRestId(Integer restId) {
		this.restId = restId;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmployeeType() {
		return employeeType;
	}

	public void setEmployeeType(String employeeType) {
		this.employeeType = employeeType;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getSex() {
		return sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getCardNum() {
		return cardNum;
	}

	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public int getWorkAge() {
		return workAge;
	}

	public void setWorkAge(int workAge) {
		this.workAge = workAge;
	}

	public String getManager_zone() {
		return manager_zone;
	}

	public void setManager_zone(String manager_zone) {
		this.manager_zone = manager_zone;
	}

	public String getX_coordinate() {
		return x_coordinate;
	}

	public void setX_coordinate(String x_coordinate) {
		this.x_coordinate = x_coordinate;
	}

	public String getY_coordinate() {
		return y_coordinate;
	}

	public void setY_coordinate(String y_coordinate) {
		this.y_coordinate = y_coordinate;
	}

}