package com.dinner.common.entity;

public class DcMenuExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}


		public Criteria andNameLike(String value) {
			addCriterion("menu.name like", value, "name");
			return (Criteria) this;
		}

		public Criteria andTypeEqualTo(String value) {
			addCriterion("menu.type = ", value, "type");
			return (Criteria) this;
		}

		public Criteria andRestNameLike(String restName) {
			addCriterion("rest.name like ", restName, "restName");
			return (Criteria) this;
		}
		
		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion("menu.restId = ", restId, "restName");
			return (Criteria) this;
		}


		public Criteria andCodeEqualTo(String code) {
			addCriterion("menu.code = ", code, "code");
			return (Criteria) this;
		}

		public Criteria andIdEqualTo(int id) {
			addCriterion("menu.id = ", id, "id");
			return (Criteria) this;
		}

	}

}