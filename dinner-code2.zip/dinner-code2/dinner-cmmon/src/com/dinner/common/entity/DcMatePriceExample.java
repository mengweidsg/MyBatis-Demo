package com.dinner.common.entity;



public class DcMatePriceExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andMateIdEqualTo(String mateId) {
			addCriterion("dmp.mateId = ", mateId, "mateId");
			return (Criteria) this;
		}

		public Criteria andIdEqualTo(Integer id) {
			addCriterion("dmp.id = ", id, "id");
			return (Criteria) this;
		}

		public Criteria andMateLike(String mateName) {
			addCriterion("sp.codeValue like", mateName, "codeValue");
			return  this;
		}

	}

}