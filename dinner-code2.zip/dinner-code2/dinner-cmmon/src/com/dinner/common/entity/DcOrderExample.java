package com.dinner.common.entity;

public class DcOrderExample extends DcExample {
	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion("rest_id = ", restId, "rest_id");
			return (Criteria) this;
			
		}

		public Criteria andIspayEqualTo(String ispay) {
			addCriterion("ispay = ", ispay, "ispay");
			return (Criteria) this;
		}
		public Criteria andTypeNotEqualTo(int type) {
			addCriterion("type != ", type, "type");
			return (Criteria) this;
		}

		public Criteria andTypeEqualTo(String type) {
			addCriterion("type = ", type, "type");
			return (Criteria) this;
		}

		public Criteria andSubmitEqualTo(Integer submit) {
			addCriterion("submit = ", submit, "submit");
			return (Criteria) this;
			
		}

		public Criteria andAcceptEqualTo(Integer accept) {
			addCriterion("accept = ", accept, "accept");
			return (Criteria) this;
			
		}
		
		public Criteria andSendStatusEqualTo(String status) {
			addCriterion("sendStatus = ", status, "sendStatus");
			return (Criteria) this;
		}

		public Criteria andSourceTypeEqualTo(int sourceType) {
			addCriterion("sourceType = ", sourceType, "sourceType");
			return (Criteria) this;
			
		}

		public Criteria andSendRestStatusEqualTo(int sendRestStatus) {
			addCriterion("sendRestStatus = ", sendRestStatus, "sendRestStatus");
			return (Criteria) this;
		}

		public Criteria andSendStatusEqualTo(int sendStatus) {
			addCriterion("sendStatus = ", sendStatus, "sendStatus");
			return (Criteria) this;
		}

		public Criteria andNameLike(String name) {
			addCriterion("a.loginName like ", name, "type");
			return (Criteria) this;
		}

		public Criteria andZoneLike(String zone) {
			addCriterion(" c.manager_zone like ", zone, " type");
			return (Criteria) this;
		}

		public Criteria andUserIdEqualTo(Integer userId) {
			addCriterion(" a.userTop = ", userId, "sendRestStatus");
			return (Criteria) this;
		}

		public Criteria andEmployeeTypeEqualTo(Integer employeeType) {
			addCriterion(" c.employeeType = ", employeeType, "sendRestStatus");
			return (Criteria) this;
		}

		public Criteria andSendMeEqualTo(Integer restId) {
			addCriterion(" (sendRestStatus=1 and sendRestId="+restId+")");
			return (Criteria) this;
			
		}

		public Criteria andSendManId(Integer userId) {
			addCriterion(" sendManId = "+userId);
			return (Criteria) this;
		}

		public Criteria andCashorEqualTo(String cashor) {
			addCriterion(" cashor = '"+cashor+"'");
			return (Criteria) this;
		}

		public Criteria andStartGtTo(String start) {
			addCriterion(" do.create_time >= '"+(start+" 00:00:00")+"'");
			return (Criteria) this;
		}

		public Criteria andEndLtTo(String end) {
			addCriterion("  do.create_time <= '"+(end+" 23:59:59")+"'");
			return (Criteria) this;
		}

		
	}

}