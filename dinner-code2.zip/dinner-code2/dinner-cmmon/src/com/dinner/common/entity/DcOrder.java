package com.dinner.common.entity;

import java.math.BigDecimal;
import java.util.Date;

public class DcOrder {

	private Integer id;
	private Integer rest_id;
	private String order_no;
	private Integer type;
	private Date create_time;
	private String operate_id;
	private Integer ispay =0;
	private Date pay_time = null;
	private String cashor;
	private Integer privilege;
	private BigDecimal money;
	private Integer state=1;
	private Date update_time;
	private Integer submit;
	private Integer accept;
	private Date submitTime;
	private Date acceptTime;
	private Integer sendStatus;
	private String sendMan;
	private Integer sendManId;
	private String table_no;
	private Integer pensonNum;
	private String sendName;
	private String sendLink;
	private String sendAddress;
	private Integer sendRestId;
	private Integer viewUser;
	private Integer sourceType;
	private Integer sendRestStatus;
	
	private Date sendTime;
	private Date sendGetTime;
	private Date sendSureTime;
	private Date sendFinishTime;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRest_id() {
		return rest_id;
	}

	public void setRest_id(Integer rest_id) {
		this.rest_id = rest_id;
	}

	public String getOrder_no() {
		return order_no;
	}

	public void setOrder_no(String order_no) {
		this.order_no = order_no;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Date getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Date create_time) {
		this.create_time = create_time;
	}

	public String getOperate_id() {
		return operate_id;
	}

	public void setOperate_id(String operate_id) {
		this.operate_id = operate_id;
	}

	public Integer getIspay() {
		return ispay;
	}

	public void setIspay(Integer ispay) {
		this.ispay = ispay;
	}

	public Date getPay_time() {
		return pay_time;
	}

	public void setPay_time(Date pay_time) {
		this.pay_time = pay_time;
	}

	public String getCashor() {
		return cashor;
	}

	public void setCashor(String cashor) {
		this.cashor = cashor;
	}

	public Integer getPrivilege() {
		return privilege;
	}

	public void setPrivilege(Integer privilege) {
		this.privilege = privilege;
	}

	public BigDecimal getMoney() {
		return money;
	}

	public void setMoney(BigDecimal money) {
		this.money = money;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public Date getUpdate_time() {
		return update_time;
	}

	public void setUpdate_time(Date update_time) {
		this.update_time = update_time;
	}

	public Integer getSubmit() {
		return submit;
	}

	public void setSubmit(Integer submit) {
		this.submit = submit;
	}

	public Integer getAccept() {
		return accept;
	}

	public void setAccept(Integer accept) {
		this.accept = accept;
	}

	public Date getSubmitTime() {
		return submitTime;
	}

	public void setSubmitTime(Date submitTime) {
		this.submitTime = submitTime;
	}

	public Date getAcceptTime() {
		return acceptTime;
	}

	public void setAcceptTime(Date acceptTime) {
		this.acceptTime = acceptTime;
	}

	public Integer getSendStatus() {
		return sendStatus;
	}

	public void setSendStatus(Integer sendStatus) {
		this.sendStatus = sendStatus;
	}

	public String getSendMan() {
		return sendMan;
	}

	public void setSendMan(String sendMan) {
		this.sendMan = sendMan;
	}

	public Integer getSendManId() {
		return sendManId;
	}

	public void setSendManId(Integer sendManId) {
		this.sendManId = sendManId;
	}

	public String getTable_no() {
		return table_no;
	}

	public void setTable_no(String table_no) {
		this.table_no = table_no;
	}

	public Integer getPensonNum() {
		return pensonNum;
	}

	public void setPensonNum(Integer pensonNum) {
		this.pensonNum = pensonNum;
	}

	public String getSendName() {
		return sendName;
	}

	public void setSendName(String sendName) {
		this.sendName = sendName;
	}

	public String getSendLink() {
		return sendLink;
	}

	public void setSendLink(String sendLink) {
		this.sendLink = sendLink;
	}

	public String getSendAddress() {
		return sendAddress;
	}

	public void setSendAddress(String sendAddress) {
		this.sendAddress = sendAddress;
	}

	public Integer getSendRestId() {
		return sendRestId;
	}

	public void setSendRestId(Integer sendRestId) {
		this.sendRestId = sendRestId;
	}

	public Integer getViewUser() {
		return viewUser;
	}

	public void setViewUser(Integer viewUser) {
		this.viewUser = viewUser;
	}

	public Integer getSourceType() {
		return sourceType;
	}

	public void setSourceType(Integer sourceType) {
		this.sourceType = sourceType;
	}

	public Integer getSendRestStatus() {
		return sendRestStatus;
	}

	public void setSendRestStatus(Integer sendRestStatus) {
		this.sendRestStatus = sendRestStatus;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public Date getSendGetTime() {
		return sendGetTime;
	}

	public void setSendGetTime(Date sendGetTime) {
		this.sendGetTime = sendGetTime;
	}

	public Date getSendSureTime() {
		return sendSureTime;
	}

	public void setSendSureTime(Date sendSureTime) {
		this.sendSureTime = sendSureTime;
	}

	public Date getSendFinishTime() {
		return sendFinishTime;
	}

	public void setSendFinishTime(Date sendFinishTime) {
		this.sendFinishTime = sendFinishTime;
	}
	
	
	
}
