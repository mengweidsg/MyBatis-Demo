package com.dinner.common.entity;

import java.math.BigDecimal;
import java.util.List;


/**
 * 菜单管理
 * @author 攻心小虫
 *
 */
public class DcMenu {

	private Integer id;
	private Integer restId;
	private String name;
	private String pic;
	private String info;
	private BigDecimal price;
	private BigDecimal mebPrice;
	private Integer sale;
	private String menuType;
	private String hot;
	private String type;
	private String commend;
	private String code;
	
	private Integer status;
	
	
	private List<DcMateMenu> dcMateMenus;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getRestId() {
		return restId;
	}

	public void setRestId(Integer restId) {
		this.restId = restId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getMebPrice() {
		return mebPrice;
	}

	public void setMebPrice(BigDecimal mebPrice) {
		this.mebPrice = mebPrice;
	}

	public Integer getSale() {
		return sale;
	}

	public void setSale(Integer sale) {
		this.sale = sale;
	}

	public String getMenuType() {
		return menuType;
	}

	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}

	public String getHot() {
		return hot;
	}

	public void setHot(String hot) {
		this.hot = hot;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getCommend() {
		return commend;
	}

	public void setCommend(String commend) {
		this.commend = commend;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public List<DcMateMenu> getDcMateMenus() {
		return dcMateMenus;
	}

	public void setDcMateMenus(List<DcMateMenu> dcMateMenus) {
		this.dcMateMenus = dcMateMenus;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}
	

}