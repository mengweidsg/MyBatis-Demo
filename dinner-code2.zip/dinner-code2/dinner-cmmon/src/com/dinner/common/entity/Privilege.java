package com.dinner.common.entity;

import com.dinner.framework.util.ObjectUtil;

/**
 * 权限
 * <p>
 * 对应这系统中的每一个页面按钮以及菜单链接
 * </p>
 * 
 * @author admin
 * @create 2014年3月3日 下午1:59:10
 */
public class Privilege {

	public static final int ONE_LEVEL_MENU = 0; // 一级菜单权限
	public static final int TWO_LEVEL_MENU = 1; // 二级菜单权限
	public static final int THREE_LEVEL_BUTTON = 2; // 三级按钮权限

	private Integer privId; // 主键
	private String module; // 权限所属模块
	private String privilege; // 权限
	private String name; // 权限显示名称
	private Integer level; // 权限等级
	private String url; // 针对二级菜单的访问url
	private Integer sort; // 排序

	public Privilege() {
	}

	public Privilege(String module, String privilege) {
		this.module = module;
		this.privilege = privilege;
	}

	public Integer getPrivId() {
		return privId;
	}

	public void setPrivId(Integer privId) {
		this.privId = privId;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getPrivilege() {
		return privilege;
	}

	public void setPrivilege(String privilege) {
		this.privilege = privilege;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getSort() {
		return sort;
	}

	public void setSort(Integer sort) {
		this.sort = sort;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getNodeName() {
		return name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((module == null) ? 0 : module.hashCode());
		result = prime * result
				+ ((privilege == null) ? 0 : privilege.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Privilege other = (Privilege) obj;
		if (module == null) {
			if (other.module != null)
				return false;
		} else if (!module.equals(other.module))
			return false;
		if (privilege == null) {
			if (other.privilege != null)
				return false;
		} else if (!privilege.equals(other.privilege))
			return false;
		return true;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return ObjectUtil.deepCopy(this);
	}

	@Override
	public String toString() {
		return "Privilege [privId=" + privId + ", name=" + name + ", module="
				+ module + ", privilege=" + privilege + ", level=" + level
				+ "]";
	}

}
