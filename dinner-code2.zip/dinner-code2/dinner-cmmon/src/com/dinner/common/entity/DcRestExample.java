package com.dinner.common.entity;


public class DcRestExample extends DcExample {
	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andNameLike(String value) {
			addCriterion("name like ", value, "name");
			return (Criteria) this;
		}

	}

}