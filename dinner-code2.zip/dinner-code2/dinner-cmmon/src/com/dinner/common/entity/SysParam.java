package com.dinner.common.entity;

public class SysParam {

	private Integer id;

	private String name;

	private String codeKey;

	private String codeValue;

	private Integer status;
	
	private Integer defend;
	
	private String 	topValue;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCodeKey() {
		return codeKey;
	}

	public void setCodeKey(String codeKey) {
		this.codeKey = codeKey;
	}

	public String getCodeValue() {
		return codeValue;
	}

	public void setCodeValue(String codeValue) {
		this.codeValue = codeValue;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getDefend() {
		return defend;
	}

	public void setDefend(Integer defend) {
		this.defend = defend;
	}

	public String getTopValue() {
		return topValue;
	}

	public void setTopValue(String topValue) {
		this.topValue = topValue;
	}
	
}
