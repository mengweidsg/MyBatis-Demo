package com.dinner.common.entity;

public class UserExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andNameLike(String name) {
			addCriterion(" a.name  like ", name, "a.name");
			return this;
		}

		public Criteria andUserTopEqualTo(Integer userTop) {
			addCriterion(" userTop  = ", userTop, "userTop");
			return this;
		}
		
		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion(" a.restId  = ", restId, "restId");
			return this;
		}
		
		public Criteria andUserTypeEqualTo(String userType) {
			addCriterion(" c.employeeType  = ", userType, "userType");
			return this;
		}
	}

}