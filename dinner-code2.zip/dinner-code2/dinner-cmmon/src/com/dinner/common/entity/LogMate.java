package com.dinner.common.entity;

import java.math.BigDecimal;
import java.util.Date;


public class LogMate {

	private Integer id;
	private Integer restId;
	private String mateId;
	private Integer addNum;
	private BigDecimal addMoney;
	private Date updateime;
	private String remark;
	
	private Integer addType;
	
	public Integer getAddType() {
		return addType;
	}
	public void setAddType(Integer addType) {
		this.addType = addType;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getRestId() {
		return restId;
	}
	public void setRestId(Integer restId) {
		this.restId = restId;
	}
	public Integer getAddNum() {
		return addNum;
	}
	public void setAddNum(Integer addNum) {
		this.addNum = addNum;
	}
	public BigDecimal getAddMoney() {
		return addMoney;
	}
	public void setAddMoney(BigDecimal addMoney) {
		this.addMoney = addMoney;
	}
	public Date getUpdateime() {
		return updateime;
	}
	public void setUpdateime(Date updateime) {
		this.updateime = updateime;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMateId() {
		return mateId;
	}
	public void setMateId(String mateId) {
		this.mateId = mateId;
	}

}