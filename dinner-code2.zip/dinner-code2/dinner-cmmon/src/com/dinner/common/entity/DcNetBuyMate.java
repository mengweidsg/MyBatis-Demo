package com.dinner.common.entity;

import java.math.BigDecimal;
import java.util.Date;


/**
 * 食材单价
 * @author 攻心小虫
 *
 */
public class DcNetBuyMate {

	private Integer id;
	private Integer restId;
	private String mateId;
	private Integer addNum;
	private BigDecimal addMoney;
	private BigDecimal price;
	private Date addTime;
	private Date dealTime;
	private Date submitTime;
	private Integer status;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getRestId() {
		return restId;
	}
	public void setRestId(Integer restId) {
		this.restId = restId;
	}
	public String getMateId() {
		return mateId;
	}
	public void setMateId(String mateId) {
		this.mateId = mateId;
	}
	public Integer getAddNum() {
		return addNum;
	}
	public void setAddNum(Integer addNum) {
		this.addNum = addNum;
	}
	public BigDecimal getAddMoney() {
		return addMoney;
	}
	public void setAddMoney(BigDecimal addMoney) {
		this.addMoney = addMoney;
	}
	public Date getAddTime() {
		return addTime;
	}
	public void setAddTime(Date addTime) {
		this.addTime = addTime;
	}
	public Date getDealTime() {
		return dealTime;
	}
	public void setDealTime(Date dealTime) {
		this.dealTime = dealTime;
	}
	public Date getSubmitTime() {
		return submitTime;
	}
	public void setSubmitTime(Date submitTime) {
		this.submitTime = submitTime;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
}