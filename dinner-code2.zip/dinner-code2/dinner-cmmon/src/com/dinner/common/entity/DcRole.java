package com.dinner.common.entity;

import java.util.Date;

/**
 * 角色对象
 * 
 * @author yu.han 2014年6月30日 下午4:40:45
 * 
 */
public class DcRole {
	private Integer postId;// 主键ID
	private String name;// 角色名
	private String description;// 描述
	private Date createTime;// 创建时间
	private Date uptime;// 修改时间
	private Integer userTop;
	
	public Integer getPostId() {
		return postId;
	}

	public void setPostId(Integer postId) {
		this.postId = postId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUptime() {
		return uptime;
	}

	public void setUptime(Date uptime) {
		this.uptime = uptime;
	}

	public Integer getUserTop() {
		return userTop;
	}

	public void setUserTop(Integer userTop) {
		this.userTop = userTop;
	}

}
