package com.dinner.common.entity;

import java.util.Date;

/**
 * 用户订餐地址
 * 
 * @author yu.han 2014年7月3日 下午3:51:32
 * 
 */
public class DcUserAddress {
    private Integer id;// 主键ID

    private Integer userid;// 用户ID

    private String address;// 用户地址

    private String mobile;// 用户手机

    private String telephone;// 用户座机

    private Date createTime;// 创建时间

    private Date updateTime;// 修改时间

    private Integer isDefault;// 是否默认地址

    public Integer getId() {
	return id;
    }

    public void setId(Integer id) {
	this.id = id;
    }

    public Integer getUserid() {
	return userid;
    }

    public void setUserid(Integer userid) {
	this.userid = userid;
    }

    public String getAddress() {
	return address;
    }

    public void setAddress(String address) {
	this.address = address;
    }

    public String getMobile() {
	return mobile;
    }

    public void setMobile(String mobile) {
	this.mobile = mobile;
    }

    public String getTelephone() {
	return telephone;
    }

    public void setTelephone(String telephone) {
	this.telephone = telephone;
    }

    public Date getCreateTime() {
	return createTime;
    }

    public void setCreateTime(Date createTime) {
	this.createTime = createTime;
    }

    public Date getUpdateTime() {
	return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
	this.updateTime = updateTime;
    }

    public Integer getIsDefault() {
	return isDefault;
    }

    public void setIsDefault(Integer isDefault) {
	this.isDefault = isDefault;
    }
}