package com.dinner.common.entity;

import java.math.BigDecimal;
import java.util.Date;

public class DcRest {
	
    private Integer id;
    private String name;
    private String telephone;
    private String mobile;
    private String pic;
    private String info;
    private String features;
    private String address;
    private Date createTime;
    private Date updateTime;
    private String businessZone;
    private BigDecimal deliveryReqPrice;
    private String link;
    private String manageTime;
    private String manageArea;
    private String xCoordinate;
    private String yCoordinate;
    private String joinType;
    private Integer groom;
    private BigDecimal avgPrice;
    private String startTime;
    private String endTime;
    private String remark;
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}
	public String getFeatures() {
		return features;
	}
	public void setFeatures(String features) {
		this.features = features;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getBusinessZone() {
		return businessZone;
	}
	public void setBusinessZone(String businessZone) {
		this.businessZone = businessZone;
	}
	public BigDecimal getDeliveryReqPrice() {
		return deliveryReqPrice;
	}
	public void setDeliveryReqPrice(BigDecimal deliveryReqPrice) {
		this.deliveryReqPrice = deliveryReqPrice;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	public String getManageTime() {
		return manageTime;
	}
	public void setManageTime(String manageTime) {
		this.manageTime = manageTime;
	}
	public String getManageArea() {
		return manageArea;
	}
	public void setManageArea(String manageArea) {
		this.manageArea = manageArea;
	}
	public String getxCoordinate() {
		return xCoordinate;
	}
	public void setxCoordinate(String xCoordinate) {
		this.xCoordinate = xCoordinate;
	}
	public String getyCoordinate() {
		return yCoordinate;
	}
	public void setyCoordinate(String yCoordinate) {
		this.yCoordinate = yCoordinate;
	}
	public String getJoinType() {
		return joinType;
	}
	public void setJoinType(String joinType) {
		this.joinType = joinType;
	}
	public Integer getGroom() {
		return groom;
	}
	public void setGroom(Integer groom) {
		this.groom = groom;
	}
	public BigDecimal getAvgPrice() {
		return avgPrice;
	}
	public void setAvgPrice(BigDecimal avgPrice) {
		this.avgPrice = avgPrice;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
}