package com.dinner.common.entity;

public class DcOrderMenu {

	private Integer id;
	private Integer order_id;
	private Integer menuId;
	private Integer num;
	private Integer status;
	private String insert_order_time;
	private String order_time;
	private String back_reason;
	private String backor;
	private String back_men;
	private String cooker;
	private String remark;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Integer getOrder_id() {
		return order_id;
	}

	public void setOrder_id(Integer order_id) {
		this.order_id = order_id;
	}

	public Integer getMenuId() {
		return menuId;
	}

	public void setMenuId(Integer menuId) {
		this.menuId = menuId;
	}

	public Integer getNum() {
		return num;
	}

	public void setNum(Integer num) {
		this.num = num;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getBack_reason() {
		return back_reason;
	}

	public void setBack_reason(String back_reason) {
		this.back_reason = back_reason;
	}

	public String getBackor() {
		return backor;
	}

	public void setBackor(String backor) {
		this.backor = backor;
	}

	public String getBack_men() {
		return back_men;
	}

	public void setBack_men(String back_men) {
		this.back_men = back_men;
	}

	public String getOrder_time() {
		return order_time;
	}

	public void setOrder_time(String order_time) {
		this.order_time = order_time;
	}

	public String getInsert_order_time() {
		return insert_order_time;
	}

	public void setInsert_order_time(String insert_order_time) {
		this.insert_order_time = insert_order_time;
	}

	public String getCooker() {
		return cooker;
	}

	public void setCooker(String cooker) {
		this.cooker = cooker;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
