package com.dinner.common.entity;

import java.util.Date;



public class DcNetBuyMateExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion("dnbm.restId =", restId, "restId");
			return  this;
		}

		public Criteria andMateIdEqualTo(String mateId) {
			addCriterion("dnbm.mateId =", mateId, "mateId");
			return  this;
		}

		public Criteria andAddTimeGreaterThan(long time) {
			addCriterion("dnbm.addTime >", new Date(time), "addTime");
			return  this;
			
		}

		public Criteria andMateLike(String mateName) {
			addCriterion("sp.codeValue like", mateName, "codeValue");
			return  this;
		}


	}

}