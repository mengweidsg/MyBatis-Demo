package com.dinner.common.entity;



import java.math.BigDecimal;
import java.util.Date;


/**
 * 食材管理
 * @author 攻心小虫
 *
 */
public class DcMate {

	private Integer id;

	private Integer restId;

	private String mateId;

	private Integer kucun;

	private Integer lastBuy;
	private Date lastBuyDate;
	private BigDecimal lastBuyMoney;
	
	
	private Integer useNum;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getRestId() {
		return restId;
	}
	public void setRestId(Integer restId) {
		this.restId = restId;
	}
	public Integer getKucun() {
		return kucun;
	}
	public void setKucun(Integer kucun) {
		this.kucun = kucun;
	}
	public Date getLastBuyDate() {
		return lastBuyDate;
	}
	public void setLastBuyDate(Date lastBuyDate) {
		this.lastBuyDate = lastBuyDate;
	}
	public BigDecimal getLastBuyMoney() {
		return lastBuyMoney;
	}
	public void setLastBuyMoney(BigDecimal lastBuyMoney) {
		this.lastBuyMoney = lastBuyMoney;
	}
	public Integer getLastBuy() {
		return lastBuy;
	}
	public void setLastBuy(Integer lastBuy) {
		this.lastBuy = lastBuy;
	}
	public String getMateId() {
		return mateId;
	}
	public void setMateId(String mateId) {
		this.mateId = mateId;
	}
	public Integer getUseNum() {
		return useNum;
	}
	public void setUseNum(Integer useNum) {
		this.useNum = useNum;
	}

}