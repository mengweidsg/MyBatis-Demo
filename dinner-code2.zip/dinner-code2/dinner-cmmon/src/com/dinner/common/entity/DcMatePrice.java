package com.dinner.common.entity;

import java.math.BigDecimal;


/**
 * 食材单价
 * @author 攻心小虫
 *
 */
public class DcMatePrice {

	private Integer id;
	private String mateId;
	private BigDecimal price;

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMateId() {
		return mateId;
	}
	public void setMateId(String mateId) {
		this.mateId = mateId;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	

}