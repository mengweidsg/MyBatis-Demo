package com.dinner.common.entity;



public class DcEmployeeExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andIdEqualTo(int id) {
			addCriterion("id = ", id, "id");
			return this;
		}

		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion("restId = ", restId, "restId");
			return this;
		}

		public Criteria andNameLike(String name) {
			addCriterion("name  like ", name, "name");
			return this;
		}

		public Criteria andEmployeeTypeEqual(String employeeType) {
			addCriterion("employeeType  = ", employeeType, "employeeType");
			return this;
		}
		public Criteria andWorkIdEqualTo(String workId) {
			addCriterion("workId = ", workId, "workId");
			return (Criteria) this;
		}
		
		public Criteria andWorkPwdEqualTo(String workPwd) {
			addCriterion("workPwd = ", workPwd, "workPwd");
			return (Criteria) this;
		}
	}
   
}