package com.dinner.common.entity;



public class DcRoleExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andNameLike(String name) {
			addCriterion("name  like ", name, "name");
			return this;
		}

		public Criteria andUserTopEqualTo(Integer userTop) {
			addCriterion("userTop  = ", userTop, "userTop");
			return this;
			
		}

	}

}