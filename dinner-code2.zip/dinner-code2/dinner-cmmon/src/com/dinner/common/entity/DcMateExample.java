package com.dinner.common.entity;


public class DcMateExample extends DcExample {

	protected GeneratedCriteria createCriteriaInternal() {
		return new Criteria();
	}

	public class Criteria extends GeneratedCriteria {

		protected Criteria() {
			super();
		}

		public Criteria andRestIdEqualTo(Integer restId) {
			addCriterion("restId = ", restId, "restId");
			return (Criteria) this;
		}

		public Criteria andMateIdEqualTo(String mateId) {
			addCriterion("MateId = ", mateId, "MateId");
			return (Criteria) this;
		}
		
		public Criteria andMateIdLike(String mateId) {
			addCriterion("sp.codeValue like ", mateId, "MateId");
			return (Criteria) this;
		}

	}

}