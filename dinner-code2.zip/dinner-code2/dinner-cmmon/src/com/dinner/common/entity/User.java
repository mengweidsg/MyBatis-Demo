package com.dinner.common.entity;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 系统用户
 * 
 * @author admin
 * @create 2014年2月24日 下午1:57:59
 */
public class User {

	private String sessid;
	private Integer userId;
	private String loginName;
	private String pwd;
	private String name;
	private String mobile;
	private String status;
	private Integer userTop;
	private Date createTime = new Date(); // 创建时间
	private Date uptime = new Date(); // 更新时间
	private Integer restId;
	private String userType;
	

	private List<Privilege> privileges = Lists.newArrayList(); // 用户拥有的权限
	/**
	 * 用户所拥有的菜单权限
	 */
	private List<Privilege> menuTree;
	
	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	public String getLoginName() {
		return loginName;
	}

	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUptime() {
		return uptime;
	}

	public void setUptime(Date uptime) {
		this.uptime = uptime;
	}

	public List<Privilege> getPrivileges() {
		return privileges;
	}

	public void setPrivileges(List<Privilege> privileges) {
		this.privileges = privileges;
		createMenuTree();
	}

	public void createMenuTree() {
		this.menuTree = new ArrayList<Privilege>();
		for (Privilege privilege : privileges) {
			// 一级、二级菜单
			if (privilege.getLevel().intValue() == Privilege.ONE_LEVEL_MENU
					|| privilege.getLevel().intValue() == Privilege.TWO_LEVEL_MENU) {
				this.menuTree.add(privilege);
			}
		}
	}

	public List<Privilege> getMenuTree() {
		if (menuTree == null) {
			return Lists.newArrayList();
		}
		return menuTree;
	}

	public Integer getRestId() {
		return restId;
	}

	public void setRestId(Integer restId) {
		this.restId = restId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSessid() {
		return sessid;
	}

	public void setSessid(String sessid) {
		this.sessid = sessid;
	}

	public Integer getUserTop() {
		return userTop;
	}

	public void setUserTop(Integer userTop) {
		this.userTop = userTop;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	
}
