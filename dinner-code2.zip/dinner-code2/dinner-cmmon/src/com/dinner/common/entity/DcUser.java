package com.dinner.common.entity;

import java.util.Date;

/**
 * 点餐系统注册用户
 * 
 * @author yu.han 2014年6月30日 下午4:40:45
 * 
 */
public class DcUser {
    private Integer id;// 主键ID
    private String name;// 用户名
    private String password;// 密码
    private String mobile;// 手机号
    private String nickName;// 昵称
    private String email;// 邮箱
    private String qq;// 扣扣
    private String phone;// 座机
    private Date createTime;// 创建时间
    private Date updateTime;// 修改时间

    public String getNickName() {
	return nickName;
    }

    public void setNickName(String nickName) {
	this.nickName = nickName;
    }

    public String getEmail() {
	return email;
    }

    public void setEmail(String email) {
	this.email = email;
    }

    public String getQq() {
	return qq;
    }

    public void setQq(String qq) {
	this.qq = qq;
    }

    public String getPhone() {
	return phone;
    }

    public void setPhone(String phone) {
	this.phone = phone;
    }

    public Integer getId() {
	return id;
    }

    public void setId(Integer id) {
	this.id = id;
    }

    public String getName() {
	return name;
    }

    public void setName(String name) {
	this.name = name;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
	this.password = password;
    }

    public String getMobile() {
	return mobile;
    }

    public void setMobile(String mobile) {
	this.mobile = mobile;
    }

    public Date getCreateTime() {
	return createTime;
    }

    public void setCreateTime(Date createTime) {
	this.createTime = createTime;
    }

    public Date getUpdateTime() {
	return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
	this.updateTime = updateTime;
    }

}
