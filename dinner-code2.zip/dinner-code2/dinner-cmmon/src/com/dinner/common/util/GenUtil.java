package com.dinner.common.util;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

import org.apache.commons.lang.RandomStringUtils;

public class GenUtil {

	/**
	 * 生成订单号
	 * 
	 * @return
	 */
	public static String generateOrderNo() {
		String seq = RandomStringUtils.randomNumeric(8);
		DateFormat df = new SimpleDateFormat("yyMMddmmssHH");
		seq = df.format(new Date()) + seq;
		return seq;
	}

	public static String generate32Seq() {
		return UUID.randomUUID().toString().replace("-", "");
	}

	public static String genSmsCode() {
		String ranCode = RandomStringUtils.randomNumeric(6);
		return ranCode;
	}

	public static String genSmsSeq() {
		return RandomStringUtils.randomNumeric(9);
	}
}