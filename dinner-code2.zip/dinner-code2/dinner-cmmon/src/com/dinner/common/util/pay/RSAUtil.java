package com.dinner.common.util.pay;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import javax.crypto.Cipher;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

public class RSAUtil {

	private static final Logger	log					= Logger.getLogger(RSAUtil.class);

	private static String		MESSAGE_ALGORITHM	= "RSA";
	private static String		SIGNATURE_ALGORITHM	= "SHA1withRSA";

	/** 聚宝吧的私钥 */
	public static String		privKeyString		= "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKcmNr1UQlNznt8w"
															+ "2sLkP1MDsD0gjk25rtpYWy2SXTt5JtPjIu4nX1LbMY8W0cOzlpOWKrwwA0q8L80N"
															+ "HweOQ0/BGWYDIGFOUxC4eDETY/tbfHhfkr2oyzxTCdOiVsODTn/VCpUaiovvxvII"
															+ "s+edq3GyKAQx/n5vyK6mTcAR5LyjAgMBAAECgYBV3HJoBR1hAtaMbesiC99fhFiG"
															+ "ve97i7N/I74KhdHwmAZS961cysrTpBcsGpu8PMdPnubq7nrybALeASx8VB7Mx09J"
															+ "Bj1EkNopUMcpkZCxNg7cU3QIe9sU5hTWcepgoPscUVITODf2PrhemSzBRHT9xU0f"
															+ "NwpoJ1XKYJ/nyHSqaQJBANtyjPAUZ1BgcjGou6D7rUf4MfTaCtrFdetxapN2EuU/"
															+ "hLGGRBcqL1fnDXx3Qk4yWQneaSnHx7gvrjXeDfFUFA8CQQDC/Z5Vor/Limh7qKa1"
															+ "ugXcGILWq39wNg6Lt8wNocZshp4mTf6cQKu/zN80li0EDR7gIIIBRhp6/dRuBBdi"
															+ "QWotAkEAx5Z55OlJxerSMaQ7coE06t4r4Xxmnu80/ryaqB+ds+9/ak6poz/060f0"
															+ "Fh4JqkFUhgtJLnzLgxOqqMebesBztQJBAJcVpIV+IVY43FRUjTfp93helaJ4J7pu"
															+ "aD7iHv3BB9o3RHsxm8K+aVWoDJrWcfLdp7rJ9XG/O+1omBzWlrfPL9ECQEO4oyjb"
															+ "5d1VB9vv9XVQUJcE8XkGobj1AC478nMTofgfMgdyGPSMVmY5XqrXGFzOr+6UPIyM"
															+ "Qh6SF40nklJHRsk=";

	/** 聚宝吧的公钥 */
	public static String		publicKeyString		= "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCnJja9VEJTc57fMNrC5D9TA7A9"
															+ "II5Nua7aWFstkl07eSbT4yLuJ19S2zGPFtHDs5aTliq8MANKvC/NDR8HjkNPwRlm"
															+ "AyBhTlMQuHgxE2P7W3x4X5K9qMs8UwnTolbDg05/1QqVGoqL78byCLPnnatxsigE"
															+ "Mf5+b8iupk3AEeS8owIDAQAB";

	private static PrivateKey convertToPrivateKey(String privKeyString) {
		try {
			byte[] privKeyByte = Base64.decodeBase64(privKeyString);
			PKCS8EncodedKeySpec privKeySpec = new PKCS8EncodedKeySpec(privKeyByte);
			KeyFactory kf = KeyFactory.getInstance(MESSAGE_ALGORITHM);
			return kf.generatePrivate(privKeySpec);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	private static PublicKey convertToPublicKey(String pubKeyString) {
		try {
			byte[] pubKeyByte = Base64.decodeBase64(pubKeyString);
			X509EncodedKeySpec pubKeySpec = new X509EncodedKeySpec(pubKeyByte);
			KeyFactory kf = KeyFactory.getInstance(MESSAGE_ALGORITHM);
			return kf.generatePublic(pubKeySpec);
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	public static String encrypt(String pubKeyString, String plainText) {

		try {
			PublicKey pubKey = convertToPublicKey(pubKeyString);
			Cipher cipher = Cipher.getInstance(MESSAGE_ALGORITHM);
			cipher.init(Cipher.ENCRYPT_MODE, pubKey);
			byte[] cipherByte = cipher.doFinal(plainText.getBytes("UTF-8"));
			return new String(Base64.encodeBase64(cipherByte));
		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	public static String sign(String privKeyString, String psw, String plainText) {
		try {

			PrivateKey privKey = convertToPrivateKey(privKeyString);
			Signature signature = Signature.getInstance(SIGNATURE_ALGORITHM);
			signature.initSign(privKey);
			String digest = plainText + psw;
			signature.update(digest.getBytes("UTF-8"));
			byte[] signedByte = signature.sign();
			return new String(Base64.encodeBase64(signedByte));

		} catch (Exception e) {
			log.error(e);
		}
		return null;
	}

	public static String decrypt(String privKeyString, String cipherText) {

		try {

			PrivateKey privKey = convertToPrivateKey(privKeyString);
			Cipher cipher = Cipher.getInstance(MESSAGE_ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE, privKey);
			byte[] plainByte = cipher.doFinal(Base64.decodeBase64(cipherText.getBytes("UTF-8")));
			return new String(plainByte);

		} catch (Exception e) {
			log.error(e);
		}
		return null;

	}

	public static boolean verify(String pubKeyString, String psw, String plainText, String signature) {

		try {

			PublicKey pubKey = convertToPublicKey(pubKeyString);
			Signature sig = Signature.getInstance(SIGNATURE_ALGORITHM);
			sig.initVerify(pubKey);
			String digest = plainText + psw;
			sig.update(digest.getBytes("UTF-8"));
			return sig.verify(Base64.decodeBase64(signature));
		} catch (Exception e) {
			log.error(e);
		}
		return false;
	}
}
