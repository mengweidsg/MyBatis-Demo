package com.dinner.common.service.biz.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcMateDAO;
import com.dinner.common.dao.auto.DcNetBuyMateDAO;
import com.dinner.common.entity.DcMate;
import com.dinner.common.entity.DcNetBuyMate;
import com.dinner.common.entity.DcNetBuyMateExample;
import com.dinner.common.entity.LogMate;
import com.dinner.common.service.biz.DcMateService;
import com.dinner.common.service.biz.DcNetBuyMateService;

/**
 * 食材受理管理service
 * 
 * @author yeyj
 * 
 */
@Service("dcNetBuyMateService")
public class DcNetBuyMateServiceImpl implements DcNetBuyMateService {
	@Resource
	private DcNetBuyMateDAO dcNetBuyMateDAO;
	@Resource
	private DcMateDAO dcMateDAO;
	@Resource
	private DcMateService dcMateService;
	public List<Map<String,Object>> queryList(DcNetBuyMateExample example) {
		example.setTotalCount(dcNetBuyMateDAO.countByExample(example));
		return dcNetBuyMateDAO.selectByExample(example);
	}

	@Override
	public DcNetBuyMate selectById(int restId) {
		return dcNetBuyMateDAO.selectByPrimaryKey(restId);
	}

	@Override
	public void update(DcNetBuyMate rest) {
		dcNetBuyMateDAO.updateByPrimaryKey(rest);

	}

	@Override
	public void save(DcNetBuyMate rest) {
//		DcExample example = new DcMateExample();
//		Criteria criteria = (Criteria) example.createCriteria();
//		criteria.andRestIdEqualTo(rest.getRestId());
//		criteria.andMateIdEqualTo(rest.getMateId());
//		List<DcMate> selectByExample = dcMateDAO.selectByExample(example);
//		
//		if(selectByExample != null && selectByExample.size() >0){
//			DcMate dcMate = selectByExample.get(0);
//			dcMate.setKucun(dcMate.getKucun()+rest.getAddNum());
//			dcMate.setLastBuy(rest.getAddNum());
//			dcMate.setLastBuyMoney(rest.getAddMoney());
//			dcMate.setLastBuyDate(new Date());
//			dcMateDAO.updateByPrimaryKey(dcMate);
//		}else{
//			DcMate dcMate = new DcMate();
//			dcMate.setMateId(rest.getMateId());
//			dcMate.setRestId(rest.getRestId());
//			dcMate.setKucun(rest.getAddNum());
//			dcMate.setLastBuy(rest.getAddNum());
//			dcMate.setLastBuyMoney(rest.getAddMoney());
//			dcMate.setLastBuyDate(new Date());
//			dcMateDAO.insert(dcMate);
//		}
		
		dcNetBuyMateDAO.insert(rest);
	}

	@Override
	public void delete(int id) {
		dcNetBuyMateDAO.deleteByPrimaryKey(id);

	}

	@Override
	public int changeStatus(int id, int status,int restId) {
		DcNetBuyMate bean = dcNetBuyMateDAO.selectByPrimaryKey(id);
		if(bean != null){
			if(bean.getStatus() ==0){
				if(status==3){ //可删除
					dcNetBuyMateDAO.deleteByPrimaryKey(bean.getId());
				}else if(status == 1){//受理
					bean.setStatus(1);
					bean.setDealTime(new Date());
					dcNetBuyMateDAO.updateByPrimaryKey(bean);
				}else if(status == -1){//受理
					bean.setStatus(-1);
					dcNetBuyMateDAO.updateByPrimaryKey(bean);
				}else{
					return -1;	//不能操作
				}
			}else if(bean.getStatus() == 1){
				if(status == 2){	//提交
					bean.setSubmitTime(new Date());
					bean.setStatus(2);
					dcNetBuyMateDAO.updateByPrimaryKey(bean);
					
					DcMate dcMate = new DcMate();
					dcMate.setRestId(restId);
					dcMate.setMateId(bean.getMateId());
					dcMate.setLastBuy(bean.getAddNum()*1000);
					dcMate.setLastBuyDate(new Date());
					dcMate.setLastBuyMoney(bean.getAddMoney());
					dcMate.setKucun(bean.getAddNum()*1000);
					
					LogMate lm = new LogMate();
					lm.setAddNum(bean.getAddNum()*1000);
					lm.setAddMoney(bean.getAddMoney());
					lm.setRestId(restId);
					lm.setRemark("");
					lm.setAddType(1);
					lm.setMateId(bean.getMateId());
					
					dcMateService.save(dcMate,lm);
					
				}else if(status == -9){	//管理员强制删除
					dcNetBuyMateDAO.deleteByPrimaryKey(bean.getId());
				}else{
					return -2;
				}
			}else if(bean.getStatus() == 2){
				return -3;
			}
			return 0;
		}else{
			return -4;
		}
	}
	
	public boolean hasNewData(DcNetBuyMateExample query) {
		int checkMateId = dcNetBuyMateDAO.countByExample(query);
		return checkMateId==0;
	}
}