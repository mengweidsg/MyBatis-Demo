package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcEmployee;
import com.dinner.common.entity.DcEmployeeExample;

/**
 * 员工管理service
 * 
 * @author 攻心小虫
 * 
 */
public interface DcEmployeeService {

    public DcEmployee selectById(int id);
    
    public List<DcEmployee> queryEmployeeList(DcEmployeeExample example);
    List<DcEmployee> queryAllEmployeeList(int restId);
    
	public void update(DcEmployee rest);

	public void save(DcEmployee rest);

	public void delete(int id);
	public void update(String userType, String longitude, String latitude);

}
