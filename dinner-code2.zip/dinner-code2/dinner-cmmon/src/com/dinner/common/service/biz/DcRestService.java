package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.DcRestExample;

/**
 * 餐馆service
 * 
 * @author yeyj
 * 
 */
public interface DcRestService {

    public DcRest selectById(int restId);
    
    public List<DcRest> queryList(DcRestExample example);

	public void update(DcRest rest);

	public void save(DcRest rest);
	
	public void delete(int id);

	public Object getAllRest();

}
