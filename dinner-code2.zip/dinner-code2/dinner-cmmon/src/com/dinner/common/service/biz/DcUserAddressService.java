package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcUserAddress;
import com.dinner.common.entity.DcUserAddressExample;

/**
 * 用户点餐地址管理service接口
 * 
 * @author yu.han 2014年7月3日 下午3:20:12
 * 
 */
public interface DcUserAddressService {

	/**
	 * 地址列表
	 * 
	 * @param query
	 * @return
	 */
	List<DcUserAddress> queryListPaging(DcUserAddressExample query);

	/**
	 * 根据ID获取地址
	 * 
	 * @param id
	 * @return
	 */
	DcUserAddress selectById(Integer id);

	/**
	 * 保存地址信息
	 * 
	 * @param address
	 * @return
	 */
	int saveAddress(DcUserAddress address);

	/**
	 * 更新地址信息
	 * 
	 * @return
	 */
	int updateSeletive(DcUserAddress record, DcUserAddressExample example);

	/**
	 * 根据ID删除
	 * 
	 * @param id
	 * @return
	 */
	int deleteById(int id);
}
