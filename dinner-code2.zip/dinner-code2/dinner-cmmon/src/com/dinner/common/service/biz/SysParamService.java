package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.SysParam;

/**
 * 参数服务接口
 * 
 * @author 攻心小虫
 * 
 */
public interface SysParamService {

    public List<SysParam> query();
    
    public void save(SysParam sysParam);
    
    public void update(SysParam sysParam);
    
    public void delParam(int id);

	public SysParam selectById(int id);

	public List<SysParam> getParam(String name);

}
