package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcUser;
import com.dinner.common.entity.DcUserExample;

/**
 * 点餐用户service
 * 
 * @author yu.han 2014年6月30日 下午5:06:10
 * 
 */
public interface DcUserService  {
	/**
     * 根据查询条件获取一条用户信息
     * 
     * @param query
     * @return
     */
    public List<DcUser> queryUserList(DcUserExample query);
    
    
    /**
     * 根据查询条件获取一条用户信息
     * 
     * @param query
     * @return
     */
    public DcUser findOne(DcUser query);

    /**
     * 根据手机号修改密码
     * 
     * @param entity
     * @return
     */
    public int updateByMob(DcUser entity);


	public List<DcUser> queryRestUserList(DcUserExample query);


	public boolean saveSale(Integer restId, String sale, String userId);
}
