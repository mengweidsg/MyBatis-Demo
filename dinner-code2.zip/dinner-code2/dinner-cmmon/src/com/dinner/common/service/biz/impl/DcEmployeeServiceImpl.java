package com.dinner.common.service.biz.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcEmployeeDAO;
import com.dinner.common.entity.DcEmployee;
import com.dinner.common.entity.DcEmployeeExample;
import com.dinner.common.service.biz.DcEmployeeService;

/**
 * 员工管理service
 * 
 * @author yeyj
 * 
 */
@Service("dcEmployeeService")
public class DcEmployeeServiceImpl implements DcEmployeeService {
	@Resource
	private DcEmployeeDAO dcEmployeeDAO;

	public List<DcEmployee> queryEmployeeList(DcEmployeeExample example) {
		example.setTotalCount(dcEmployeeDAO.countByExample(example));
		return dcEmployeeDAO.selectByExample(example);
	}

	@Override
	public DcEmployee selectById(int restId) {
		return dcEmployeeDAO.selectByPrimaryKey(restId);
	}

	@Override
	public void update(DcEmployee rest) {
		dcEmployeeDAO.updateByPrimaryKey(rest);

	}

	@Override
	public void save(DcEmployee rest) {
		dcEmployeeDAO.insert(rest);
	}

	@Override
	public void delete(int id) {
		dcEmployeeDAO.deleteByPrimaryKey(id);

	}

	@Override
	public List<DcEmployee> queryAllEmployeeList(int restId) {
		// TODO Auto-generated method stub
		return dcEmployeeDAO.queryAllEmployeeList(restId);
	}

	@Override
	public void update(String id, String longitude, String latitude) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("x_coordinate", longitude);
		map.put("y_coordinate", latitude);
		dcEmployeeDAO.update(map);
		
	}
}
