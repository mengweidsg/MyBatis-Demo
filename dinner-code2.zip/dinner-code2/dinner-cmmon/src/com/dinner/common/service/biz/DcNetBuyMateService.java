package com.dinner.common.service.biz;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcNetBuyMate;
import com.dinner.common.entity.DcNetBuyMateExample;

/**
 * 食材受理管理service
 * 
 * @author 攻心小虫
 * 
 */
public interface DcNetBuyMateService {

    public DcNetBuyMate selectById(int id);
    
    public List<Map<String,Object>> queryList(DcNetBuyMateExample example);
    
	public void update(DcNetBuyMate rest);

	public void save(DcNetBuyMate rest);

	public void delete(int id);

	public int changeStatus(int id, int status,int restId);

	public boolean hasNewData(DcNetBuyMateExample query);
}
