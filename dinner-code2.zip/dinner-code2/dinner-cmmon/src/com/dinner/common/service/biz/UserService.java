package com.dinner.common.service.biz;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.Privilege;
import com.dinner.common.entity.User;
import com.dinner.common.entity.UserExample;

/**
 * 系统用户服务接口
 * 
 * @author 攻心小虫
 */
public interface UserService {

    /**
     * 用户登陆, 根据登录名、密码返回用户
     * 
     * @param loginName
     * @param pwd
     * @return 如果没有对应用户则返回null
     */
    public User longin(String loginName, String pwd);

    /**
     * 获取用户已拥有的权限(包括用户通过岗位获取的权限、以及用户被直接分配的权限)
     * 
     * @param userId
     * @return
     */
    public List<Privilege> getPrivileges(Integer userId);


    /**
     * 修改密码
     * 
     * @param userId
     * @param oldPwd
     * @param newPwd
     * @return
     */
    public void modifyPwd(Integer userId, String oldPwd, String newPwd);


    public List<Map<String, Object>> queryList(UserExample example);
    
   	public void update(User user, String roleId);

   	public void save(User user, String roleId);

   	public void delete(int id);

   	User selectByPrimaryKey(int id);

	public List<DcRole> getAllRole();

	public Integer selectRole(int userId);

	User getByLoginName(String loginName);

	public List<DcRole> getAllRole(Integer userId);

	public List<Map<String, Object>> queryCookList(UserExample query);

	public User longinForEmployee(String loginName, String pwd);

	public int getUserByRestId(Integer id);


    
}
