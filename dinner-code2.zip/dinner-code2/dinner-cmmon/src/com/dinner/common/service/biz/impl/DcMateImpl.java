package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcMateDAO;
import com.dinner.common.dao.auto.LogMateDAO;
import com.dinner.common.entity.DcMate;
import com.dinner.common.entity.DcMateExample;
import com.dinner.common.entity.DcMateExample.Criteria;
import com.dinner.common.entity.LogMate;
import com.dinner.common.service.biz.DcMateService;

/**
 * 食材管理service
 * 
 * @author yeyj
 * 
 */
@Service("dcMateService")
public class DcMateImpl implements DcMateService {
	@Resource
	private DcMateDAO dcMateDAO;
	
	@Resource
	private LogMateDAO logMateDAO;

	public List<DcMate> queryList(DcMateExample example) {
		example.setTotalCount(dcMateDAO.countByExample(example));
		return dcMateDAO.selectByExample(example);
	}

	@Override
	public DcMate selectById(int restId) {
		return dcMateDAO.selectByPrimaryKey(restId);
	}

	@Override
	public void update(DcMate rest) {
		dcMateDAO.updateByPrimaryKey(rest);

	}

	@Override
	public void save(DcMate rest) {
		dcMateDAO.insert(rest);
	}

	@Override
	public void delete(int id) {
		dcMateDAO.deleteByPrimaryKey(id);

	}

	@Override
	public void save(DcMate dcMate, LogMate lm) {
		DcMateExample query = new DcMateExample();
		DcMateExample.Criteria criteria = (Criteria) query.createCriteria();
		criteria.andRestIdEqualTo(dcMate.getRestId());
		criteria.andMateIdEqualTo(dcMate.getMateId());
		List<DcMate> selectByExample = dcMateDAO.selectByExample(query);
		if(selectByExample !=null && selectByExample.size() >0){
			DcMate dm = selectByExample.get(0);
			dm.setKucun(dcMate.getKucun()+dm.getKucun());
			dm.setLastBuy(dcMate.getLastBuy());
			dm.setLastBuyMoney(dcMate.getLastBuyMoney());
			dm.setUseNum(0);
			dcMateDAO.updateByPrimaryKey(dm);
		}else{
			dcMateDAO.insert(dcMate);
		}
		logMateDAO.insert(lm);
	}

	@Override
	public void updateKucun(String dataId, String kucun) {
		DcMate selectByPrimaryKey = dcMateDAO.selectByPrimaryKey(Integer.parseInt(dataId));
		if(selectByPrimaryKey != null){
			selectByPrimaryKey.setKucun(Integer.parseInt(kucun));
			dcMateDAO.updateByPrimaryKey(selectByPrimaryKey);
		}
	}

	@Override
	public DcMate getMateInfo(String metaId, Integer restId) {
		DcMateExample query = new DcMateExample();
		DcMateExample.Criteria criteria = (Criteria) query.createCriteria();
		criteria.andRestIdEqualTo(restId);
		criteria.andMateIdEqualTo(metaId);
		List<DcMate> l = dcMateDAO.selectByExample(query);
		
		return l!=null&&l.size()>0?l.get(0):null;
	}
}
