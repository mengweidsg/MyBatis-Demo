package com.dinner.common.service.biz;

import java.util.List;


public interface ReportService {

	List<?> money(String start, String end, Integer restId);

	List<?> srxx(String start, String end);

}
