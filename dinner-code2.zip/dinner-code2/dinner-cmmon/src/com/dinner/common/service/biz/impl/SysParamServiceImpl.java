package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.SysParamDAO;
import com.dinner.common.entity.SysParam;
import com.dinner.common.service.biz.SysParamService;

/**
 * 数字字典service
 * 
 * @author 攻心小虫
 * 
 */
@Service("sysParamService")
public class SysParamServiceImpl implements SysParamService {
	
	@Resource
	private SysParamDAO sysParamDAO;

	@Override
	public List<SysParam> query() {
		return sysParamDAO.query();
	}

	@Override
	public void save(SysParam sysParam) {
		sysParamDAO.insert(sysParam);
		
	}

	@Override
	public void update(SysParam sysParam) {
		sysParamDAO.update(sysParam);
		
	}

	@Override
	public void delParam(int id) {
		sysParamDAO.delete(id);
		
	}

	@Override
	public SysParam selectById(int id) {
		return sysParamDAO.selectById(id);
	}

	@Override
	public List<SysParam> getParam(String name) {
		// TODO Auto-generated method stub
		return sysParamDAO.getParam(name);
	}

}
