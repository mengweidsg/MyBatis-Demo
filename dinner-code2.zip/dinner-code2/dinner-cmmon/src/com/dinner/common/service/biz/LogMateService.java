package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.LogMate;
import com.dinner.common.entity.LogMateExample;

/**
 * 食材管理service
 * 
 * @author 攻心小虫
 * 
 */
public interface LogMateService {

    public List<LogMate> queryList(LogMateExample example);
    
	public void save(LogMate rest);

}
