package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcExample;
 
public interface BaseService<T> {

	public List<T> queryList(DcExample example);

	public void update(T user);

	public void save(T user);

	public void delete(int id);

	T selectByPrimaryKey(int id);

}
