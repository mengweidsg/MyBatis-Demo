package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcUserAddressDAO;
import com.dinner.common.entity.DcUserAddress;
import com.dinner.common.entity.DcUserAddressExample;
import com.dinner.common.service.biz.DcUserAddressService;

/**
 * 用户订餐地址管理service实现
 * 
 * @author yu.han 2014年7月3日 下午5:14:12
 * 
 */
@Service("dcUserAddressService")
public class DcUserAddressServiceImpl implements DcUserAddressService {
	@Resource
	private DcUserAddressDAO dcUserAddressDAO;

	@Override
	public List<DcUserAddress> queryListPaging(DcUserAddressExample query) {
		int totalCount = dcUserAddressDAO.countByExample(query);
		query.setTotalCount(totalCount);
		return dcUserAddressDAO.selectByExample(query);
	}

	@Override
	public DcUserAddress selectById(Integer id) {
		return dcUserAddressDAO.selectByPrimaryKey(id);
	}

	@Override
	public int saveAddress(DcUserAddress address) {
		if(null == address){
			return 0;
		}
		if(address.getId() != null){
			return dcUserAddressDAO.updateByPrimaryKey(address);
		}
		return dcUserAddressDAO.insert(address);
	}

	@Override
	public int deleteById(int id) {
		return dcUserAddressDAO.deleteByPrimaryKey(id);
	}

	@Override
	public int updateSeletive(DcUserAddress record, DcUserAddressExample example) {
		return dcUserAddressDAO.updateByExampleSelective(record, example);
	}
}
