package com.dinner.common.service.biz.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcUserDAO;
import com.dinner.common.entity.DcUser;
import com.dinner.common.entity.DcUserExample;
import com.dinner.common.service.biz.DcUserService;

/**
 * 点餐用户service实现
 * 
 * @author yu.han 2014年6月30日 下午5:36:17
 * 
 */
@Service("dcUserService")
public class DcUserServiceImpl implements DcUserService {
	@Resource
	private DcUserDAO dcUserDao;

	@Override
	public DcUser findOne(DcUser query) {
		return dcUserDao.findOne(query);
	}

	@Override
	public int updateByMob(DcUser entity) {
		return dcUserDao.updateByMob(entity);
	}

	@Override
	public List<DcUser> queryUserList(DcUserExample example) {
		example.setTotalCount(dcUserDao.countByExample(example));
		return dcUserDao.queryUserList(example);
	}

	@Override
	public List<DcUser> queryRestUserList(DcUserExample example) {
		example.setTotalCount(dcUserDao.countRestByExample(example));
		return dcUserDao.queryRestUserList(example);
	}

	@Override
	public boolean saveSale(Integer restId, String sale, String userId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("restId", restId);
		map.put("sale", sale);
		map.put("userId", userId);
		return dcUserDao.saveSale(map);
	}

}
