package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.LogMateDAO;
import com.dinner.common.entity.LogMate;
import com.dinner.common.entity.LogMateExample;
import com.dinner.common.service.biz.LogMateService;

/**
 * 食材管理service
 * 
 * @author yeyj
 * 
 */
@Service("logMateService")
public class LogMateImpl implements LogMateService {
	@Resource
	private LogMateDAO logMateDAO;

	public List<LogMate> queryList(LogMateExample example) {
		example.setTotalCount(logMateDAO.countByExample(example));
		return logMateDAO.selectByExample(example);
	}

	@Override
	public void save(LogMate rest) {
		logMateDAO.insert(rest);
	}

}
