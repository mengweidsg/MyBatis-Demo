package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcMatePriceDAO;
import com.dinner.common.entity.DcMatePrice;
import com.dinner.common.entity.DcMatePriceExample;
import com.dinner.common.service.biz.DcMatePriceService;

/**
 * 食材单价service
 * 
 * 
 */
@Service("dcMatePriceService")
public class DcMatePriceServiceImpl implements DcMatePriceService {
	@Resource
	private DcMatePriceDAO dcMatePriceDAO;
	
	public List<DcMatePrice> queryList(DcMatePriceExample example) {
		example.setTotalCount(dcMatePriceDAO.countByExample(example));
		return dcMatePriceDAO.selectByExample(example);
	}

	@Override
	public DcMatePrice selectById(int restId) {
		return dcMatePriceDAO.selectByPrimaryKey(restId);
	}

	@Override
	public void update(DcMatePrice rest) {
		dcMatePriceDAO.updateByPrimaryKey(rest);
	}

	@Override
	public void save(DcMatePrice rest) {
		dcMatePriceDAO.insert(rest);
	}

	@Override
	public void delete(int id) {
		dcMatePriceDAO.deleteByPrimaryKey(id);
	}

	@Override
	public boolean checkMateId(DcMatePriceExample example) {
		int checkMateId = dcMatePriceDAO.countByExample(example);
		return checkMateId==0;
	}

	
}
