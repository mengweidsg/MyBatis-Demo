package com.dinner.common.service.biz.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcEmployeeDAO;
import com.dinner.common.dao.auto.DcMateDAO;
import com.dinner.common.dao.auto.DcOrderDAO;
import com.dinner.common.entity.DcExample;
import com.dinner.common.entity.DcMate;
import com.dinner.common.entity.DcMateExample;
import com.dinner.common.entity.DcOrder;
import com.dinner.common.entity.DcOrderMenu;
import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.User;
import com.dinner.common.entity.DcMateExample.Criteria;
import com.dinner.common.service.biz.DcOrderService;
import com.dinner.common.service.biz.UserService;

@Service("dcOrderService")
public class DcOrderServiceImpl implements DcOrderService {
	
	@Resource
	private DcOrderDAO dcOrderDAO;
	
	@Resource
	private DcEmployeeDAO dcEmployeeDAO;
	
	@Resource
	private UserService userService;
	
	@Resource
	private DcMateDAO dcMateDAO;
	
	@Override
	public List<DcOrder> queryList(DcExample example) {
		example.setTotalCount(dcOrderDAO.countByExample(example));
		return dcOrderDAO.selectByExample(example);
	}

	@Override
	public List<Map<String, Object>> querySubmitList(DcExample example) {
		example.setTotalCount(dcOrderDAO.countByExample(example));
		return dcOrderDAO.selectForSubmitByExample(example);
	}
	
	@Override
	public void delete(int id) {
		dcOrderDAO.deleteByPrimaryKey(id);
	}

	@Override
	public DcOrder selectByPrimaryKey(int id) {
		return dcOrderDAO.selectByPrimaryKey(id);
	}

	@Override
	public void update(DcOrder t) {
		dcOrderDAO.updateByPrimaryKey(t);
		
	}

	@Override
	public void save(DcOrder t) {
		dcOrderDAO.insert(t);
	}

	
	public List<Map<String,Object>> selectMenuById(int orderId,Integer menuId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", orderId);
		if(menuId != null){
			map.put("menuId", menuId);
		}
		return dcOrderDAO.selectMenuById(map);
	}


	@Override
	public void insertMenu(List<DcOrderMenu> l) {
		for(DcOrderMenu menu:l){
			dcOrderDAO.insertMenu(menu);
		}
	}

	@Override
	public void updateMenu(Integer orderId,List<DcOrderMenu> l) {
		dcOrderDAO.deleteAllMenu(orderId);
		insertMenu(l);
	}

	@Override
	public void saveBack(String orderId, String menuIds, String reason, String backor, String backorPwd, String backMen, String backMenPwd, Integer restId) {
		
		User longin = userService.longin(backor, backorPwd);
		
		User longin2 = userService.longin(backMen, backMenPwd);
		
		if(!longin2.getUserType().equals("4")){
			throw new NullPointerException("不存在当前退菜执行人");
		}
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("orderId", orderId);
		map.put("menuIds", menuIds);
		map.put("reason", reason);
		map.put("backName", longin.getName());
		map.put("backMenName", longin2.getName());
		dcOrderDAO.saveBack(map);
		
		int result = dcOrderDAO.countBackByExample(orderId);
		if(result == 0){
			//说明全部退菜
			DcOrder bean = dcOrderDAO.selectByPrimaryKey(Integer.parseInt(orderId));
			bean.setState(3);
			dcOrderDAO.updateByPrimaryKey(bean);
		}
	}

	@Override
	public void saveprice(Integer id) {
		dcOrderDAO.saveprice(id);
		
	}

	@Override
	public void savesell(String orderId, String name) {
		DcOrder bean = dcOrderDAO.selectByPrimaryKey(Integer.parseInt(orderId));
		if(bean != null){
			bean.setIspay(1);
			bean.setPay_time(new Date());
			bean.setCashor(name);
			bean.setState(2);
			dcOrderDAO.saveSell(bean);
		}
	}

	@Override
	public List<Map<String, Object>> queryCook(Integer restId) {
		return dcOrderDAO.queryCook(restId);
	}

	@Override
	public Map<String, List<Map<String, Object>>> queryCookForMap(Integer restId) {
		List<Map<String, Object>> l = dcOrderDAO.queryCookForMap(restId);
		Map<String, List<Map<String, Object>>> map = new HashMap<String,List<Map<String, Object>>>();
		String mark_type = null;
		List<Map<String, Object>> mark_list = null;
		for(Map<String, Object> m :l){
			String type = String.valueOf(m.get("type"));
			if(mark_type == null || !type.equals(mark_type)){	//第一次
				mark_list = new ArrayList<Map<String, Object>>();
				mark_type = type;
				map.put(type, mark_list);
			}
			mark_list.add(m);
		}
		return map;
	}
	
	@Override
	public void update(String cooker, String ids,int restId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("cooker", cooker);
		map.put("ids", ids.split(","));
		dcOrderDAO.updateCooker(map);
		
		map.put("restId", restId);
		
		List<Map<String, Object>> selectMateUse = dcOrderDAO.selectMateUse(map);
		
		DcMateExample query = new DcMateExample();
		DcMateExample.Criteria criteria = (Criteria) query.createCriteria();
		criteria.andRestIdEqualTo(restId);
		for(Map<String, Object> s:selectMateUse){
			criteria.andMateIdEqualTo(String.valueOf(s.get("mateId")));
			
			List<DcMate> selectByExample = dcMateDAO.selectByExample(query);
			if(selectByExample !=null && selectByExample.size() >0){
				DcMate dm = selectByExample.get(0);
				dm.setKucun(dm.getKucun()-Integer.parseInt(String.valueOf(s.get("use"))));
				dm.setUseNum(dm.getUseNum()+Integer.parseInt(String.valueOf(s.get("use"))));
				dcMateDAO.updateByPrimaryKey(dm);
			}
		}
		
		//更新库存
		
		
		
	}

	public void update(String ids) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("ids", ids.split(","));
		dcOrderDAO.updateCookerStatus(map);
	}

	@Override
	public void changeSubmit(int id) {
		dcOrderDAO.changeSubmit(id);
	}

	@Override
	public void submitSend(int id,int status) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("status", status);
		String type = "";
		switch(status){
		case 0:
			type = "sendTime";
			break;
		case 1:
			type = "sendGetTime";
			break;
		case 2:
			type = "sendSureTime";
			break;
		case 3:
			type = "sendFinishTime";
			break;
		}
		map.put("sendStatus", type);
		dcOrderDAO.submitSend(map);
	}

	@Override
	public void dealOrder(int id, String status) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("status", status);
		
		dcOrderDAO.dealOrder(map);
	}

	@Override
	public void deleteOrder(int order_id) {
		dcOrderDAO.deleteAllMenu(order_id);
		dcOrderDAO.deleteByPrimaryKey(order_id);
	}

	@Override
	public void sendSend(int id,String yesNo) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("yesNo", yesNo);
		dcOrderDAO.sendSend(map);
	}

	@Override
	public void setEmployee(int id,int orderId,String name) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("id", id);
		map.put("orderId", orderId);
		map.put("name", name);
		
		dcOrderDAO.setEmployee(map);
	}

	@Override
	public List<Map<String, Object>> selectEmployee(DcExample criteria) {
		return dcOrderDAO.selectEmployee(criteria);
	}

	@Override
	public DcRest selectRest(Integer orderId) {
		// TODO Auto-generated method stub
		return dcOrderDAO.selectRest(orderId);
	}
}
