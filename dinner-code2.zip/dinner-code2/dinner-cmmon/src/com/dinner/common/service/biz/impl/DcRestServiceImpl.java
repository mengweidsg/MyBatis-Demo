package com.dinner.common.service.biz.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcRestDAO;
import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.DcRestExample;
import com.dinner.common.service.biz.DcRestService;

/**
 * 餐馆service
 * 
 * @author yeyj
 * 
 */
@Service("dcRestService")
public class DcRestServiceImpl implements DcRestService {
	@Resource
	private DcRestDAO dcRestDao;


	public List<DcRest> queryList(DcRestExample example) {
		example.setTotalCount(dcRestDao.countByExample(example));
		return dcRestDao.selectByExample(example);
	}
	
	@Override
	public DcRest selectById(int restId) {
		return dcRestDao.selectByPrimaryKey(restId);
	}


	@Override
	public void update(DcRest rest) {
		dcRestDao.updateByPrimaryKey(rest);

	}

	@Override
	public void save(DcRest rest) {
		dcRestDao.insert(rest);
	}

	@Override
	public void delete(int id) {
		dcRestDao.deleteByPrimaryKey(id);

	}

	@Override
	public Object getAllRest() {
		// TODO Auto-generated method stub
		return dcRestDao.getAllRest();
	}

}
