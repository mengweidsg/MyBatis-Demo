package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcMate;
import com.dinner.common.entity.DcMateExample;
import com.dinner.common.entity.LogMate;

/**
 * 食材管理service
 * 
 * @author 攻心小虫
 * 
 */
public interface DcMateService {

    public DcMate selectById(int id);
    
    
    public List<DcMate> queryList(DcMateExample example);
    

	public void update(DcMate rest);

	public void save(DcMate rest);

	public void delete(int id);

	public void save(DcMate dcMate, LogMate lm);

	public void updateKucun(String dataId, String kucun);

	public DcMate getMateInfo(String metaId, Integer restId);

}
