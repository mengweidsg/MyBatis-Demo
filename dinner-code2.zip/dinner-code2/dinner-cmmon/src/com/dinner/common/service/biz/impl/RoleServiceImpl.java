package com.dinner.common.service.biz.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcRoleDAO;
import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.DcRoleExample;
import com.dinner.common.service.biz.RoleService;

@Service("roleService")
public class RoleServiceImpl implements RoleService {

	@Resource
	private DcRoleDAO roleDao;


	public List<DcRole> queryList(DcRoleExample example) {
		example.setTotalCount(roleDao.countByExample(example));
		return roleDao.selectByExample(example);
	}

	public void update(DcRole rest,List<Integer> priv) {
		
		roleDao.deletePostPriv(rest.getPostId());
		for(Integer privId:priv){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("privId", privId);
			map.put("postId", rest.getPostId());
			roleDao.insertPostPriv(map);
		}
		roleDao.updateByPrimaryKey(rest);
	}

	public void save(DcRole rest,List<Integer> priv) {
		
		roleDao.insert(rest);
		for(Integer privId:priv){
			Map<String,Object> map = new HashMap<String,Object>();
			map.put("privId", privId);
			map.put("postId", rest.getPostId());
			roleDao.insertPostPriv(map);
		}
		
	}

	public boolean delete(int id) {
		//校验是否正在被使用
		int use = roleDao.isUse(id);
		if(use == 0){
			roleDao.deletePostPriv(id);
			roleDao.deleteByPrimaryKey(id);
			return true;
		}else{
			return false;
		}

	}
	
	public DcRole selectByPrimaryKey(int id) {
		return roleDao.selectByPrimaryKey(id);
	}
	@Override
	public List<Map<String, Object>> selectUserByPrimaryKey(int postId) {
		return roleDao.selectUserByPrimaryKey(postId);
	}

	@Override
	public List<Map<String,Object>> selectAllPrivByPrimaryKey(int postId) {
		return roleDao.selectPrivByPrimaryKey(postId);
	}


	@Override
	public List<Map<String, Object>> selectAllPrivByPrimaryKey() {
		return roleDao.selectAllPrivByPrimaryKey();
	}


	@Override
	public List<Map<String,Object>> selectPrivByPrimaryKey(int userId) {
		return roleDao.selectAllPrivByUser(userId);
	}


	@Override
	public List<Map<String, Object>> selectPrivByPrimaryKey(int postId,int userId) {
		Map<String,Object> map = new HashMap<String, Object>();
		map.put("postId", postId);
		map.put("userId", userId);
		return roleDao.selectPrivByUser(map);
	}
	
	
}
