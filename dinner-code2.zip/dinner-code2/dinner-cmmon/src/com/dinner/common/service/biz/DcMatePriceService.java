package com.dinner.common.service.biz;

import java.util.List;

import com.dinner.common.entity.DcMatePrice;
import com.dinner.common.entity.DcMatePriceExample;

/**
 * 食材单价service
 * 
 * @author 攻心小虫
 * 
 */
public interface DcMatePriceService {

    public DcMatePrice selectById(int id);
    
    public List<DcMatePrice> queryList(DcMatePriceExample example);
    
	public void update(DcMatePrice rest);

	public void save(DcMatePrice rest);

	public void delete(int id);

	public boolean checkMateId(DcMatePriceExample example);

}
