package com.dinner.common.service.biz.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.DcMateMenuDAO;
import com.dinner.common.dao.auto.DcMenuDAO;
import com.dinner.common.entity.DcMateMenu;
import com.dinner.common.entity.DcMenu;
import com.dinner.common.entity.DcMenuExample;
import com.dinner.common.service.biz.DcMenuService;

/**
 * 菜单service
 * 
 * @author yeyj
 * 
 */
@Service("dcMenuService")
public class DcMenuServiceImpl implements DcMenuService {
	@Resource
	private DcMenuDAO dcMenuDao;

	@Resource
	private DcMateMenuDAO dcMateMenuDAO;

	@Override
	public DcMenu selectById(int id) {
		DcMenu bean = dcMenuDao.selectByPrimaryKey(id);
		bean.setDcMateMenus(dcMateMenuDAO.selectByPrimaryKeyMenuId(bean.getId()));
		return bean;
	}

	@Override
	public List<Map<String,Object>> queryList(DcMenuExample example) {
		example.setTotalCount(dcMenuDao.countByExample(example));
		return dcMenuDao.selectByExample(example);
	}

	@Override
	public void update(DcMenu rest) {
		dcMateMenuDAO.deleteByMenuId(rest.getId());
		dcMenuDao.updateByPrimaryKey(rest);
		for (DcMateMenu m : rest.getDcMateMenus()) {
			m.setMenuId(rest.getId());
			dcMateMenuDAO.insert(m);
		}

	}

	@Override
	public void save(DcMenu rest) {
		dcMenuDao.insert(rest);
		for (DcMateMenu m : rest.getDcMateMenus()) {
			m.setMenuId(rest.getId());
			dcMateMenuDAO.insert(m);
		}

	}

	@Override
	public void delete(int id) {
		dcMateMenuDAO.deleteByMenuId(id);
		dcMenuDao.deleteByPrimaryKey(id);
	}

	@Override
	public boolean checkCode(DcMenuExample example) {
		int checkWorkId = dcMenuDao.countByExample(example);
		return checkWorkId==0;
	}


}
