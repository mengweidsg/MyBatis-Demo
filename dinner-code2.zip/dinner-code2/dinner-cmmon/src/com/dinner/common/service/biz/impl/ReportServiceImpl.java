package com.dinner.common.service.biz.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.ReportDAO;
import com.dinner.common.service.biz.ReportService;

/**
 * 用户服务接口
 * 
 * @author admin
 * @create 2014年2月25日 下午9:33:10
 */
@Service("reportService")
public class ReportServiceImpl implements ReportService {
	
	@Resource
	private ReportDAO reportDao;

	@Override
	public List<?> money(String start, String end, Integer restId) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("start",start);
		map.put("end",end);
		map.put("restId",restId);
		
		return reportDao.money(map);
	}

	@Override
	public List<?> srxx(String start, String end) {
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("start",start);
		map.put("end",end);
		return reportDao.srxx(map);
	}
	


}
