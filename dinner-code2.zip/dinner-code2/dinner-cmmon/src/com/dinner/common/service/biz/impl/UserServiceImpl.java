package com.dinner.common.service.biz.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.dinner.common.dao.auto.UserDAO;
import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.Privilege;
import com.dinner.common.entity.User;
import com.dinner.common.entity.UserExample;
import com.dinner.common.exception.BizException;
import com.dinner.common.exception.ErrorCode;
import com.dinner.common.service.biz.UserService;

/**
 * 用户服务接口
 * 
 * @author admin
 * @create 2014年2月25日 下午9:33:10
 */
@Service("userService")
public class UserServiceImpl implements UserService {
	
	@Resource
	private UserDAO userDao;
	
	public User longin(String loginName, String pwd) {
		if (StringUtils.isBlank(loginName) || StringUtils.isBlank(pwd)) {
			return null;
		}
		
		User u = new User();
		u.setLoginName(loginName);
		u.setPwd(DigestUtils.md5Hex(pwd));
		return userDao.getByLoginNameAndPwd(u);
	}
	
	public List<Privilege> getPrivileges(Integer userId) {
		return userDao.getUserPrivileges(userId);
	}
	
	public User getByLoginName(String loginName) {
		if (StringUtils.isBlank(loginName)) {
			return null;
		}
		return userDao.getByLoginName(loginName);
	}
	

	@Override
	public void modifyPwd(Integer userId, String oldPwd, String newPwd) {
		if (userId == null || StringUtils.isBlank(oldPwd) || StringUtils.isBlank(newPwd)) {
			throw new IllegalArgumentException();
		}
		User user = selectByPrimaryKey(userId);
		if (user == null) {
			throw new BizException(ErrorCode.USER_NOT_EXIST);
		}
		
		if (!user.getPwd().equals(DigestUtils.md5Hex(oldPwd))) { // 原始密码不正确
			throw new BizException(ErrorCode.USER_ORIGINAL_PWD_ERROR);
		}
		
		User u = new User();
		u.setUserId(userId);
		u.setPwd(DigestUtils.md5Hex(newPwd));
		userDao.modifyPwd(u);
	}

	public void save(User user, String roleId) {
		user.setStatus("NORMAL");
		user.setPwd(DigestUtils.md5Hex("888888"));	//密码默认采用888888
		userDao.insert(user);
		
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userId", user.getUserId());
		map.put("postId", roleId);
		userDao.addPost(map);
		
	}
	
	@Override
	public void update(User user, String roleId) {
		userDao.delPost(user.getUserId());
		userDao.updateByPrimaryKey(user);
		Map<String,Object> map = new HashMap<String,Object>();
		map.put("userId", user.getUserId());
		map.put("postId", roleId);
		userDao.addPost(map);
		
		
	}
	@Override
	public List<Map<String,Object>> queryList(UserExample example) {
		example.setTotalCount(userDao.countByExample(example));
		return userDao.selectByExample(example);
	}


	@Override
	public void delete(int id) {
		userDao.deleteByPrimaryKey(id);
		userDao.delPost(id);
	}

	@Override
	public User selectByPrimaryKey(int id) {
		return userDao.selectByPrimaryKey(id);
	}

	@Override
	public List<DcRole> getAllRole() {
		return userDao.getAllRole();
	}

	@Override
	public Integer selectRole(int userId) {
		return userDao.selectRole(userId);
	}

	@Override
	public List<DcRole> getAllRole(Integer userId) {
		return userDao.getAllRoleByUserId(userId);
	}

	@Override
	public List<Map<String, Object>> queryCookList(UserExample query) {
		return userDao.queryCookList(query);
	}

	@Override
	public User longinForEmployee(String loginName, String pwd) {
		if (StringUtils.isBlank(loginName) || StringUtils.isBlank(pwd)) {
			return null;
		}
		User u = new User();
		u.setLoginName(loginName);
		u.setPwd(DigestUtils.md5Hex(pwd));
		return userDao.longinForEmployee(u);
	}

	@Override
	public int getUserByRestId(Integer restId) {
		return userDao.getUserByRestId(restId);
	}

}
