package com.dinner.common.service.biz;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.DcRoleExample;

/**
 * 角色Service
 * 
 * @author admin
 * @create 2014年3月10日 下午7:03:05
 */
public interface RoleService {

    public List<DcRole> queryList(DcRoleExample example);
    
	public void update(DcRole rest,List<Integer> priv);

	public void save(DcRole rest,List<Integer> priv);

	public boolean delete(int id);

	DcRole selectByPrimaryKey(int id);


	public List<Map<String,Object>> selectUserByPrimaryKey(int postId);

	
	
	public Object selectAllPrivByPrimaryKey(int postId);

	public Object selectAllPrivByPrimaryKey();
	
	
	public List<Map<String,Object>> selectPrivByPrimaryKey(int userId);
	
	public List<Map<String,Object>> selectPrivByPrimaryKey(int postId,int userId);

}
