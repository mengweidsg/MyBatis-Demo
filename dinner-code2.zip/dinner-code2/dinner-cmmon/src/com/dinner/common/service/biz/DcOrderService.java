package com.dinner.common.service.biz;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcExample;
import com.dinner.common.entity.DcOrder;
import com.dinner.common.entity.DcOrderMenu;
import com.dinner.common.entity.DcRest;

public interface DcOrderService extends BaseService<DcOrder> {

	public List<Map<String, Object>> querySubmitList(DcExample example);
	
	List<Map<String, Object>> selectMenuById(int id,Integer menuId);
	void insertMenu(List<DcOrderMenu> l);
	void updateMenu(Integer orderId, List<DcOrderMenu> l);
	
	void saveBack(String orderId, String menuIds, String reason, String backor, String backorPwd, String backMen, String backMenPwd, Integer restId);
	void saveprice(Integer id);
	void savesell(String order_id, String name);
	
	List<Map<String, Object>> queryCook(Integer restId);
	Map<String, List<Map<String, Object>>> queryCookForMap(Integer restId);
	void update(String cooker, String ids, int restId);
	void update(String ids);
	void changeSubmit(int id);
	void submitSend(int id,int status);

	public void dealOrder(int id, String status);

	public void deleteOrder(int order_id);

	public void sendSend(int id, String yesno);


	public void setEmployee(int userId,int orderId,String name);

	public  List<Map<String, Object>> selectEmployee(DcExample criteria);

	public DcRest selectRest(Integer orderId);


}
