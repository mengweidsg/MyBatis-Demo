package com.dinner.common.service.biz;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcMenu;
import com.dinner.common.entity.DcMenuExample;

/**
 * 餐馆service
 * 
 * @author yeyj
 * 
 */
public interface DcMenuService {

    public DcMenu selectById(int id);
    
    public List<Map<String,Object>> queryList(DcMenuExample example);

	public void update(DcMenu rest);

	public void save(DcMenu rest);
	
	public void delete(int id);

	public boolean checkCode(DcMenuExample example);

}
