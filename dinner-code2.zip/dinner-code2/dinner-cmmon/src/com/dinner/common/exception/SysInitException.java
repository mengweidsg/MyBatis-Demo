package com.dinner.common.exception;

public class SysInitException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public SysInitException() {
	super();

    }

    public SysInitException(String message, Throwable cause, boolean enableSuppression,
	    boolean writableStackTrace) {
	super(message, cause, enableSuppression, writableStackTrace);

    }

    public SysInitException(String message, Throwable cause) {
	super(message, cause);

    }

    public SysInitException(String message) {
	super(message);

    }

    public SysInitException(Throwable cause) {
	super(cause);

    }

}
