package com.dinner.common.exception;

/**
 * 权限验证失败异常
 * 
 * @author admin
 * @create 2014年3月11日 下午2:26:09
 */
public class AccessDeniedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public AccessDeniedException() {
	super();
    }

    public AccessDeniedException(String message, Throwable cause, boolean enableSuppression,
	    boolean writableStackTrace) {
	super(message, cause, enableSuppression, writableStackTrace);
    }

    public AccessDeniedException(String message, Throwable cause) {
	super(message, cause);
    }

    public AccessDeniedException(String message) {
	super(message);
    }

    public AccessDeniedException(Throwable cause) {
	super(cause);
    }

}
