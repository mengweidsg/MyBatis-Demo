package com.dinner.common.exception;

/**
 * 各种业务异常
 * 
 * @author admin
 * @create 2014年3月18日 下午5:11:05
 */
public class BizException extends RuntimeException {

    private ErrorCode errorCode;
    
    private static final long serialVersionUID = 1L;

    public BizException(ErrorCode errorCode) {
	this.errorCode = errorCode;
    }
    
    public BizException(ErrorCode errorCode, Throwable cause) {
	super(cause);
   	this.errorCode = errorCode;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }

    @Override
    public String toString() {
	return this.getClass().getName() + (errorCode != null ? ": " + errorCode + ", " + errorCode.getDesc() : "");
    }
   
}
