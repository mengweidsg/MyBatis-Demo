package com.dinner.common.exception;

/**
 * 各种错误码
 * 
 * @author admin
 * @create 2014年3月18日 下午5:12:02
 */
public enum ErrorCode {

    /**
     * 用户不存在
     */
    USER_NOT_EXIST(100, "用户不存在！"),
    /**
     * 用戶原始密码不正确
     */
    USER_ORIGINAL_PWD_ERROR(101, "原始密码不正确！"),

    /**
     * root用户已经存在
     */
    USER_ROOT_EXIST(102, "root用户已经存在！"),
    /**
     * 登陆失败, 用户名或密码不正确
     */
    USER_LOGIN_ERROR(103, "用户名或密码错误，手不要抖哦！"),
    /**
     * 用户状态非正常状态
     */
    USER_STATUS_NO_NORMAL(104, "您的帐号已经被禁用！"),
    /**
     * 验证码不正确
     */
    USER_VERIFY_CODE_ERROR(105, "验证码错误，手不要抖哦!"),
    /**
     * 用户已存在
     */
    USER_EXIST(106, "用户已存在！"),

    /**
     * 创建root用户时必须提供绑定的手机号
     */
    USER_ROOT_MOB_NULL(107, "创建root用户时必须提供绑定的手机号！"),
    
    /**
     * 指定的权限不存在
     */
    PRIVILEGE_NOT_EXIST(200, "权限不存在:%s,%s！"),
    
    /**
     * 用户在别处登陆
     */
    USER_LOGIN_ELSEWHERE(201, "用户已在别处登陆！"),
    
    /**
     * 餐厅不存在
     */
    REST_NOT_EXIST(301, "餐厅不存在！"),
    
    /**
     * 订单不存在
     */
    ORDER_NOT_EXIST(401, "订单不存在！");

    private int code;
    private String desc;

    private ErrorCode(int code, String desc) {
	this.code = code;
	this.desc = desc;
    }

    public int getCode() {
	return code;
    }

    public String getDesc() {
	return desc;
    }

    public ErrorCode setDescArgs(Object... args) {
	desc = String.format(desc, args);
	return this;
    }

}
