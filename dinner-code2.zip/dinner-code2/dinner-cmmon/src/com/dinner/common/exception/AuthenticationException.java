package com.dinner.common.exception;

/**
 * 登陆验证失败异常
 * 
 * @author admin
 * @create 2014年3月11日 下午2:28:50
 */
public class AuthenticationException extends RuntimeException {

    private static final long serialVersionUID = 1L;

    public AuthenticationException() {
	super();
    }

    public AuthenticationException(String message, Throwable cause, boolean enableSuppression,
	    boolean writableStackTrace) {
	super(message, cause, enableSuppression, writableStackTrace);
    }

    public AuthenticationException(String message, Throwable cause) {
	super(message, cause);
    }

    public AuthenticationException(String message) {
	super(message);
    }

    public AuthenticationException(Throwable cause) {
	super(cause);
    }

}
