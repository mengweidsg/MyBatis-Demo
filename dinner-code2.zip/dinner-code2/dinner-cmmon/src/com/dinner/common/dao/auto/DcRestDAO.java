package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.DcRest;
import com.dinner.common.entity.DcRestExample;

public interface DcRestDAO {
    int countByExample(DcRestExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DcRest record);

    List<DcRest> selectByExample(DcRestExample example);

    DcRest selectByPrimaryKey(Integer id);

    int updateByPrimaryKey(DcRest record);

	List<DcRest> getAllRest();
}