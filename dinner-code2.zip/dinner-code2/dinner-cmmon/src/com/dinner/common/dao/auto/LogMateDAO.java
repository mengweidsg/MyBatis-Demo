package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.LogMate;
import com.dinner.common.entity.LogMateExample;

public interface LogMateDAO {
    int countByExample(LogMateExample example);
    int insert(LogMate record);
    List<LogMate> selectByExample(LogMateExample example);
}