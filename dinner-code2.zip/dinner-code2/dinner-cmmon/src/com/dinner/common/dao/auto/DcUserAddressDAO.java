package com.dinner.common.dao.auto;

import com.dinner.common.entity.DcUserAddress;
import com.dinner.common.entity.DcUserAddressExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface DcUserAddressDAO {
    int countByExample(DcUserAddressExample example);

    int deleteByExample(DcUserAddressExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(DcUserAddress record);

    int insertSelective(DcUserAddress record);

    List<DcUserAddress> selectByExample(DcUserAddressExample example);

    DcUserAddress selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") DcUserAddress record, @Param("example") DcUserAddressExample example);

    int updateByExample(@Param("record") DcUserAddress record, @Param("example") DcUserAddressExample example);

    int updateByPrimaryKeySelective(DcUserAddress record);

    int updateByPrimaryKey(DcUserAddress record);
}