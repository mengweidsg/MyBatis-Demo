package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.DcMatePrice;
import com.dinner.common.entity.DcMatePriceExample;

public interface DcMatePriceDAO {
	int countByExample(DcMatePriceExample example);
    List<DcMatePrice> selectByExample(DcMatePriceExample example);
    DcMatePrice selectByPrimaryKey(Integer id);
    int insert(DcMatePrice record);
    int updateByPrimaryKey(DcMatePrice record);
    int deleteByPrimaryKey(Integer id);
}