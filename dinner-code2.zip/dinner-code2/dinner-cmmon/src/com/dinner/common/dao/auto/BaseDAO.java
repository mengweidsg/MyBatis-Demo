package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.DcExample;

public interface BaseDAO<T> {

	int countByExample(DcExample example);

	List<T> selectByExample(DcExample example);

	T selectByPrimaryKey(Integer id);

	int insert(T t);

	int updateByPrimaryKey(T t);

	int deleteByPrimaryKey(Integer id);
}
