package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.DcRoleExample;

public interface DcRoleDAO {
	
    int countByExample(DcRoleExample example);
    List<DcRole> selectByExample(DcRoleExample example);
    
    DcRole selectByPrimaryKey(Integer postId);
    int insert(DcRole record);
    int updateByPrimaryKey(DcRole record);
    int deleteByPrimaryKey(Integer postId);
    
	int isUse(Integer postId);
	List<Map<String, Object>> selectPrivByPrimaryKey(int postId);
	List<Map<String, Object>> selectUserByPrimaryKey(int postId);
	void deletePostPriv(int postId);
	void insertPostPriv(Map<String, Object> map);
	List<Map<String, Object>> selectAllPrivByPrimaryKey();
	
	List<Map<String, Object>> selectAllPrivByUser(int userId);
	List<Map<String, Object>> selectPrivByUser(Map<String, Object> map);
}