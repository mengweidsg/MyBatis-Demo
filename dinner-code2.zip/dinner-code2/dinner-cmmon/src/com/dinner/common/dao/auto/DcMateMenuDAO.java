package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.DcMateMenu;

public interface DcMateMenuDAO {

	List<DcMateMenu> selectByPrimaryKeyMenuId(Integer menuId);

	int insert(DcMateMenu record);

	int deleteByMenuId(Integer id);
}