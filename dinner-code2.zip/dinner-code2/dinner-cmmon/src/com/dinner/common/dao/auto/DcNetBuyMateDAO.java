package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcNetBuyMate;
import com.dinner.common.entity.DcNetBuyMateExample;

public interface DcNetBuyMateDAO {
	int countByExample(DcNetBuyMateExample example);
    List<Map<String,Object>> selectByExample(DcNetBuyMateExample example);
    DcNetBuyMate selectByPrimaryKey(Integer id);
    int insert(DcNetBuyMate record);
    int updateByPrimaryKey(DcNetBuyMate record);
    int deleteByPrimaryKey(Integer id);
}