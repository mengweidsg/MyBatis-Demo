package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;


/**
 * 报表
 * 
 * @author 攻心小虫
 */
public interface ReportDAO {

	List<Map<String, Object>> money(Map<String, Object> map);

	List<Map<String, Object>> srxx(Map<String, Object> map);

   

}
