package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcMenu;
import com.dinner.common.entity.DcMenuExample;

public interface DcMenuDAO {
	int countByExample(DcMenuExample example);
    List<Map<String,Object>> selectByExample(DcMenuExample example);
    DcMenu selectByPrimaryKey(Integer id);
    int insert(DcMenu record);
    int updateByPrimaryKey(DcMenu record);
    int deleteByPrimaryKey(Integer id);
	int checkCode(DcMenu record);
}