package com.dinner.common.dao.auto;

import java.util.List;

import com.dinner.common.entity.DcExample;
import com.dinner.common.entity.DcMate;

public interface DcMateDAO {
	int countByExample(DcExample example);
    List<DcMate> selectByExample(DcExample example);
    DcMate selectByPrimaryKey(Integer id);
    int insert(DcMate record);
    int updateByPrimaryKey(DcMate record);
    int deleteByPrimaryKey(Integer id);
}