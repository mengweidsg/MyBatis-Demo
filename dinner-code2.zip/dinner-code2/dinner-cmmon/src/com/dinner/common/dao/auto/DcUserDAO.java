package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcUser;
import com.dinner.common.entity.DcUserExample;

/**
 * 点餐用户DAO
 * 
 * @author yu.han 2014年6月30日 下午5:00:56
 * 
 */
public interface DcUserDAO {
    public DcUser findOne(DcUser query);
    public int updateByMob(DcUser entity);
	public int countByExample(DcUserExample example);
	public List<DcUser> queryUserList(DcUserExample example);
	public int countRestByExample(DcUserExample example);
	public List<DcUser> queryRestUserList(DcUserExample example);
	public boolean saveSale(Map<String, Object> map);
}
