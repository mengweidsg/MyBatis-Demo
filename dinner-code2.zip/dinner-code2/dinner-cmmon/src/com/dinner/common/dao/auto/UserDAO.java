package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcRole;
import com.dinner.common.entity.Privilege;
import com.dinner.common.entity.User;
import com.dinner.common.entity.UserExample;

/**
 * 系统用户
 * 
 * @author 攻心小虫
 */
public interface UserDAO {

    /**
     * 用户登陆 通过登录名、密码获取用户
     * 
     * @param loginName
     * @param pwd
     * @return
     */
    User getByLoginNameAndPwd(User record);


    /**
     * 修改密码
     * 
     * @param userId
     * @param md5Hex
     */
    void modifyPwd(User record);

    /**
     * 根据登录名获取用户
     * 
     * @param loginName
     * @return
     */
    User getByLoginName(String loginName);

    List<Privilege> getUserPrivileges(int UserId);
    
    int countByExample(UserExample example);
    List<Map<String,Object>> selectByExample(UserExample example);
    
    User selectByPrimaryKey(Integer postId);
    int insert(User record);
    int updateByPrimaryKey(User record);
    int deleteByPrimaryKey(Integer postId);


	List<DcRole> getAllRole();


	Integer selectRole(int userId);


	void delPost(Integer userId);


	void addPost(Map<String, Object> map);


	List<DcRole> getAllRoleByUserId(Integer userId);


	List<Map<String, Object>> queryCookList(UserExample query);


	User longinForEmployee(User u);

	int getUserByRestId(Integer restId);

}
