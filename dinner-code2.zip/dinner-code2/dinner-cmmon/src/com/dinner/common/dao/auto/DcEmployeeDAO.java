package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcEmployee;
import com.dinner.common.entity.DcEmployeeExample;

public interface DcEmployeeDAO {
	
	
    int countByExample(DcEmployeeExample example);
    int insert(DcEmployee record);
    List<DcEmployee> selectByExample(DcEmployeeExample example);
    int updateByPrimaryKey(DcEmployee record);
    int deleteByPrimaryKey(Integer id);
    DcEmployee selectByPrimaryKey(Integer id);
	List<DcEmployee> queryAllEmployeeList(int restId);
	void update(Map<String, Object> map);
}