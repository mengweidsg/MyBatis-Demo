package com.dinner.common.dao.auto;

import java.util.List;
import java.util.Map;

import com.dinner.common.entity.DcExample;
import com.dinner.common.entity.DcOrder;
import com.dinner.common.entity.DcOrderMenu;
import com.dinner.common.entity.DcRest;



public interface DcOrderDAO extends BaseDAO<DcOrder> {

	
	List<Map<String,Object>> selectForSubmitByExample(DcExample example);
	
	List<Map<String,Object>> selectMenuById(Map<String,Object> map);
	void insertMenu(DcOrderMenu menu);
	void deleteAllMenu(Integer orderId);
	
	void saveBack(Map<String, Object> map);
	int countBackByExample(String orderId);
	void saveprice(Integer id);
	void saveSell(DcOrder bean);
	
	List<Map<String, Object>> queryCook(Integer restId);
	void updateCooker(Map<String, Object> map);
	void updateCookerStatus(Map<String,Object> ids);
	List<Map<String, Object>> queryCookForMap(Integer restId);
	void changeSubmit(int id);
	void submitSend(Map<String,Object> map);

	void dealOrder(Map<String, Object> map);

	void sendSend(Map<String, Object> map);

	void setEmployee(Map<String, Object> map);

	List<Map<String, Object>> selectEmployee(DcExample criteria);

	List<Map<String, Object>> selectMateUse(Map<String, Object> map);

	DcRest selectRest(Integer orderId);
}
