package com.dinner.common.dao.auto;

import java.io.Serializable;
import java.util.List;

import com.dinner.common.entity.SysParam;

public interface SysParamDAO {
	
	
	public List<SysParam> query();
    
    public void insert(SysParam sysParam);
    
    public void update(SysParam sysParam);
    
    public void delete(Serializable id);

	public SysParam selectById(int id);

	public List<SysParam> getParam(String name);
}