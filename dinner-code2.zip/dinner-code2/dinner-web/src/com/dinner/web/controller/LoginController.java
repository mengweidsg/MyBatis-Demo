package com.dinner.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.web.controller.base.BaseController;

/**
 * 处理用户登陆、登出、主页
 * 
 * @author admin
 * @create 2014年2月26日 下午1:59:39
 */
@Controller
public class LoginController extends BaseController {

//	@Resource
//	private UserService userService;

	//登录页面
	@RequestMapping(value = "login.htm", method = RequestMethod.GET)
	public ModelAndView loginPage(HttpServletRequest request, HttpServletResponse response) {
		return new ModelAndView("front/login");
	}
//
//	//登录操作
//	@RequestMapping(value = "login.htm", method = RequestMethod.POST)
//	public ModelAndView login(User user, HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView view = new ModelAndView("home/login");
//		Result<String> result = new Result<String>(0, "登入成功");
//		try {
//			if (StringUtils.isBlank(user.getLoginName()) || StringUtils.isBlank(user.getPwd())) {
//				result.setCode(-1);
//				result.setMsg("请输入用户名和密码");
//			} else {
//				user = userService.longin(user.getLoginName(), user.getPwd());
//				if (user == null) {
//					result.setCode(-2);
//					result.setMsg("用户不存在");
//				} else {
//					UserUtils.saveLoginUser(request, user);
//
//					// 登陆成功, 获取对应的权限
//					List<Privilege> privileges = userService.getPrivileges(user.getUserId());
//					user.setPrivileges(privileges);
//
//					// 跳转到指定页面
//					Thread.sleep(100); // 针对IE8 报Cannot call sendRedirect()
//					String contextPath = request.getContextPath();
//					response.sendRedirect(contextPath + "/home/index.htm");
//				}
//			}
//		} catch (Exception e) {
//			result.setCode(-999);
//			result.setMsg("登入异常");
//			e.printStackTrace();
//		}
//		view.addObject("result", result);
//		return view;
//	}
//	
//	 //外卖登录
//	 @RequestMapping(value = "/loginEmployee.htm", method = RequestMethod.POST)
//	 public void finish(User user,HttpServletRequest request, HttpServletResponse response) throws IOException {
//		Result<String> result = new Result<String>(0, "登入成功");
//		try {
//			if (StringUtils.isBlank(user.getLoginName()) || StringUtils.isBlank(user.getPwd())) {
//				result.setCode(-1);
//				result.setMsg("请输入用户名和密码");
//			} else {
//				user = userService.longinForEmployee(user.getLoginName(), user.getPwd());
//				if (user == null) {
//					result.setCode(-2);
//					result.setMsg("用户不存在");
//				} else {
//					UserUtils.saveLoginUser(request, user);
//
//					// 登陆成功, 获取对应的权限
//					List<Privilege> privileges = userService.getPrivileges(user.getUserId());
//					Privilege e = new Privilege("dinner","waimai");
//					e.setLevel( Privilege.ONE_LEVEL_MENU);
//					privileges.add(e);	//追加手机用户操作
//					user.setPrivileges(privileges);
//					result.setMsg(user.getUserType());
//				}
//			}
//		} catch (Exception e) {
//			result.setCode(-999);
//			result.setMsg("登入异常");
//			e.printStackTrace();
//		}
//		 this.outJson(response, JsonUtil.toJson(result));
//	 }
//	
//	
//	//主页面
//	@RequestMapping("/index.htm")
//	public ModelAndView index(HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView view = new ModelAndView("home/index");
//		view.addObject("breadcrumb", "欢迎");
//		return view;
//	}
//	
//	//退出操作
//	@RequestMapping("/logout.htm")
//	public RedirectView logout(HttpServletRequest request, HttpServletResponse response) {
//		UserUtils.removeUser(request);
//		return new RedirectView("login.htm");
//	}
//
//	//修改密码页面
//	@RequestMapping(value = "password.htm", method = RequestMethod.GET)
//	public ModelAndView passwordPage(HttpServletRequest request, HttpServletResponse response) {
//		ModelAndView view = new ModelAndView("home/password");
//		view.addObject("breadcrumb", "修改密码");
//		return view;
//	}
//	
//	//修改密码页面
//	@RequestMapping(value = "password.htm", method = RequestMethod.POST)
//	public ModelAndView changePassword(HttpServletRequest request, HttpServletResponse response,String oldpassword,String newpassword,String surepassword) {
//		ModelAndView view = new ModelAndView("home/password");
//		User user = UserUtils.getLoginUser(request);
//		Result<String> result = new Result<String>(0, "操作成功！");
//		view.addObject("result", result);
//		try{
//			if (user == null) {
//				result.setCode(1);
//				result.setMsg("您尚无登陆!");
//			}else if(StringUtils.isBlank(oldpassword) || StringUtils.isBlank(newpassword)|| StringUtils.isBlank(surepassword)){
//				result.setCode(2);
//				result.setMsg("密码不能为空！");
//			}else if(!newpassword.equals(surepassword)){
//				result.setCode(2);
//				result.setMsg("两次密码不正确！");
//			}else if(!oldpassword.equals(newpassword)){
//				result.setCode(2);
//				result.setMsg("新密码与旧密码相同！");
//			}
//			userService.modifyPwd(user.getUserId(), oldpassword, newpassword);
//			UserUtils.removeUser(request);// 登出
//			return new ModelAndView("home/login");
//		} catch (Exception e) {
//			result.setCode(-999);
//			result.setMsg("修改异常");
//		}
//		return view;
//	}
	
}
