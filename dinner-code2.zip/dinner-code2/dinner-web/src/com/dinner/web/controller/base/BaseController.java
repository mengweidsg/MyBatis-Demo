package com.dinner.web.controller.base;

import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.dinner.framework.util.date.DateUtils;
import com.dinner.framework.util.web.WebUtils;
import com.dinner.web.util.StringPropertyEditor;

public class BaseController {

    private static final Log log = LogFactory.getLog(BaseController.class);

    @InitBinder
    protected void initBinder(HttpServletRequest request, ServletRequestDataBinder binder)
	    throws Exception {
	binder.registerCustomEditor(String.class, new StringPropertyEditor());
    }

    protected Short getShort(HttpServletRequest request, String key, Short defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return Short.parseShort(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected Date getDate(HttpServletRequest request, String key, Date defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return DateUtils.parse(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected Integer getInteger(HttpServletRequest request, String key, Integer defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return Integer.parseInt(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected Integer getInteger(HttpServletRequest request, String key) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return null;
	try {
	    return Integer.parseInt(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return null;
	}
    }

    protected Byte getByte(HttpServletRequest request, String key, Byte defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return Byte.parseByte((request.getParameter(key)));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected Double getDouble(HttpServletRequest request, String key, Double defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return Double.parseDouble(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected Long getLong(HttpServletRequest request, String key, Long defaultValue) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    return Long.parseLong(request.getParameter(key));
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected String getString(HttpServletRequest request, String key, String defaultValue,
	    boolean encode) {
	String value = request.getParameter(key);
	if (value == null || value == "")
	    return defaultValue;
	try {
	    String s = request.getParameter(key);
	    if (s != null && encode) {
		s = new String(s.getBytes("iso-8859-1"), "utf-8");
	    }
	    return s;
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return defaultValue;
	}
    }

    protected String getString(HttpServletRequest request, String key) {
	return getString(request, key, null, false);
    }

    protected String getString(HttpServletRequest request, String key, String defaultValue) {
	return getString(request, key, defaultValue, false);
    }

    protected Boolean getBoolean(HttpServletRequest request, String key) {
	return getBoolean(request, key, false);
    }

    protected Boolean getBoolean(HttpServletRequest request, String key, Boolean defaultValue) {
	String value = request.getParameter(key);
	if (StringUtils.isBlank(value))
	    return defaultValue;
	try {
	    String s = request.getParameter(key);
	    s = s.trim();
	    if ("true".equals(s)) {
		return true;
	    }
	    return false;
	} catch (Exception e) {
	    log.error("参数解析错误, key:" + key, e);
	    return false;
	}
    }


    protected boolean isPost(HttpServletRequest request) {
	return request.getMethod().toLowerCase().endsWith("post");
    }

    protected void outText(HttpServletResponse response, String content) {
	try {
	    response.setContentType(WebUtils.HTML_RESPONSE_TYPE);
	    response.setCharacterEncoding("UTF-8");
	    response.setHeader("Content-length", "" + content.getBytes().length);
	    PrintWriter pw = response.getWriter();
	    pw.write(content);
	    pw.flush();
	    pw.close();
	} catch (Exception e) {
	    e.printStackTrace();
	    response.setStatus(407);
	}
    }

    protected void outJson(HttpServletResponse response, String content) {
	try {
	    response.setContentType(WebUtils.JSON_RESPONSE_TYPE);
	    response.setCharacterEncoding("UTF-8");
	    PrintWriter pw = response.getWriter();
	    pw.write(content);
	    pw.flush();
	    pw.close();
	} catch (Exception e) {
	    e.printStackTrace();
	    response.setStatus(407);
	}
    }
}
