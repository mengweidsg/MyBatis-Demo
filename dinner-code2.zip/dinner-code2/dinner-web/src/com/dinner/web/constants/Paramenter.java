package com.dinner.web.constants;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.dinner.common.entity.SysParam;
import com.dinner.common.service.biz.SysParamService;
import com.dinner.web.util.SpringApplicationContext;

public class Paramenter {

	
	private static final Paramenter p = new Paramenter();
	
	private static final Map<String,List<SysParam>> param = new HashMap<String,List<SysParam>>();
	
	
	private static final String PARANNAME = "ParamName";
	
	private Paramenter(){}
	
	static{
		init();
	}
	//初始化
	private static void init(){
		//加载所有的参数 
		SysParamService sysParamService = (SysParamService) SpringApplicationContext.getApplicationContext().getBean(SysParamService.class);	
		
		List<SysParam> query = sysParamService.query();
		
		String name = null;
		
		List<SysParam> list = new ArrayList<SysParam>();
		for(SysParam p : query){
			if(name != null && !name.equals(p.getName())){
				param.put(name, list);
				list = new ArrayList<SysParam>();
			}
			name = p.getName();
			list.add(p);
		}
		param.put(name, list);
	}
	
	public static Paramenter getInstance(){
		return p;
	}
	
	public void reload() {
		init();
	}
	
	private List<SysParam> getParam(String codeName){
		return param.get(codeName);
	}
	
	private Map<String,String> getParamForMap(String codeName){
		List<SysParam> joinType =getParam(codeName);
		Map<String,String> map =new HashMap<String,String>();
		if(joinType != null){
			for(SysParam p :joinType){
				map.put(p.getCodeKey(), p.getCodeValue());
			}
		}
		return map;
	}
	
	//获取数据字典列表
	public List<SysParam> getRootParam(){
		return param.get(PARANNAME);
	}

	/** 商圈  **/
	public List<SysParam> getBusinessZone() {
		return getParam("001");
	}
	public Map<String,String>getBusinessZoneForMap() {
		return getParamForMap("001");
	}
	/** 特色  **/
	public List<SysParam> getFeatures(){
		return getParam("002");
	}
	public Map<String,String> getFeaturesForMap(){
		return getParamForMap("002");
	}
	/** 餐厅合作性质  **/
	public List<SysParam> getJoinType(){
		return getParam("003");
	}
	public Map<String,String> getJoinTypeForMap(){
		return getParamForMap("003");
	}
	/** 菜系  **/
	public List<SysParam> getSeries() {
		return getParam("004");
	}
	public Map<String,String>getSeriesForMap() {
		return getParamForMap("004");
	}
	/** 辣程度  **/
	public List<SysParam> getHot() {
		return getParam("005");
	}
	public Map<String,String>getHotForMap() {
		return getParamForMap("005");
	}
	/** 菜类型  **/
	public List<SysParam> getType() {
		return getParam("006");
	}
	public Map<String,String>getTypeForMap() {
		return getParamForMap("006");
	}
	/** 员工类型  **/
	public List<SysParam> getEmployeeType() {
		return getParam("008");
	}
	public Map<String,String>getEmployeeTypeForMap() {
		return getParamForMap("008");
	}
	/** 食材  **/
	public List<SysParam> getMate() {
		return getParam("009");
	}
	public Map<String,String> getMateForMap() {
		return getParamForMap("009");
	}
	/** 退菜原因  **/
	public List<SysParam> getBackReason() {
		return getParam("010");
	}
	/** 性别  **/
	public List<SysParam> getSex() {
		return getParam("sex");
	}
	public Map<String,String>getSexForMap() {
		return getParamForMap("sex");
	}
	/** 是否  **/
	public List<SysParam> getYesNo() {
		return getParam("yes_no");
	}
	public Map<String,String> getYesNoForMap() {
		return getParamForMap("yes_no");
	}
	/** 接受状态  **/
	public Map<String,String> getAcceptStatusForMap() {
		return getParamForMap("accept_status");
	}
	public List<SysParam> getAcceptStatus() {
		return getParam("accept_status");
	}
	/** 派送状态  **/
	public Map<String,String> getSendStatusForMap() {
		return getParamForMap("send_status");
	}
	public List<SysParam> getSendStatus() {
		return getParam("send_status");
	}
}
