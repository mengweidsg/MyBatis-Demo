package com.dinner.web.util;

import java.beans.PropertyEditorSupport;

import org.apache.commons.lang.StringUtils;

/**
 * Spring mvc绑定String参数时对空字符串进行null处理
 * 
 * @author admin
 * @create 2014年3月12日 下午1:42:03
 */
public class StringPropertyEditor extends PropertyEditorSupport {

    @Override
    public void setAsText(String text) throws IllegalArgumentException {
	if (StringUtils.isBlank(text)) {
	    setValue(null);
	} else {
	    setValue(text.trim());
	}
    }

}
