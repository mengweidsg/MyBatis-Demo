package com.dinner.web.util;

import javax.servlet.http.HttpServletRequest;

import com.dinner.common.entity.User;

public class UserUtils {

	private static final String SESSION_LOGIN_KEY = "login_user";

	/**
	 * 从Session中获取已登陆用户
	 * 
	 * @param request
	 * @return
	 */
	public static User getLoginUser(HttpServletRequest request) {
		return (User) request.getSession().getAttribute(SESSION_LOGIN_KEY);
	}

	/**
	 * 把登陆用户保存到Session中
	 * 
	 * @param request
	 * @param user
	 */
	public static void saveLoginUser(HttpServletRequest request, User user) {
		request.getSession().invalidate(); // session 先置为无效
		request.getSession().setAttribute(SESSION_LOGIN_KEY, user);
	}

	/**
	 * 删除用户
	 * 
	 * @param request
	 */
	public static void removeUser(HttpServletRequest request) {
		request.getSession().invalidate();
	}

}
