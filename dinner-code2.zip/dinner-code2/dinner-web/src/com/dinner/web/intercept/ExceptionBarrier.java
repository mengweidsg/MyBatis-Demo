package com.dinner.web.intercept;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Component;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.exception.AccessDeniedException;
import com.dinner.common.exception.AuthenticationException;
import com.dinner.common.exception.BizException;
import com.dinner.common.exception.ErrorCode;
import com.dinner.framework.bean.Result;
import com.dinner.framework.util.JsonUtil;
import com.dinner.framework.util.web.WebUtils;

/**
 * 统一异常处理
 * 
 * @author admin
 * @create 2014年3月11日 下午3:11:34
 */
@Component
public class ExceptionBarrier implements HandlerExceptionResolver {

    private static final Logger logger = Logger.getLogger(ExceptionBarrier.class);

    @Override
    public ModelAndView resolveException(HttpServletRequest req, HttpServletResponse resp,
	    Object handler, Exception e) {

	logger.error(e);

	Result<String> error = null;

	// 对各种异常进行分别处理
	if (e instanceof BindException) { // 参数验证错误
	    List<ObjectError> errors = ((BindException) e).getAllErrors();
	    String m = "";
	    for (ObjectError err : errors) {
		m += err.getDefaultMessage() + ",";
	    }
	    if (m.length() > 0) {
		m = m.substring(0, m.length() - 1);
	    }
	    error = new Result<String>(Result.ERROR, m);
	} else if (e instanceof AccessDeniedException) { // 权限验证失败
	    error = new Result<String>(Result.ERROR, "您尚无权限进行此项操作！");
	} else if (e instanceof AuthenticationException) { // 登陆验证失败
	    error = new Result<String>(Result.ERROR, "您尚无登陆！");
	} else if (e instanceof BizException) { // 业务异常
	    ErrorCode errorCode = ((BizException) e).getErrorCode();
	    error = new Result<String>(Result.ERROR, errorCode.getDesc());
	} else {
	    error = new Result<String>(Result.ERROR, "操作失败！");
	}

	try {
	    WebUtils.outJson(resp, JsonUtil.toJson(error));
	} catch (IOException ioe) {
	    logger.error(ioe);
	    throw new RuntimeException(ioe);
	}
	return null;
    }

}
