package com.dinner.web.intercept;

import javax.servlet.http.HttpServletRequest;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.ModelAndView;

import com.dinner.common.entity.User;
import com.dinner.web.util.UserUtils;

@Component
@Aspect
public class IndexAspectJ {

	@Autowired(required = true)
	private HttpServletRequest request;

	@Pointcut("execution(org.springframework.web.servlet.ModelAndView com.dinner.web.controller..*.* (..))")
	public void cutController() {

	}

	@AfterReturning(pointcut = "cutController()", returning = "model")
	public void doAfterReturning(JoinPoint jp,ModelAndView model) {
		User user = UserUtils.getLoginUser(request);
		if (user != null) {
			
			//Signature signature = jp.getSignature();
			//MethodSignature methodSignature = (MethodSignature) signature;  
			//Method method = methodSignature.getMethod();  
			
			
			model.addObject("user", user);
			model.addObject("menus", user.getMenuTree());
		}
	}

}
